using System;
using System.Collections.Generic;
using System.Text;
using FSEarthMasksInternalDLL;

namespace FSEarthMasksDLL
{
    public class SummerScript
    {        

        //Summer is usually equal to the original source map so there isn't anything to do here

        //The following Methodes will be called by FSEarthMasks:
        //MakeSummer(MasksTexture iTexture)
        public void MakeSummer(MasksTexture iTexture)
        {
            //Nothing to do
        }
    }
}
