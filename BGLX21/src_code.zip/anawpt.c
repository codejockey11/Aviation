/*
 *   $Id: anawpt.c,v 1.8 2005/10/12 17:26:03 Alessandro Exp $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: WayPoint record analyzer $
 *
 *   $Log: anawpt.c,v $
 *   Revision 1.8  2005/10/12 17:26:03  alexanto
 *   made decoding routines aware of multiple routes
 *
 *   Revision 1.7  2005/05/01 16:12:32  alexanto
 *   Changed loop code
 *
 *   Revision 1.6  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.5  2004/03/12 15:19:59  alexanto
 *   Some changes
 *
 *   Revision 1.4  2004/02/19 17:51:07  alexanto
 *   Some changes
 *
 *   Revision 1.3  2004/02/14 17:34:55  alexanto
 *   Changed length field to unsigned
 *
 *   Revision 1.2  2004/02/12 15:17:07  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2004/02/04 14:07:48  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"



/*
 * Analyzes and decode Waypoints and routes
 *
 * Parameters:
 * nGrpCount - number of WayPoint available in this group
 * nGrpOffset - offset to current WayPoint chunk
 * nGrpLen - current chunk length
 *
 * Return value:
 * none
 */
void AnalyzeWpt(DWORD nGrpCount, DWORD nGrpOffset, DWORD nChunkLen)
{

	WORD wType;				// navaid type - 0x22 for waypoint
	DWORD nLen;				// length of record in bytes
	BYTE bWptKind;			// waypoint type, NAMED, UNNAMED, etc.
	BYTE bHasRoute;			// waypoint has nested route (0x0 or 0x1)
	int nLon;				// packed longitude
	int nLat;				// packed latitude
	float fMagVar;  		// magvar
	DWORD nId;
	DWORD nRegion;
	char szId[8];			// encrypted navaid ID
	char szRegion[8];		// encrypted navaid Region

	BYTE bType;				// route type
	char szName[8];			// route name
	DWORD nNextId;
	char szNextId[8];		// previous wayp. encrypted ID
	DWORD nNextRegion;
	char szNextRegion[8];	// previous wayp. encrypted Region
	float fNextAltitude;	// previous wayp. altitude in meters

	DWORD nPrevId;
	DWORD nRouteStart;
	DWORD nRouteLen;
	DWORD nSubChunk;
	char szPrevId[8];		// next wayp. encrypted ID
	DWORD nPrevRegion;
	char szPrevRegion[8];	// next wayp. encrypted Region
	float fPrevAltitude;	// next wayp. altitude in meters
	intlist_t *ptr;	
	char szLat[24];
	char szLon[24];


	int nStart = nGrpOffset;
	int nEnd = nGrpOffset+nChunkLen;
	int n;

	while (nStart<nEnd)
	{
		n = nStart;

		wType = GET_U16(n);
		nLen = GET_U32(n+2);
		bWptKind = GET_BYTE(n+6);
		bHasRoute = GET_BYTE(n+7);
		nLon = GET_S32(n+8);
		nLat = GET_S32(n+12);
		fMagVar = GET_FLOAT(n+16);
		nId = GET_U32(n+20);
		nRegion = GET_U32(n+24);

		/* if we have a terminal waypoint */
		if ( (LO4BITS(LOBYTE(LOWORD(nId))))==FIX_TYPE_TERMINAL_WAYPOINT)
		{
			ptr = MALLOC(sizeof(intlist_t));
			PRECONDITION(NULL!=ptr);
			ptr->nOffset=nStart;
			ptr->nParam=nRegion>>6; // strip 11 bits to get belonging Airport
			ptr->next=NULL; 
			if (NULL==lpWpt)
			{
				lpWpt=ptr;
				lpWptTail=ptr;
			}
			else
			{
				lpWptTail->next=ptr;
				lpWptTail=ptr;
			}
			goto skip;
		}


		if (nPartialDecode)		// if partial decode is enabled
		{
			if (gcdist(fCenterLat,fCenterLon,
				fslat2lat(nLat),fslon2lon(nLon))>fCenterRad)
			{	
				goto skip;	// skip the record if too far away
			}
		}


		

		DecodeRegionStr(nRegion, szRegion);
		DecodeIdStr(nId, szId, 0x45);

		//DecodeIdStr(nAptId, szAptId, 0x45);



/*		if (bHasRoute)		// read additional info for routes
		{
			bType = GET_BYTE(n+28);
			memcpy(szName, OFFSET(n+29),sizeof(szName));
			nNextId = GET_U32(n+29+sizeof(szName));
			nNextRegion = GET_U32(n+33+sizeof(szName));
			fNextAltitude = GET_FLOAT(n+37+sizeof(szName));
			nPrevId = GET_U32(n+41+sizeof(szName));
			nPrevRegion = GET_S32(n+45+sizeof(szName));
			fPrevAltitude = GET_FLOAT(n+49+sizeof(szName));
		}*/
		if (!nTerse)
			PrintObjectSpec("Waypoint",nStart);

		
		fprintf(outfile,"\t<Waypoint lat=\"%s\" lon=\"%s\" "
			"waypointType=\"%s\"\n\t\tmagvar=\"%0.2lf\" "
			"waypointRegion=\"%s\" waypointIdent=\"%s\"",
			LatString(ndblat2lat(nLat),szLat),
			LatString(ndblon2lon(nLon),szLon),
			wpTable[bWptKind],
			MAGVAR(fMagVar), szRegion, szId );

		//if (bHasRoute)		// read additional info for routes
		//	fprintf(outfile," >\n");

		if (bHasRoute)		// read additional info for routes
		{

			fprintf(outfile," >\n");
			
			nRouteStart = n + 28;			// mark start of routes
			nRouteLen = (n+nLen) - 28;		// try to compute length of route chunk

			while (nRouteStart<nRouteLen)
			{
				nSubChunk = nRouteStart;
				bType = GET_BYTE(nSubChunk);
				
				memcpy(szName , OFFSET(nSubChunk+1),sizeof(szName));
				nNextId = GET_U32(nSubChunk+1+sizeof(szName));

				nNextRegion = GET_U32(nSubChunk+5+sizeof(szName));
				fNextAltitude = GET_FLOAT(nSubChunk+9+sizeof(szName));
				
				nPrevId = GET_U32(nSubChunk+13+sizeof(szName));
				nPrevRegion = GET_S32(nSubChunk+17+sizeof(szName));
				fPrevAltitude = GET_FLOAT(nSubChunk+21+sizeof(szName));
				
				nRouteStart+=25+sizeof(szName);
	
				DecodeRegionStr(nNextRegion,szNextRegion);
				DecodeRegionStr(nPrevRegion,szPrevRegion);
				DecodeIdStr(nNextId, szNextId,0x45);
				DecodeIdStr(nPrevId, szPrevId,0x45);

				fprintf(outfile,"\t\t<Route routeType=\"%s\" name=\"%s\" >\n",
					rteTable[bType], szName);				
			
				if (nPrevId!=0)	// if we have a valid previous route
				{
					fprintf(outfile,"\t\t\t<Previous waypointType=\"UNNAMED\" waypointRegion=\"%s\"\n"
						"\t\t\t\twaypointIdent=\"%s\" altitudeMinimum=\"%0.3lf\" />\n",
						szPrevRegion, szPrevId, fPrevAltitude);
				}
				if (nNextId!=0)	// if we have a valid next route
				{
					fprintf(outfile,"\t\t\t<Next waypointType=\"UNNAMED\" waypointRegion=\"%s\"\n"
						"\t\t\t\twaypointIdent=\"%s\" altitudeMinimum=\"%0.3lf\" />\n",
						szNextRegion, szNextId, fNextAltitude);
				}
				fprintf(outfile,"\t\t</Route>\n");
			}
			fprintf(outfile,"\t</Waypoint>\n");

		}
		else
			fprintf(outfile," />\n");
		fprintf(outfile,"\n");
skip:
		nStart+=nLen;
	}

}

