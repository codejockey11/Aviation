/*
 *   $Id: anavor.c,v 1.7 2007/10/02 21:46:38 alexanto Exp $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: VOR / ILS record analyzer $
 *
 *   $Log: anavor.c,v $
 *   Revision 1.7  2007/10/02 21:46:38  alexanto
 *   Scan algorithm corrected to be the good one
 *
 *   Revision 1.6  2005/05/01 16:12:32  alexanto
 *   Changed loop code
 *
 *   Revision 1.5  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.4  2004/02/25 13:47:04  alexanto
 *   Added description print with XML translation
 *
 *   Revision 1.3  2004/02/19 17:51:07  alexanto
 *   Some changes
 *
 *   Revision 1.2  2004/02/12 15:17:07  alexanto
 *   +Id+Log
 *   ,
 *
 *   Revision 1.1  2004/02/04 14:07:48  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"


/*
 * Analyzes and decode VORs
 *
 * Parameters:
 * nGrpCount - number of VOR available in this group
 * nGrpOffset - offset to current VOR chunk
 * nGrpLen - current chunk length
 *
 * Return value:
 * none
 */
void AnalyzeVor(DWORD nGrpCount, DWORD nGrpOffset, DWORD nChunkLen)
{
	DWORD nStart=nGrpOffset, nEnd = nGrpOffset+nChunkLen;
    DWORD nCurrent;
    DWORD nLen;
	WORD wType;
    BYTE bType;
    int nLat, nLon, nAlt;
    BYTE bFlags;
    float fRange, fMagVar, fDmeRange;
    int nFreq;
	int nId;
	char szDesc[64];		// navaid description
	char szRegion[8];
	char szLat[24];
	char szLon[24];
	char szAlt[24];
	char szRange[24];

	int nDmeLon, nDmeLat, nDmeAlt;
    

    char szId[4];
    DWORD nSubStart, nSubEnd;
	int nRegion;
	WORD wId;
	DWORD nChunkLength;
    BOOL hasDme;
	intlist_t *ptr;

    while (nStart<nEnd)
    {
		nCurrent=nStart;
		wType = GET_U16(nCurrent);
        if (wType!=OBJTYPE_VOR)
        	break;
		nLen = GET_U32(nCurrent+2);
		bType = GET_BYTE(nCurrent+6);
		nLon = GET_S32(nCurrent+8);
		nLat = GET_S32(nCurrent+12);
		nAlt = GET_S32(nCurrent+16);



		if (nPartialDecode)		// if partial decode is enabled
		{
			if (gcdist(fCenterLat,fCenterLon,
				fslat2lat(nLat),fslon2lon(nLon))>fCenterRad)
			{	
				goto skip;	// skip the record if too far away
			}
		}



		if (bType==VOR_ILS)	// if we have an ILS
		{
			ptr = MALLOC(sizeof(intlist_t));
			PRECONDITION(NULL!=ptr);
			ptr->nOffset=(DWORD)(nStart);
			ptr->next=NULL;
			if (NULL==lpIls)
			{
				lpIls=ptr;
				lpIlsTail=ptr;
			}
			else
			{
				lpIlsTail->next=ptr;
				lpIlsTail=ptr;
			}
        }
        else if (bType!=VOR_ILS)				// else scan vor
        {
			bFlags = GET_BYTE(nCurrent+7);
			nFreq = GET_S32(nCurrent+20);
			fRange = GET_FLOAT(nCurrent+24);
			fMagVar = GET_FLOAT(nCurrent+28);
			nId = GET_S32(nCurrent+32);
			nRegion = GET_S32(nCurrent+36);
			//wUnk1 = GET_U16(nGrpOffset+nBytesRead+40);
			
			nSubStart = nCurrent+40;
			nSubEnd = nCurrent+nLen;
			memset(szDesc,0x0,sizeof(szDesc));
			hasDme = 0;
			while (nSubStart<nSubEnd)
			{
				wId = GET_U16(nSubStart);
				switch (wId)
				{
				case 0x19:		// vor name
					nChunkLength = GET_U32(nSubStart+2);
					memmove(szDesc,OFFSET(nSubStart+6),
	                    min(nChunkLength-6,sizeof(szDesc)-1)); // get descriptive name
	                nSubStart+=nChunkLength;
    	            break;
				
				case 0x16:
					nChunkLength = GET_U32(nSubStart+2);
					nDmeLon = GET_S32(nSubStart+8);
					nDmeLat = GET_S32(nSubStart+12);
					nDmeAlt = GET_S32(nSubStart+16);
					fDmeRange = GET_FLOAT(nSubStart+20);
					hasDme = 1;
	                nSubStart+=nChunkLength;
					break;
				default:	// just to avoid endless loops risks
					nSubStart+=nSubEnd;
					break;
				}
			}

			
			/*if (bFlags<0x10)	// e.g. this doesn't have a DME
			{
				nOffset = GET_S32(nCurrent+42);
				memset(szDesc,0x0,sizeof(szDesc));
				memmove(szDesc,&OFFSET(nCurrent+46),
                	min(nOffset-6,sizeof(szDesc)-1));
				//DecodeRegionStr(nRegion,szRegion);
			}
			else				// read additional info for DME
			{
				wDmeType = GET_U16(nCurrent+40);
				nDmeLen = GET_S32(nCurrent+42);
				nDmeLon = GET_S32(nCurrent+48);
				nDmeLat = GET_S32(nCurrent+52);
				nDmeAlt = GET_S32(nCurrent+56);
				//fDmeRange = GET_F32(nGrpOffset+nBytesRead+60);
				wUnk2 = GET_U16(nCurrent+64);
				nOffset = GET_S32(nCurrent+66);
				memset(szDesc,0x0,sizeof(szDesc));
				memmove(szDesc,&OFFSET(nCurrent+70),
                	min(nOffset-6,sizeof(szDesc)-1));
			}*/
			DecodeRegionStr(nRegion,szRegion);
            strrtrim(szDesc);
			DecodeIdStr(nId,szId,0);


			fprintf(outfile,"\t<Vor lat=\"%s\" lon=\"%s\" alt=%s "
				"type=\"%s\"\n\t\tfrequency=\"%0.3lf\" magvar=\"%0.2lf\"",
				LatString(vorlat2lat(nLat),szLat),
				LatString(vorlon2lon(nLon),szLon), 
				AltString(nAlt,szAlt),
				vorTable[bType], (double)nFreq/1000000, MAGVAR(fMagVar));
			fprintf(outfile," range=%s region=\"%s\"\n\t\tident=\"%s\" name=",
				RangeString(fRange,szRange), szRegion, szId);
			
			PrintXmlString(szDesc,0);
			fprintf(outfile," ");
				

			if (!hasDme)
			{
				fprintf(outfile,"dme=\"FALSE\" dmeOnly=\"FALSE\" >\n");
			}
			else
			{
				switch (bFlags)		// gotta find something better
				{

				case 0x10:			// dme only
					fprintf(outfile,"dme=\"TRUE\" dmeOnly=\"TRUE\" >\n");
					break;
	
				case 0x11:			// vor-dme
				case 0x31:			
					fprintf(outfile,"dme=\"TRUE\" dmeOnly=\"FALSE\" >\n");
					break;
				}

				if (bFlags>=0x10)
					fprintf(outfile,"\t\t<Dme lat=\"%s\" lon=\"%s\" "
						"alt=%s range=%s />\n",
						LatString(vorlat2lat(nDmeLat),szLat),
						LatString(vorlon2lon(nDmeLon),szLon),
						AltString(nDmeAlt,szAlt),
						RangeString(fDmeRange,szRange));
			}
			fprintf(outfile, "\t</Vor>\n");
			fprintf(outfile, "\n");






        }
skip:
		nStart+=nLen;
    }
}














