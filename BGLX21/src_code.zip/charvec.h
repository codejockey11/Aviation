/*
 *   $Id: charvec.h,v 1.1 2007/09/23 23:29:19 Alessandro Exp $
 */
#ifndef charvec_h
#define charvec_h


typedef struct tag_char_entry_t
{
	int i;
	char *s;
} char_entry_t;

typedef enum 
{
	DUP_ACCEPT,
	DUP_IGNORE,
	DUP_ERROR
} dup_mode_t;

typedef enum
{
	ERR_DUPE,
	ERR_OUT_OF_BOUNDS,
	ERR_SORTED_LIST
} error_mode_t;

typedef struct tag_char_pool_t
{
	char_entry_t *ptr;
	int nCount;
	int nCapacity;
	int nSorted;
	dup_mode_t nDupMode;
	void (* lpOnChanging)(void);
	void (* lpOnChanged)(void);
	void (* lpOnError)(error_mode_t, int, int);
} char_pool_t;

extern char_pool_t *ChrPoolInit(void);
extern void ChrPoolFlush(char_pool_t *);
extern void ChrPoolFree(char_pool_t *);
extern int ChrPoolAdd(char_pool_t *, char *, int);
extern int ChrPoolFind(char_pool_t *, char *, int *);
extern void ChrPoolDelete(char_pool_t *, int);
extern void ChrPoolInsert(char_pool_t *, int, char *, int);
#ifdef NT_API_CALLS
extern HGLOBAL GlobalFreePtr(void *);
void *GlobalAllocPtr(DWORD);
void *GlobalReAllocPtr(void *, DWORD);
#endif


#endif
