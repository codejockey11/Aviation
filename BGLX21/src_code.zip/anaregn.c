/*
 *   $Id: anaregn.c,v 1.4 2005/10/20 10:57:11 Alessandro Exp $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: Region, country, etc, record analyzer $
 *
 *   $Log: anaregn.c,v $
 *   Revision 1.4  2005/10/20 10:57:11  alexanto
 *   Fixed routine to detect ICAO Ids
 *
 *   Revision 1.3  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.2  2004/02/12 15:17:07  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2004/02/04 14:07:48  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"


/*
 * Analyzes and decode Regions
 *
 * Parameters:
 * ptr - region_t record
 * nStartOffset - staring offset to decode from
 *
 * Return value:
 * none
 */
static void AnalyzeRegionNames(region_t *ptr, DWORD nStartOffset)
{
	int i,j;
	int nOffset;
	char *pszRegionName;

	// position to region offset
	nOffset = nStartOffset+ptr->nRegionPtr+(ptr->wRegionCount*4);

	j=0;
	for (i=0; i<ptr->wRegionCount; i++)
	{
		// get region name
		pszRegionName = PSZ_STR(nOffset+j);

		// stuff new name to array
		ChrPoolAdd(cregions,pszRegionName,nOffset+j);
		j+=strlen(pszRegionName)+1;
	}

}


/*
 * Analyzes and decode cities
 *
 * Parameters:
 * ptr - region_t record
 * nStartOffset - starting offset to decode from
 *
 * Return value:
 * none
 */
static void AnalyzeCityNames(region_t *ptr, DWORD nStartOffset)
{
	int i,j;
	int nOffset;
	char *pszCityName;

	// position to region offset
	nOffset = nStartOffset+ptr->nCityPtr+(ptr->wCityCount*4);

	j=0;
	for (i=0; i<ptr->wCityCount; i++)
	{
		// get city name
		pszCityName = PSZ_STR(nOffset+j);

		// stuff new name to array
		ChrPoolAdd(ccities,pszCityName,nOffset+j);
		j+=strlen(pszCityName)+1;
	}

}

/*
 * Analyzes and decode states
 *
 * Parameters:
 * ptr - region_t record
 * nStartOffset - starting offset to decode from
 *
 * Return value:
 * none
 */
static void AnalyzeStatesNames(region_t *ptr, DWORD nStartOffset)
{
	int i,j;
	int nOffset;
	char *pszStateName;

	// position to region offset
	nOffset = nStartOffset+ptr->nStatePtr+(ptr->wStateCount*4);

	j=0;
	for (i=0; i<ptr->wStateCount; i++)
	{
		// get city name
		pszStateName = PSZ_STR(nOffset+j);

		// stuff new name to array
		ChrPoolAdd(cstates,pszStateName,nOffset+j);
		j+=strlen(pszStateName)+1;
	}

}

/*
 * Analyzes and decode countries
 *
 * Parameters:
 * ptr - region_t record
 * nStartOffset - staring offset to decode from
 *
 * Return value:
 * none
 */
static void AnalyzeCountryNames(region_t *ptr, DWORD nStartOffset)
{
	int i,j;
	int nOffset;
	char *pszCountryName;

	// position to region offset
	nOffset = nStartOffset+ptr->nCountryPtr+(ptr->wCountryCount*4);

	j=0;
	for (i=0; i<ptr->wCountryCount; i++)
	{
		// get region name
		pszCountryName = PSZ_STR(nOffset+j);

		// stuff new name to array
		ChrPoolAdd(ccountries,pszCountryName,nOffset+j);
		j+=strlen(pszCountryName)+1;
	}

}

/*
 * Analyzes and decode airports
 *
 * Parameters:
 * ptr - region_t record
 * nStartOffset - starting offset to decode from
 *
 * Return value:
 * none
 */
static void AnalyzeAirportNames(region_t *ptr, DWORD nStartOffset)
{
	int i,j;
	int nOffset;
	char *pszAirportName;

	// position to region offset
	nOffset = nStartOffset+ptr->nAirportPtr+(ptr->wAirportCount*4);

	j=0;
	for (i=0; i<ptr->wAirportCount; i++)
	{
		// get city name
		pszAirportName = PSZ_STR(nOffset+j);

		// stuff new name to array
		ChrPoolAdd(cairports,pszAirportName,nOffset+j);
		j+=strlen(pszAirportName)+1;
	}

}


/*
 * Analyzes and decode Regions
 *
 * Parameters:
 * nGrpCount - number of Regions available in this group
 * nGrpOffset - offset to current Region chunk
 * nGrpLen - current chunk length
 *
 * Return value:
 * none
 */
void AnalyzeRegion(DWORD nGrpCount, DWORD nGrpOffset, DWORD nChunkLen)
{
	DWORD i,icaosize,nBytesRead = 0;
	int j;
	region_t ptr;

	for (i=0; i<nGrpCount; i++)			// group should be 1 anyway
	{
		if (nBytesRead>nChunkLen)		// we overrun
			break;

		ptr.wId = GET_U16(nGrpOffset+nBytesRead);
		ptr.wUnk1 = GET_U16(nGrpOffset+nBytesRead+2);
		ptr.wUnk2 = GET_U16(nGrpOffset+nBytesRead+4);
		ptr.wRegionCount = GET_U16(nGrpOffset+nBytesRead+6);
		ptr.wCountryCount = GET_U16(nGrpOffset+nBytesRead+8);
		ptr.wStateCount = GET_U16(nGrpOffset+nBytesRead+10);
		ptr.wCityCount = GET_U16(nGrpOffset+nBytesRead+12);
		ptr.wAirportCount = GET_U16(nGrpOffset+nBytesRead+14);
		ptr.wIcaoCount = GET_U16(nGrpOffset+nBytesRead+16);
		ptr.nRegionPtr = GET_S32(nGrpOffset+nBytesRead+18);
		ptr.nCountryPtr = GET_S32(nGrpOffset+nBytesRead+22);
		ptr.nStatePtr = GET_S32(nGrpOffset+nBytesRead+26);
		ptr.nCityPtr = GET_S32(nGrpOffset+nBytesRead+30);
		ptr.nAirportPtr = GET_S32(nGrpOffset+nBytesRead+34);
		ptr.nIcaoPtr = GET_S32(nGrpOffset+nBytesRead+38);
		AnalyzeRegionNames(&ptr, nGrpOffset+nBytesRead);
		AnalyzeCountryNames(&ptr, nGrpOffset+nBytesRead);
		AnalyzeStatesNames(&ptr, nGrpOffset+nBytesRead);
		AnalyzeCityNames(&ptr, nGrpOffset+nBytesRead);
		AnalyzeAirportNames(&ptr, nGrpOffset+nBytesRead);

		// allocate structure for ICAO IDs
		cicaos.cicao = (icaoid_t *)MALLOC(ptr.wIcaoCount*sizeof(icaoid_t));
		cicaos.nCount=ptr.wIcaoCount;
		// read icao entries
		for (j=0,icaosize=0; j<cicaos.nCount; j++,icaosize+=sizeof(icaoid_t))
		{
			int nOffset=nGrpOffset+nBytesRead+ptr.nIcaoPtr+icaosize;
			cicaos.cicao[j].bRegionIndex=GET_BYTE(nOffset);
			cicaos.cicao[j].bCountryIndex=GET_BYTE(nOffset+1);
			cicaos.cicao[j].bStateIndex=GET_BYTE(nOffset+2);
			cicaos.cicao[j].bUnk2=GET_BYTE(nOffset+3);
			cicaos.cicao[j].wCitiesIndex=GET_U16(nOffset+4);
			cicaos.cicao[j].wAirportIndex=GET_U16(nOffset+6);
			cicaos.cicao[j].nId=GET_U32(nOffset+8);
			memcpy(&cicaos.cicao[j].lpUnk,OFFSET(nOffset+12), 8);
		}
		nBytesRead+=sizeof(ptr);		// advance pointer
	}
}

