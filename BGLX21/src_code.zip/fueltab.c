/*
 *   $Id: fueltab.c,v 1.5 2005/10/12 17:26:03 Alessandro Exp $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: Fuel-type lookup table $
 *
 *   $Log: fueltab.c,v $
 *   Revision 1.5  2005/10/12 17:26:03  alexanto
 *   adjusted fuel tab to match for fs fuel types (hopefully)
 *
 *   Revision 1.4  2005/05/01 16:12:32  alexanto
 *   Added get_fuel_kind routine
 *
 *   Revision 1.3  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.2  2004/02/12 15:17:07  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2004/02/04 14:07:48  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"

/*fueltab_t fueltab[] =
{
	{ 0x40000000, "100",		FUELNO		},

	{ 0x40000001, "73",			FUELUNK		},
	{ 0x40000002, "73",			FUELPR		},
	{ 0x40000003, "73",			FUELYES		},

	{ 0x40000004, "87",			FUELUNK		},
	{ 0x40000008, "87",			FUELPR		},
	{ 0x4000000C, "87",			FUELYES		},

	{ 0x40000010, "100",		FUELUNK		},
	{ 0x40000020, "100",		FUELPR		},
	{ 0x40000030, "100",		FUELYES		},

	{ 0x40000040, "130",		FUELUNK		},
	{ 0x40000080, "130",		FUELPR		},
	{ 0x400000C0, "130",		FUELYES		},

	{ 0x40000100, "145",		FUELUNK		},
	{ 0x40000200, "145",		FUELPR		},
	{ 0x40000300, "145",		FUELYES		},

	{ 0x40004000, "MOGAS",		FUELUNK		},
	{ 0x40008000, "MOGAS",		FUELPR		},
	{ 0x4000C000, "MOGAS",		FUELYES		},

	{ 0x80000000, "JET",		FUELNO		},

	{ 0x80001000, "JET",		FUELUNK		},
	{ 0x80002000, "JET",		FUELPR		},
	{ 0x80003000, "JET",		FUELYES		},

	{ 0x80004000, "JETA",		FUELUNK		},
	{ 0x80008000, "JETA",		FUELPR		},
	{ 0x8000C000, "JETA",		FUELYES		},

	{ 0x80010000, "JETA1",		FUELUNK		},
	{ 0x80020000, "JETA1",		FUELPR		},
	{ 0x80030000, "JETA1",		FUELYES		},

	{ 0x80040000, "JETAP",		FUELUNK		},
	{ 0x80080000, "JETAP",		FUELPR		},
	{ 0x800C0000, "JETAP",		FUELYES		},

	{ 0x80100000, "JETB",		FUELUNK		},
	{ 0x80200000, "JETB",		FUELPR		},
	{ 0x80300000, "JETB",		FUELYES		},

	{ 0x80400000, "JET4",		FUELUNK		},
	{ 0x80800000, "JET4",		FUELPR		},
	{ 0x80C00000, "JET4",		FUELYES		},

	{ 0x81000000, "JET5",		FUELUNK		},
	{ 0x82000000, "JET5",		FUELPR		},
	{ 0x83000000, "JET5",		FUELYES		},

	{ 0x00000000, "JET",		FUELNO		}
};
*/
static const char *fuelkinds[] =
{"NO","UNKNOWN","PRIOR_REQUEST","YES"};

typedef struct
{
	int shift;
	char *kind;
} fueltypes_t;

static const fueltypes_t fueltypes[] =
{
	{  0, "73" },
	{  2, "87" },
	{  4, "100" },
	{  6, "130" },
	{  8, "145" },
	{ 10, "MOGAS" },
	{ 12, "JET" },
	{ 14, "JETA" },
	{ 16, "JETA1" },
	{ 18, "JETAP" },
	{ 20, "JETB" },
	{ 22, "JET4" },
	{ 24, "JET5" },
};

void get_fuel_kind(DWORD v)
{
	int i;
	for (i=0; i<sizeof(fueltypes)/sizeof(fueltypes_t); i++)
	{
		if ((v >> fueltypes[i].shift) & 3)
		{
			fprintf(outfile,"\t\t\t<Fuel type=\"%s\" availability=\"%s\" />\n",
					fueltypes[i].kind, fuelkinds[(v >> fueltypes[i].shift) & 3]);
		}
	}
}
