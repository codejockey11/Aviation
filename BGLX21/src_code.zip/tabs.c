/*
 *   $Id: tabs.c,v 1.9 2007/10/20 00:15:15 Alessandro Exp Alessandro $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: various lookup tables $
 *
 *   $Log: tabs.c,v $
 *   Revision 1.9  2007/10/20 00:15:15  Alessandro
 *   Minor changes
 *
 *   Revision 1.8  2007/10/02 21:46:38  alexanto
 *   Added FSX tables
 *
 *   Revision 1.7  2005/05/01 16:12:32  alexanto
 *   Removed unnecessary tabs
 *
 *   Revision 1.6  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.5  2004/02/25 13:47:04  alexanto
 *   Added a quick patch for GetRwyNumber when parameter is 0
 *
 *   Revision 1.4  2004/02/16 10:03:01  alexanto
 *   Added Boundary Table
 *
 *   Revision 1.3  2004/02/14 17:34:55  alexanto
 *   Added routine to decode runway numbers
 *
 *   Revision 1.2  2004/02/12 15:17:07  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2004/02/04 14:07:48  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"

// NDB table
const char *ndbTable[] =
{
	"COMPASS_POINT",
	"MH",
	"H",
	"HH"
};

// VOR table
const char *vorTable[] = 
{
	" ",
	"TERMINAL",
	"LOW",
	"HIGH",
	" ",
	"VOT"
};

// waypoint table
const char *wpTable[] =
{
	" ",
	"NAMED",
	"UNNAMED",
	"VOR",
	"NDB",
	"OFFROUTE",
	"IAF",
	"FAF"
};

// route table
const char *rteTable[] =
{
	" ",
	"VICTOR",
	"JET",
	"BOTH"
};

// comm type table
const char *commTable[] =
{
	" ",
	"ATIS",
	"MULTICOM",
	"UNICOM",
	"CTAF",
	"GROUND",
	"TOWER",
	"CLEARANCE",
	"APPROACH",
	"DEPARTURE",
	"CENTER",
	"FSS",
	"AWOS",
	"ASOS"
};

// complexity table
const char *cplxTable[] = 
{
	"VERY_SPARSE",
	"SPARSE",
	"NORMAL",
	"DENSE",
	"VERY_DENSE",
	"EXTREMELY_DENSE"
};

// weather type table
const char *weatherTable[] = 
{
	"RIDGE_LIFT",
	"NONDIRECTIONAL_TURBULENCE",
	"DIRECTIONAL_TURBULENCE",
	"THERMAL"
};


const char *truthTable[] = 
{
	"FALSE", "TRUE"
};

const char *YesNoTable[] = 
{
	"NO", "YES"
};

// runway designators
const char *lrcTable[] =
{
	"NONE",
	"LEFT",
	"RIGHT",
	"CENTER",
	"WATER",
	"A"
};

// runway surfaces
const char *surfacesTable[] =
{
	"CONCRETE",
	"GRASS",
	"WATER",
	"UNKNOWN",
	"ASPHALT",
	"UNKNOWN",
	"UNKNOWN",
	"CLAY",
	"SNOW",
	"ICE",
	"UNKNOWN",
	"UNKNOWN",
	"DIRT",
	"CORAL",
	"GRAVEL",
	"OIL_TREATED",
	"STEEL_MATS",
	"BITUMINOUS",
	"BRICK",
	"MACADAM",
	"PLANKS",
	"SAND",
	"SHALE",
	"TARMAC",
	"UNKNOWN"
};

// runway start types
const char *rwyStartTable[] =
{
	"RUNWAY",
	"RUNWAY",
	"WATER",
	"HELIPAD"
};

// VASI types
const char *vasiTable[] =
{
	"NONE",
	"VASI21",
	"VASI31",
	"VASI22",
	"VASI32",
	"VASI23",
	"VASI33",
	"PAPI2",
	"PAPI4",
	"TRICOLOR",
	"PVASI",
	"TVASI",
	"BALL",
	"APAP"
};

// approach types
const char *approachTable[] =
{
	"NONE",
	"GPS",
	"VOR",
	"NDB",
	"ILS",
	"LOCALIZER",
	"SDF",
	"LDA",
	"VORDME",
	"NDBDME",
	"RNAV",
	"LOCALIZER_BACKCOURSE"
};

// taxiway point types
const char *twpTable[] =
{
	"NORMAL",
	"HOLD_SHORT",
	"UNKNOWN",
	"ILS_HOLD_SHORT",
	"HOLD_SHORT_NO_DRAW",		// new in FSX
	"ILS_HOLD_SHORT_NO_DRAW",	// new in FSX
};

// taxiway path types
const char *twpathTable[] =
{
	"TAXI",			// 0x1
	"RUNWAY",		// 0x2
	"PARKING",		// 0x3
	"PATH",			// 0x4
	"CLOSED",		// 0x5
	"VEHICLE",		// 0x6 new in FSX
};

// helipad table
const char *heliTable[] =
{
	"NONE",
	"H",
	"SQUARE",
	"CIRCLE",
	"MEDICAL"
};


// parking table
const char *parkingTable[] =
{
	"NONE",
	"PARKING",
	"N_PARKING",
	"NE_PARKING",
	"E_PARKING",
	"SE_PARKING",
	"S_PARKING",
	"SW_PARKING",
	"W_PARKING",
	"NW_PARKING",
	"GATE",
	"DOCK"
};


// parking types table
const char *parkingTypeTable[] =
{
	"NONE",
	"RAMP_GA",
	"RAMP_GA_SMALL",
	"RAMP_GA_MEDIUM",
	"RAMP_GA_LARGE",
	"RAMP_CARGO",
	"RAMP_MIL_CARGO",
	"RAMP_MIL_COMBAT",
	"GATE_SMALL",
	"GATE_MEDIUM",
	"GATE_HEAVY",
	"DOCK_GA",
	"FUEL",
	"VEHICLE",
};

// leg types table
const char *legTypesTable[] = /* 0x1 based */
{	"AF", "CA", "CD", "CF", "CI", "CR", "DF", "FA", "FC", "FD", "FM",
	"HA", "HF", "HM", "IF", "PI", "RF", "TF", "VA", "VD", "VI", "VM",
	"VR"
};

// fix types table (0x2 based)
const char *fixTypeTable[] =
{
	"VOR",					// 2 - 0
	"NDB",					// 3 - 1
	"TERMINAL_NDB",			// 4 - 2
	"WAYPOINT",				// 5 - 3
	"TERMINAL_WAYPOINT",	// 6 - 4
	" ",					// 7 - 5
	"LOCALIZER",			// 8 - 6
	"RUNWAY"				// 9 - 7
};

// runway number table )0x25 based)
static char *rwyNumberTable[] =
{
	"NORTH",
	"NORTHEAST",
	"EAST",
	"SOUTHEAST",
	"SOUTH",
	"SOUTHWEST",
	"WEST",
	"NORTHWEST"
};

// boundary types table (0x0 based)
const char *boundaryTypeTable[] =
{
	"NONE",
	"CENTER",
	"CLASS_A",
	"CLASS_B",
	"CLASS_C",
	"CLASS_D",
	"CLASS_E",
	"CLASS_F",
	"CLASS_G",
	"TOWER",
	"CLEARANCE",
	"GROUND",
	"DEPARTURE",
	"APPROACH",
	"MOA",
	"RESTRICTED",
	"PROHIBITED",
	"WARNING",
	"ALERT",
	"DANGER",
	"NATIONAL_PARK",
	"MODEC",
	"RADAR",
	"TRAINING"
};

// boundary alt table (0x0 based)
const char *boundaryAltTypeTable[] =
{
	"UNKNOWN",
	"MEAN_SEA_LEVEL",
	"ABOVE_GROUND_LEVEL",
	"UNLIMITED"
};

static char rwy_buff[4];

char *GetRwyNumber(BYTE b)
{
    if (b==0x0)
    {
		memset(rwy_buff,0x0,sizeof(rwy_buff));
        sprintf(rwy_buff,"%0.2d", 36);
		return rwy_buff;
    }
    else if (b>=0x25)
		return rwyNumberTable[b-0x25];
	else
	{
		memset(rwy_buff,0x0,sizeof(rwy_buff));
		sprintf(rwy_buff,"%0.2d", b);
		return rwy_buff;
	}

}

int GetRwySurface(int i)
{
	return (i==SURFACE_UNKNOWN) ? 0x0018 : i;
}

const char *pushBackTable[] =
{
      "NONE",
      "LEFT",
      "RIGHT",
      "BOTH"
};
