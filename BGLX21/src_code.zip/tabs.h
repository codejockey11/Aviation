/*
 *   $Id: tabs.h,v 1.7 2007/10/02 21:48:38 alexanto Exp $
 */
#ifndef tabs_h
#define tabs_h

extern const char *cplxTable[];
extern const char *weatherTable[];
extern const char *ndbTable[];
extern const char *truthTable[];
extern const char *lrcTable[];
extern const char *surfacesTable[];
extern const char *rwyStartTable[];
extern const char *YesNoTable[];
extern const char *vasiTable[];
extern const char *approachTable[];
extern const char *twpTable[];
extern const char *heliTable[];
extern const char *twpathTable[];
extern const char *parkingTable[];
extern const char *parkingTypeTable[];
extern const char *commTable[];
extern const char *vorTable[];
extern const char *wpTable[];
extern const char *rteTable[];
extern const char *legTypesTable[];
extern const char *fixTypeTable[];
extern const char *boundaryTypeTable[];
extern const char *boundaryAltTypeTable[];
extern const char *pushBackTable[];

int GetRwySurface(int);
char *GetRwyNumber(BYTE);

#endif
