/*
 *   $Id: anatsign.c,v 1.5 2007/10/20 00:15:15 Alessandro Exp Alessandro $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: TaxwaySign record analyzer $
 *
 *   $Log: anatsign.c,v $
 *   Revision 1.5  2007/10/20 00:15:15  Alessandro
 *   Minor changes
 *
 *   Revision 1.4  2005/05/01 16:12:32  alexanto
 *   Some changes
 *
 *   Revision 1.3  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.2  2004/02/14 17:34:55  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2004/02/12 15:17:07  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"

/*
 * analyze and print taxiway sign
 *
 * Parameters:
 * nStart: offset of record
 *
 * Return:
 * none
 */
void AnalyzeTaxiSign(DWORD nStart)
{
	DWORD n;
	WORD wId = GET_U16(nStart);			// get block id
	WORD wLen = GET_U16(nStart+2);		// we have a 16-bit rec. length
	double fStartLon = fslon2lon(GET_S32(nStart+4));
	double fStartLat = fslat2lat(GET_S32(nStart+8));
	float fX, fY;
	char szLat[24], szLon[24];
	double fEndLat, fEndLon;
	char *pszLabel;
	BYTE bJust;
	int nCount, j;
	DWORD len;
	char buff[96];

	TRACE("AnalyzeTaxiSign\n");

	if (wId==SCNOBJ_TAXISIGN_FSX)
		nStart+=16;		/* Skip FSX InstanceId */
	nCount = GET_S32(nStart+28);
	n = nStart+32;						// position on start of entries
	//nEnd = nStart+wLen;				// mark end

	for (j=0; j<nCount; j++)
	{
		
		fX = GET_FLOAT(n);				// get X component
		fY = GET_FLOAT(n+4);			// get Y component
		if (!nTerse)
		{
			sprintf(buff,"TaxiwaySign x: %.4f, y: %.4f",
				fX, fY);
			PrintObjectSpec(buff,n);
		}
		
		n+=8;							// advance

		CartesianOffset(fStartLat,fStartLon,(double)fX,(double)fY,&fEndLat,&fEndLon);

		fprintf(outfile,"\t\t<TaxiwaySign lat=\"%s\" lon=\"%s\" ",
			LatString(fEndLat,szLat), LatString(fEndLon,szLon));

		fEndLat = (double)(GET_U16(n))*360/(double)65535;	// get heading
		n+=2;
		fprintf(outfile,"heading=\"%0.2lf\"\n", fEndLat);
		
		fprintf(outfile,"\t\t\tsize=\"SIZE%d\" ", GET_BYTE(n++)); // size
		bJust = GET_BYTE(n++);
		PRECONDITION((bJust>=1 && bJust<=2));
		
		fprintf(outfile,"justification=\"%s\" ",lrcTable[bJust]);

		pszLabel = PSZ_STR(n);								// label string

		fprintf(outfile,"label=");
		len=strlen(pszLabel);
		
		
		PrintXmlString(pszLabel,len);

		/*
		
		for (i=0; i<len; i++)
		{
			if ('<'==pszLabel[i])
				fprintf(outfile,"&lt;");
			else if ('>'==pszLabel[i])
				fprintf(outfile,"&gt;");
			else
				fprintf(outfile,"%c",pszLabel[i]);
		}
*/

		fprintf(outfile," />\n");

		n+=len+1;

		// the label string length, including the null terminator
		// must be a multiple of two
		while (n % 2) n++;
	}
	
}
