/*
 *   $Id: analegs.c,v 1.5 2004/04/08 11:57:15 Alessandro Exp $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: analyze legs under approaches (splitted from anapt.c) $
 *
 *   $Log: analegs.c,v $
 *   Revision 1.5  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.4  2004/02/25 13:47:04  alexanto
 *   Stripped unnecessary parameters from leg type CI
 *
 *   Revision 1.3  2004/02/19 17:51:07  alexanto
 *   Fixed parameters for legs type VI
 *
 *   Revision 1.2  2004/02/14 17:34:55  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2004/02/12 15:17:07  alexanto
 *   Initial revision
 *
 *
 */
#include "bglxml.h"

/*
 * leg parameters bits
 */

#define BIT_FLYOVER				0x0001
#define BIT_FIXTYPE				0x0002
#define BIT_FIXREGION			0x0004

#define BIT_FIXIDENT			0x0008
#define BIT_TURNDIRECTION		0x0010
#define BIT_RECOMMENDEDTYPE		0x0020

#define BIT_RECOMMENDEDREGION	0x0040
#define BIT_RECOMMENDEDIDENT	0x0080
#define BIT_THETA				0x0100

#define BIT_RHO					0x0200
#define BIT_TRUE_OR_MAG_COURSE	0x0400
#define BIT_TIME_OR_DISTANCE	0x0800

#define BIT_ALTITUDEDESCRIPTOR	0x1000
#define BIT_ALTITUDE1			0x2000
#define BIT_ALTITUDE2			0x4000

#define BIT_ALL BIT_FLYOVER | BIT_FIXTYPE | BIT_FIXREGION | \
 BIT_FIXIDENT | BIT_TURNDIRECTION | BIT_RECOMMENDEDTYPE | \
 BIT_RECOMMENDEDREGION | BIT_RECOMMENDEDIDENT | BIT_THETA | \
 BIT_RHO | BIT_TRUE_OR_MAG_COURSE | BIT_TIME_OR_DISTANCE | \
 BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1 | BIT_ALTITUDE2
 
/*
 * leg parameter entry
 */ 
struct leg_param_t
{
	BYTE bType;					// leg type
	WORD wBits;					// leg bits
};



/*
 * parameter lookup table - to help choose which parameters to print
 */
struct leg_param_t leg_params[] =
{
	{ LEG_TYPE_AF,	BIT_FIXTYPE | BIT_FIXREGION | BIT_FIXIDENT | BIT_TURNDIRECTION |
					BIT_RECOMMENDEDTYPE | BIT_RECOMMENDEDREGION | BIT_RECOMMENDEDIDENT |
					BIT_THETA | BIT_RHO | BIT_TRUE_OR_MAG_COURSE |
					BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1 | BIT_ALTITUDE2	},

	{ LEG_TYPE_CA,	BIT_TURNDIRECTION | BIT_TRUE_OR_MAG_COURSE |
					BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1	},

	{ LEG_TYPE_CD,	BIT_RECOMMENDEDTYPE | BIT_RECOMMENDEDREGION | BIT_RECOMMENDEDIDENT |
					BIT_TURNDIRECTION | BIT_TRUE_OR_MAG_COURSE |
					BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1 | BIT_TIME_OR_DISTANCE	},

	{ LEG_TYPE_CI,	BIT_FLYOVER | BIT_TURNDIRECTION | BIT_TRUE_OR_MAG_COURSE |
					BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1 | BIT_ALTITUDE2 | 
					BIT_TIME_OR_DISTANCE	},

	{ LEG_TYPE_CR,	BIT_FLYOVER | BIT_RECOMMENDEDTYPE | BIT_RECOMMENDEDREGION | 
					BIT_RECOMMENDEDIDENT | BIT_THETA | BIT_TRUE_OR_MAG_COURSE |
					BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1 | BIT_ALTITUDE2 	},


	{ LEG_TYPE_DF,	BIT_FLYOVER | BIT_FIXTYPE | BIT_FIXREGION | BIT_FIXIDENT |
					BIT_RECOMMENDEDTYPE | BIT_RECOMMENDEDREGION | BIT_RECOMMENDEDIDENT | 
					BIT_TURNDIRECTION | BIT_THETA | BIT_RHO |
					BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1 | BIT_ALTITUDE2 },

	{ LEG_TYPE_FD,	BIT_ALL },

	{ LEG_TYPE_FM,	BIT_TURNDIRECTION | BIT_FIXTYPE | BIT_FIXREGION | BIT_FIXIDENT | 
					BIT_RECOMMENDEDTYPE | BIT_RECOMMENDEDREGION | BIT_RECOMMENDEDIDENT | 
					BIT_THETA | BIT_RHO | BIT_TRUE_OR_MAG_COURSE |
					BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1 },

	{ LEG_TYPE_HA,	BIT_TURNDIRECTION | BIT_FIXTYPE | BIT_FIXREGION | BIT_FIXIDENT | 
					BIT_RECOMMENDEDTYPE | BIT_RECOMMENDEDREGION | BIT_RECOMMENDEDIDENT | 
					BIT_THETA | BIT_RHO | BIT_TRUE_OR_MAG_COURSE | BIT_TIME_OR_DISTANCE |
					BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1 },

	{ LEG_TYPE_HF,	BIT_TURNDIRECTION | BIT_FIXTYPE | BIT_FIXREGION | BIT_FIXIDENT | 
					BIT_RECOMMENDEDTYPE | BIT_RECOMMENDEDREGION | BIT_RECOMMENDEDIDENT | 
					BIT_THETA | BIT_RHO | BIT_TRUE_OR_MAG_COURSE | BIT_TIME_OR_DISTANCE |
					BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1 },

	{ LEG_TYPE_HM,	BIT_TURNDIRECTION | BIT_FIXTYPE | BIT_FIXREGION | BIT_FIXIDENT | 
					BIT_RECOMMENDEDTYPE | BIT_RECOMMENDEDREGION | BIT_RECOMMENDEDIDENT | 
					BIT_THETA | BIT_RHO | BIT_TRUE_OR_MAG_COURSE | BIT_TIME_OR_DISTANCE |
					BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1 },

	{ LEG_TYPE_IF,	BIT_FIXTYPE | BIT_FIXREGION | BIT_FIXIDENT | 
					BIT_RECOMMENDEDTYPE | BIT_RECOMMENDEDREGION | BIT_RECOMMENDEDIDENT | 
					BIT_THETA | BIT_RHO | BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1 |
					BIT_ALTITUDE2 },

	{ LEG_TYPE_PI,	BIT_TURNDIRECTION | BIT_FIXTYPE | BIT_FIXREGION | BIT_FIXIDENT | 
					BIT_RECOMMENDEDTYPE | BIT_RECOMMENDEDREGION | BIT_RECOMMENDEDIDENT | 
					BIT_THETA | BIT_RHO | BIT_TRUE_OR_MAG_COURSE | BIT_TIME_OR_DISTANCE |
					BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1 },

	{ LEG_TYPE_RF,	BIT_FLYOVER | BIT_TURNDIRECTION | BIT_FIXTYPE | BIT_FIXREGION | BIT_FIXIDENT | 
					BIT_RECOMMENDEDTYPE | BIT_RECOMMENDEDREGION | BIT_RECOMMENDEDIDENT | 
					BIT_THETA | BIT_TRUE_OR_MAG_COURSE | BIT_TIME_OR_DISTANCE |
					BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1 | BIT_ALTITUDE2 },

	{ LEG_TYPE_TF,	BIT_ALL },

	{ LEG_TYPE_VA,	BIT_TURNDIRECTION | BIT_TRUE_OR_MAG_COURSE | BIT_ALTITUDEDESCRIPTOR | 
					BIT_ALTITUDE1 },

	{ LEG_TYPE_VD,	BIT_TURNDIRECTION | BIT_RECOMMENDEDTYPE | BIT_RECOMMENDEDREGION | 
					BIT_RECOMMENDEDIDENT | BIT_TRUE_OR_MAG_COURSE | BIT_TIME_OR_DISTANCE |
					BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1 | BIT_ALTITUDE2 },

	{ LEG_TYPE_VI,	BIT_TRUE_OR_MAG_COURSE },

    { LEG_TYPE_VM,  /*BIT_TURNDIRECTION | BIT_FIXTYPE | BIT_FIXREGION | BIT_FIXIDENT |*/ 
                    BIT_TRUE_OR_MAG_COURSE /* | BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1*/ },

	{ LEG_TYPE_VR,	BIT_FLYOVER | BIT_TURNDIRECTION | BIT_RECOMMENDEDTYPE | BIT_RECOMMENDEDREGION | 
					BIT_RECOMMENDEDIDENT | BIT_THETA | BIT_TRUE_OR_MAG_COURSE |
					BIT_ALTITUDEDESCRIPTOR | BIT_ALTITUDE1 | BIT_ALTITUDE2 },
	{0,0}
};

static const char *szDtor = "A+-B";

/*
 * forward declarations
 */
static void AnalyzeApproachLegs(DWORD,DWORD,char *);
static void AnalyzeLeg(DWORD,WORD,DWORD);
static void AnalyzeTransition(DWORD,DWORD);


/*
 * analyze contents of an approach record
 *
 * Parameters:
 * nStart - offset within bgl file to start analyzing
 * nEnd - end of contents chunk
 *
 * Return value:
 * none
 */
void AnalyzeApproachContents(DWORD nStart, DWORD nEnd, DWORD nIcaoId)
{

	WORD wId;
	DWORD nLen;

	while (nStart<nEnd)
	{
		wId = GET_U16(nStart);			// get record ID
		nLen = GET_U32(nStart+2);		// get record len
		
		switch (wId)					
		{
		case 0x002C:					// transition
			AnalyzeTransition(nStart,nIcaoId);
			break;
		case 0x002D:					// approachLegs
			AnalyzeApproachLegs(nStart,nIcaoId,"ApproachLegs");
			break;
		case 0x002E:					// missedapproachLegs
			AnalyzeApproachLegs(nStart,nIcaoId,"MissedApproachLegs");
			break;
		}

		nStart+=nLen;					// advance file pointer

	}
}



/*
 * analyze approach legs
 *
 * Parameters:
 * nStart - offset within bgl file to start analyzing
 *
 * Return value:
 * none
 */
static void AnalyzeApproachLegs(DWORD nStart, DWORD nIcaoId, char *pszName)
{
	approach_legs_t legs;
	legs.wId = GET_U16(nStart);			// get record ID
	legs.nLen = GET_U32(nStart+2);			// get record len
	legs.wLegsCount = GET_U16(nStart+6);	// get entry count
	fprintf(outfile,"\t\t\t<%s>\n",pszName);
	AnalyzeLeg(nStart+8,legs.wLegsCount, nIcaoId);
	fprintf(outfile,"\t\t\t</%s>\n",pszName);
}

/*
 * analyze leg entries
 *
 * Parameters:
 * nStart - offset within bgl file to start analyzing
 * wCount - count of legs to analyze
 * Return value:
 * none
 */
static void AnalyzeLeg(DWORD nStart, WORD wCount, DWORD nIcaoId)
{
	WORD i;
	int j;
	DWORD n;
	leg_t leg;
	BYTE b;
	char szAlt[24];
	char szRange[24];
	char szId[6];
	struct leg_param_t *ptr;
	
	for (i=0, n = nStart; i<wCount; i++, n+=44 /* size of leg */)
	{
		leg.bLegType = GET_BYTE(n);
		leg.bAltitudeDtor = GET_BYTE(n+1);
		leg.bTurnDirection = GET_BYTE(n+2);
		leg.bFlags = GET_BYTE(n+3);
		leg.nFixId = GET_U32(n+4);
		leg.nFixRegion = GET_U32(n+8);
		leg.nRecomId = GET_U32(n+12);
		leg.nRecomRegion = GET_U32(n+16);
		leg.fTheta = GET_FLOAT(n+20);
		leg.fRho = GET_FLOAT(n+24);
		leg.fTrueCorse = GET_FLOAT(n+28);
		leg.fDistance = GET_FLOAT(n+32);
		leg.fAltitude1 = GET_FLOAT(n+36);
		leg.fAltitude2 = GET_FLOAT(n+40);
		
		j = 0;
		ptr=NULL;
		while (leg_params[j].bType>0)	// browse legs table
		{
			if (leg_params[j].bType==leg.bLegType)
			{
				ptr = &leg_params[j];	// found the leg
				break;
			}
			j++;
		}
		
		if (ptr)						// if leg found, print it
		{
			fprintf(outfile,"\t\t\t\t<Leg type=\"%s\"",
				legTypesTable[leg.bLegType-1]);
			
			// print parameters according to which table bit is set
			if (ptr->wBits & BIT_ALTITUDE1)
			{
				fprintf(outfile,"\n\t\t\t\t\taltitude1=%s",
					DimString(leg.fAltitude1,szAlt));
			}

			if (ptr->wBits & BIT_ALTITUDE2)
			{
				fprintf(outfile,"\n\t\t\t\t\taltitude2=%s",
					DimString(leg.fAltitude2,szAlt));
			}
			
			if (ptr->wBits & BIT_ALTITUDEDESCRIPTOR)
			{
				if (leg.bAltitudeDtor>0 && leg.bAltitudeDtor<=LEG_ALT_DESCRIPTOR_B)
					fprintf(outfile,"\n\t\t\t\t\taltitudeDescriptor=\"%c\"",
					szDtor[leg.bAltitudeDtor-1]);
			}
			
			if (ptr->wBits & BIT_THETA)
			{
				fprintf(outfile,"\n\t\t\t\t\ttheta=\"%0.4lf\"",
						(double)leg.fTheta );
			}
			
			if (ptr->wBits & BIT_RHO)
			{
				fprintf(outfile,"\n\t\t\t\t\trho=\"%0.4lf\"",
						(double)leg.fRho );
			}
			
			if (ptr->wBits & BIT_TRUE_OR_MAG_COURSE)
			{
				fprintf(outfile,"\n\t\t\t\t\t");
				if (leg.bFlags & LEG_TRUE_COURSE_VALID)
					fprintf(outfile,"trueCourse");
				else
					fprintf(outfile,"magneticCourse");
				fprintf(outfile,"=\"%0.2lf\"",
					(double)leg.fTrueCorse);
			}
			if (ptr->wBits & BIT_TIME_OR_DISTANCE)
			{
				fprintf(outfile,"\n\t\t\t\t\t");
				if (leg.bFlags & LEG_TIME_VALID)
					fprintf(outfile,"time=\"%.2lf\"",
						(double)leg.fDistance);
				else
					fprintf(outfile,"distance=%s",
						RangeString(leg.fDistance,szRange));

			}

			if (ptr->wBits & BIT_FLYOVER)
			{
				fprintf(outfile,"\n\t\t\t\t\t");
				fprintf(outfile,"flyOver=\"%s\"",
					(leg.bFlags & LEG_FLY_OVER) ?
						YesNoTable[1] : YesNoTable[0]);
			}

			if (ptr->wBits & BIT_TURNDIRECTION)
			{
				fprintf(outfile,"\n\t\t\t\t\t");
				fprintf(outfile,"turnDirection=\"");
				switch (leg.bTurnDirection)
				{
				case LEG_TURN_DIRECTION_L:
					fprintf(outfile,"L\"");
					break;
				case LEG_TURN_DIRECTION_R:
					fprintf(outfile,"R\"");
					break;
				case LEG_TURN_DIRECTION_E:
					fprintf(outfile,"E\"");
					break;
				default:	// supply a default value if off bounds
					fprintf(outfile,"E\"");
					break;
				}

			}
			
			if (ptr->wBits & BIT_FIXTYPE)
			{
				fprintf(outfile,"\n\t\t\t\t\tfixType=\"");

				b = GET_BYTE(n+4) & 0xf;
				if (b>=FIX_TYPE_VOR && b<=FIX_TYPE_RUNWAY)
				{
					fprintf(outfile,"%s",fixTypeTable[b-2]);
				}
				else
					fprintf(outfile,"%s",fixTypeTable[4]);	// default to terminal_wpt

				fprintf(outfile,"\"");
			}

			if (ptr->wBits & BIT_FIXIDENT)
			{

				fprintf(outfile,"\n\t\t\t\t\tfixIdent=\"");
				b = GET_BYTE(n+4) & 0xf;
				switch (b)
				{
				case FIX_TYPE_VOR:
					DecodeIdStr(leg.nFixId,szId,FIX_TYPE_VOR + 0x40);
					break;
				case FIX_TYPE_NDB:
					DecodeIdStr(leg.nFixId,szId,FIX_TYPE_NDB + 0x40);
					break;
				case FIX_TYPE_TERMINAL_NDB:
					DecodeIdStr(leg.nFixId,szId,FIX_TYPE_TERMINAL_NDB + 0x40);
					break;
				case FIX_TYPE_WAYPOINT:
					DecodeIdStr(leg.nFixId,szId,FIX_TYPE_WAYPOINT + 0x40);
					break;
				case FIX_TYPE_TERMINAL_WAYPOINT:
					DecodeIdStr(leg.nFixId,szId,FIX_TYPE_TERMINAL_WAYPOINT + 0x40);
					break;
				case FIX_TYPE_LOCALIZER:
					DecodeIdStr(leg.nFixId,szId,FIX_TYPE_LOCALIZER + 0x40);
					break;
				case FIX_TYPE_RUNWAY:
					DecodeIdStr(leg.nFixId,szId,FIX_TYPE_RUNWAY + 0x40);
					break;
				default:
					// decode id - whether we found the type or not
					DecodeIdStr(leg.nFixId,szId,0x40); 
					break;
				}
				fprintf(outfile,"%s\"",szId);

			}

			if (ptr->wBits & BIT_FIXREGION)
			{
				DecodeRegionStr(leg.nFixRegion,szId);
				fprintf(outfile,"\n\t\t\t\t\tfixRegion=\"%s\"",
					szId);
			}

			if (ptr->wBits & BIT_RECOMMENDEDTYPE)
			{

				fprintf(outfile,"\n\t\t\t\t\trecommendedType=\"");

				b = GET_BYTE(n+12) & 0xf;
				if (b>=FIX_TYPE_VOR && b<=FIX_TYPE_RUNWAY)
				{
					fprintf(outfile,"%s",fixTypeTable[b-2]);
				}
				else
					fprintf(outfile,"%s",fixTypeTable[4]);	// default to terminal_wpt

				fprintf(outfile,"\"");

			}

			if (ptr->wBits & BIT_RECOMMENDEDIDENT)
			{

				b = GET_BYTE(n+12) & 0xf;
				switch (b)
				{
				case FIX_TYPE_VOR:
					DecodeIdStr(leg.nRecomId,szId,FIX_TYPE_VOR + 0x40);
					break;
				case FIX_TYPE_NDB:
					DecodeIdStr(leg.nRecomId,szId,FIX_TYPE_NDB + 0x40);
					break;
				case FIX_TYPE_TERMINAL_NDB:
					DecodeIdStr(leg.nRecomId,szId,FIX_TYPE_TERMINAL_NDB + 0x40);
					break;
				case FIX_TYPE_WAYPOINT:
					DecodeIdStr(leg.nRecomId,szId,FIX_TYPE_WAYPOINT + 0x40);
					break;
				case FIX_TYPE_TERMINAL_WAYPOINT:
					DecodeIdStr(leg.nRecomId,szId,FIX_TYPE_TERMINAL_WAYPOINT + 0x40);
					break;
				case FIX_TYPE_LOCALIZER:
					DecodeIdStr(leg.nRecomId,szId,FIX_TYPE_LOCALIZER + 0x40);
					break;
				case FIX_TYPE_RUNWAY:
					DecodeIdStr(leg.nRecomId,szId,FIX_TYPE_RUNWAY + 0x40);
					break;
				default:
					// decode id - whether we found the type or not
					DecodeIdStr(leg.nFixId,szId,0x40); 
					break;
				}
				if (*szId)
				{
					fprintf(outfile,"\n\t\t\t\t\trecommendedIdent=\"");
					fprintf(outfile,"%s\"",szId);
				}

			}

			if (ptr->wBits & BIT_RECOMMENDEDREGION)
			{
				DecodeRegionStr(leg.nRecomRegion,szId);
				if (*szId)
					fprintf(outfile,"\n\t\t\t\t\trecommendedRegion=\"%s\"",
						szId);
			}
			fprintf(outfile," />\n");
		}
	}
}

/*
 * analyze transitions
 *
 * Parameters:
 * nStart - offset within bgl file to start analyzing
 * nIcaoId - ICAO ID of airport this entry belongs to
 * Return value:
 * none
 */
static void AnalyzeTransition(DWORD nStart,DWORD nIcaoId)
{
	transition_t t;
	DWORD nRecEnd = 20;
	char szId[6];
	char szRegion[4];
	char szAlt[24];
	DWORD start, end;
	WORD wId;
	DWORD nLen;
	BYTE b;
	t.wId = GET_U16(nStart);
	t.nLen = GET_U32(nStart+2);
	t.bType = GET_BYTE(nStart+6);
	t.bLegCount = GET_BYTE(nStart+7);
	t.nId = GET_U32(nStart+8);
	t.nRegion = GET_U32(nStart+12);
	t.fAltitude = GET_FLOAT(nStart+16);

	
	b = GET_BYTE(nStart+8) & 0xf;
	switch (b)
	{
	case FIX_TYPE_VOR:
		DecodeIdStr(t.nId,szId,FIX_TYPE_VOR + 0x40);
		break;
	case FIX_TYPE_NDB:
		DecodeIdStr(t.nId,szId,FIX_TYPE_NDB + 0x40);
		break;
	case FIX_TYPE_TERMINAL_NDB:
		DecodeIdStr(t.nId,szId,FIX_TYPE_TERMINAL_NDB + 0x40);
		break;
	case FIX_TYPE_WAYPOINT:
		DecodeIdStr(t.nId,szId,FIX_TYPE_WAYPOINT + 0x40);
		break;
	case FIX_TYPE_TERMINAL_WAYPOINT:
		DecodeIdStr(t.nId,szId,FIX_TYPE_TERMINAL_WAYPOINT + 0x40);
		break;
	case FIX_TYPE_LOCALIZER:
		DecodeIdStr(t.nId,szId,FIX_TYPE_LOCALIZER + 0x40);
		break;
	case FIX_TYPE_RUNWAY:
		DecodeIdStr(t.nId,szId,FIX_TYPE_RUNWAY + 0x40);
		break;
	default:
		// decode id - whether we found the type or not
		DecodeIdStr(t.nId,szId,0x40); 
		break;
	}	
	DecodeRegionStr(t.nRegion,szRegion);

	fprintf(outfile,"\t\t\t<Transition transitionType=\"%s\" fixType=\"%s\" "
			" fixRegion=\"%s\"\n\t\t\t\tfixIdent=\"%s\" altitude=%s>\n",
			t.bType==TRANSITION_TYPE_DME ? "DME" : "FULL",
			(b>=FIX_TYPE_VOR && b<=FIX_TYPE_RUNWAY) ? fixTypeTable[b-2] :
			fixTypeTable[4], szRegion, szId,
				DimString(t.fAltitude,szAlt));


	if (t.bType==TRANSITION_TYPE_DME)
	{										// read additional info for dmearc
		t.nDmeId = GET_U32(nStart+20);
		t.nDmeRegion = GET_U32(nStart+24);
		t.nRadial  = GET_U32(nStart+28);
		t.fDmeDistance = GET_FLOAT(nStart+32);
		nRecEnd = 36;
		DecodeRegionStr(t.nDmeRegion,szRegion);
		DecodeIdStr(t.nDmeId,szId,0x42);
		fprintf(outfile,"\t\t\t\t<DmeArc radial=\"%ld\" distance=%s dmeRegion=\"%s\"\n"
			"\t\t\t\t\tdmeIdent=\"%s\" />\n",
			t.nRadial, RangeString(t.fDmeDistance,szAlt),
			szRegion, szId);
	}

	start = nStart + nRecEnd;
	end = nStart + t.nLen/* - nRecEnd*/;

	while (start<end)
	{
		wId = GET_U16(start);
		PRECONDITION(start+2<=map.dwSize-4);
		nLen = GET_U32(start+2);
		switch (wId)
		{
		case 0x2F:			// missedapproachlegs
			AnalyzeApproachLegs(start, nIcaoId, "TransitionLegs");
		}
		start+=nLen;
	}
	fprintf(outfile,"\t\t\t</Transition>\n");
}
