/*
 *   $Id: anapt.c,v 1.14 2007/10/20 00:15:15 Alessandro Exp Alessandro $
 *
 *   BGL to XML converter for FSX
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: Airport record analyzer $
 *
 *   $Log: anapt.c,v $
 *   Revision 1.14  2007/10/20 00:15:15  Alessandro
 *   Added Boundary and Apron Fences decoding
 *
 *   Revision 1.13  2007/10/02 21:46:38  alexanto
 *   Added decoding of fences
 *
 *   Revision 1.12  2007/09/23 23:22:16  Alessandro
 *   Support for FSX (courtesy of Jonathan Harris)
 *
 *   Revision 1.12  2005/10/20 10:57:11  alexanto
 *   Modified tower decode function
 *
 *   Revision 1.11  2005/10/20 10:57:11  alexanto
 *   Modified tower decode function
 *
 *   Revision 1.10  2005/10/12 17:26:03  alexanto
 *   some changes
 *
 *   Revision 1.9  2005/05/01 16:12:32  alexanto
 *   Modified the code to decompose fuel bitmask
 *
 *   Revision 1.8  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.7  2004/03/12 15:19:59  alexanto
 *   Added: XML Transformation to cities, states, etc.
 *
 *   Revision 1.6  2004/02/25 13:47:04  alexanto
 *   Added description print with XML translation
 *   Added decoding of Tower chunks
 *
 *   Revision 1.5  2004/02/19 17:51:07  alexanto
 *   Fixed "doubled" ILS matter
 *
 *   Revision 1.4  2004/02/16 10:03:01  alexanto
 *   Changed to increase compatibility with Watcom C++
 *
 *   Revision 1.3  2004/02/14 17:34:55  alexanto
 *   Fixed Typo in Taxiwaypath (leftEdgeLighted==)
 *   Fixed mess with ApronEdgeLights ending tags
 *   Implemented decoding of Services and DeleteFrequency
 *   Modified runway code to properly decode number (NORTH,EAST...)
 *   Fixed TaxiwayParking decode routine
 *
 *   Revision 1.2  2004/02/12 15:17:07  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2004/02/04 14:07:48  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"

typedef struct
{
	char *ptr;
	char *kind;
} OrBpTsEntry;

static OrBpTsEntry OrBpTsTable[] =
{
	{"OffsetThreshold","PRIMARY"},
	{"OffsetThreshold","SECONDARY"},
	{"BlastPad","PRIMARY"},
	{"BlastPad","SECONDARY"},
	{"Overrun","PRIMARY"},
	{"Overrun","SECONDARY"},
};

/*
// return the difference from first course to second course,
// wrapping at 360 degrees, clockwise is positive
// (courtesy of Ted Wright - nav@consequential.org)
static double courseDiff(double c1, double c2)
{
	double d = c2 - c1;

    TRACE("courseDiff\n");

	if (fabs(d) < 180.0)
		return d;
	else if ((d == 180.0) || (d == -180.0))
		return 180.0;
	else if (d > 180.0)
		return 360.0 - d;
	else // if (d < -180.0)
		return -360.0 - d;
}
*/

/*
 * print terminal waypoint info
 *
 * Parameters:
 * n - offset this waypoint is
 *
 * Return value:
 * none
 */
static void PrintWaypointInfo(DWORD n)
{
	WORD wType = GET_U16(n);
	DWORD nLen = GET_U32(n+2);
	BYTE bWptKind = GET_BYTE(n+6);
	BYTE bHasRoute = GET_BYTE(n+7);
	int nLon = GET_S32(n+8);
	int nLat = GET_S32(n+12);
	float fMagVar = GET_FLOAT(n+16);
	DWORD nId = GET_U32(n+20);
	DWORD nRegion = GET_U32(n+24);
	
	char szRegion[4];
	char szId[8], szLat[24], szLon[24];


	DecodeRegionStr(nRegion, szRegion);
	DecodeIdStr(nId, szId, 0x45);


/*		if (bHasRoute)		// read additional info for routes
		{
			bType = GET_BYTE(n+28);
			memcpy(szName, OFFSET(n+29),sizeof(szName));
			nNextId = GET_U32(n+29+sizeof(szName));
			nNextRegion = GET_U32(n+33+sizeof(szName));
			fNextAltitude = GET_FLOAT(n+37+sizeof(szName));
			nPrevId = GET_U32(n+41+sizeof(szName));
			nPrevRegion = GET_S32(n+45+sizeof(szName));
			fPrevAltitude = GET_FLOAT(n+49+sizeof(szName));
		}*/
	if (!nTerse)
		PrintObjectSpec("Waypoint",n);

		
	fprintf(outfile,"\t\t<Waypoint lat=\"%s\" lon=\"%s\" "
			"waypointType=\"%s\"\n\t\t\tmagvar=\"%0.2lf\" "
			"waypointRegion=\"%s\" waypointIdent=\"%s\"",
			LatString(ndblat2lat(nLat),szLat),
			LatString(ndblon2lon(nLon),szLon),
			wpTable[bWptKind],
			MAGVAR(fMagVar), szRegion, szId );

/*		if (bHasRoute)
		{
			DecodeRegionStr(nNextRegion,szNextRegion);
			DecodeRegionStr(nPrevRegion,szPrevRegion);
			DecodeIdStr(nNextId, szNextId,0x45);
			DecodeIdStr(nPrevId, szPrevId,0x45);

			fprintf(outfile," >\n");
			fprintf(outfile,"\t\t<Route routeType=\"%s\" name=\"%s\" >\n",
				rteTable[bType], szName);				
			
			if (nPrevId!=0)	// if we have a valid previous route
			{
				fprintf(outfile,"\t\t\t<Previous waypointType=\"UNNAMED\" waypointRegion=\"%s\"\n"
					"\t\t\t\twaypointIdent=\"%s\" altitudeMinimum=\"%0.3lf\" />\n",
					szPrevRegion, szPrevId, fPrevAltitude);
			}
			if (nNextId!=0)	// if we have a valid next route
			{
				fprintf(outfile,"\t\t\t<Next waypointType=\"UNNAMED\" waypointRegion=\"%s\"\n"
					"\t\t\t\twaypointIdent=\"%s\" altitudeMinimum=\"%0.3lf\" />\n",
					szNextRegion, szNextId, fNextAltitude);
			}

			fprintf(outfile,"\t\t</Route>\n\t</Waypoint>\n");

		}
		else*/
	fprintf(outfile," />\n");



}


/*
 * search for terminal waypoints
 *
 * Parameters:
 * none
 *
 * Return value:
 * none
 */
static void LookUpWaypoints(char *szIcao)
{
	intlist_t *ptr;
	char szId[8];

	for (ptr=lpWpt; ptr; ptr=ptr->next)
	{
		DecodeIdStr(ptr->nParam,szId,0);
		if (0==strcmp(szId,szIcao))
		{
			/*fprintf(outfile,"\t\t<!-- Waypoint %s at %d -->\n",
				szId,ptr->nOffset);*/
			PrintWaypointInfo(ptr->nOffset);
			
		}

	}
}


#define BIT_ILS BIT0
#define BIT_GS BIT1
#define BIT_DME BIT2
#define BIT_BK BIT3
#define BIT_BEAM BIT4

/*
 * print ILS to outfile
 *
 * Parameters:
 * nOffset - offset within bgl file this ils is at
 *
 * Return value:
 * none
 */
static void PrintIlsInfo(DWORD nOffset)
{
	ils_t ils;
	ilsgs_t  ilsgs;
	ilsdme_t ilsdme;
	ils_beam_t ilsbeam;
	char szId[6], szName[48];
	char szLat[24], szLon[24];
	char szAlt[24], szRange[24];
	DWORD nStart, nLen;
	WORD wId;
	DWORD bFlags2 = BIT_ILS;

	DWORD nChunkLength;

	memset(&ils,0x0,sizeof(ils_t));
	memset(&ilsgs,0x0,sizeof(ilsgs_t));
	memset(&ilsdme,0x0,sizeof(ilsdme_t));
	memset(&ilsbeam,0x0,sizeof(ils_beam_t));
	memset(szName,0x0,sizeof(szName));



    TRACE("PrintIlsInfo\n");

	ils.wId = GET_U16(nOffset);
	ils.nLen = GET_U32(nOffset+2);
	ils.bType = map.ptr[nOffset+6];
	ils.bFlags = map.ptr[nOffset+7];
	ils.nLon = GET_S32(nOffset+8);
	ils.nLat = GET_S32(nOffset+12);
	ils.nAlt = GET_S32(nOffset+16);
	ils.nFreq = GET_S32(nOffset+20);
	ils.fRange = GET_FLOAT(nOffset+24);
	ils.fMagVar = GET_FLOAT(nOffset+28);
	ils.nId = GET_S32(nOffset+32);
	
	
	/*ils.nRegion = GET_S32(nOffset+36);
	ils.nUnk1 = GET_S32(nOffset+40);
	ils.wUnk1 = GET_U16(nOffset+44);
	ils.bEnd = map.ptr[nOffset+46];
	ils.bUnk1 = map.ptr[nOffset+47];
	ils.fHeading = GET_FLOAT(nOffset+48);
	ils.fWidth = GET_FLOAT(nOffset+52);*/


	nStart = nOffset+40;
	nLen = nOffset+ils.nLen;

	while (nStart<nLen)
	{
		wId = GET_U16(nStart);
		switch(wId)
		{
		case 0x14:		// beam info
			bFlags2 |= BIT_BEAM;
			ilsbeam.wId = wId;
			ilsbeam.nLen = GET_S32(nStart+2);
			ils.bEnd = map.ptr[nStart+6];
			ilsbeam.fHeading = GET_FLOAT(nStart+8);
			ilsbeam.fWidth = GET_FLOAT(nStart+12);
			nStart+=(DWORD)ilsbeam.nLen;
			break;

		case 0x15:		// has gs
			bFlags2 |= BIT_GS;
			ilsgs.wId = wId;
			ilsgs.nLen = GET_S32(nStart+2);
			ilsgs.wFiller = GET_U16(nStart+6);
			ilsgs.nLon = GET_S32(nStart+8);
			ilsgs.nLat = GET_S32(nStart+12);
			ilsgs.nAlt = GET_S32(nStart+16);
			ilsgs.fRange = GET_FLOAT(nStart+20);
			ilsgs.fPitch = GET_FLOAT(nStart+24);
			nStart+=ilsgs.nLen;
			break;
		
		case 0x16:
			bFlags2 |= BIT_DME;
			ilsdme.wId = wId;
			ilsdme.nLen = GET_S32(nStart+2);
			ilsdme.wFiller = GET_U16(nStart+6);
			ilsdme.nLon = GET_S32(nStart+8);
			ilsdme.nLat = GET_S32(nStart+12);
			ilsdme.nAlt = GET_S32(nStart+16);
			ilsdme.fRange = GET_FLOAT(nStart+20);
			nStart+=(DWORD)ilsdme.nLen;
			break;


		case 0x19:
			nChunkLength = GET_U32(nStart+2);
			memmove(szName,OFFSET(nStart+6),
	                min(nChunkLength-6,sizeof(szName)-1)); // get descriptive name
			nStart+=nChunkLength;
			break;

		default:		// just to avoid endless loops risks
			nStart+=nLen;
			break;
		}
	
	}

	DecodeIdStr(ils.nId,szId,0x42);		// decode ICAO ID

	fprintf(outfile,"\t\t\t<Ils lat=\"%s\" lon=\"%s\"\n",
		LatString(fslat2lat(ils.nLat),szLat),
		LatString(fslon2lon(ils.nLon),szLon));
	fprintf(outfile,"\t\t\t\talt=%s heading=\"%0.2lf\"\n",
		AltString(ils.nAlt,szAlt),(double)ilsbeam.fHeading);

	fprintf(outfile,"\t\t\t\tfrequency=\"%.3lf\" end=\"%s\" backCourse=\"%s\"\n",
		(double)ils.nFreq/1000000, OrBpTsTable[ils.bEnd>>4].kind,
		(ils.bFlags & ILS_BACKCOURSE) ? truthTable[1] : truthTable[0]);

	fprintf(outfile,"\t\t\t\trange=%s magvar=\"%.2lf\" ident=\"%s\" width=\"%.2lf\"\n",
		RangeString(ils.fRange,szRange),
		MAGVAR(ils.fMagVar),
		szId, (double)ilsbeam.fWidth);

	fprintf(outfile,"\t\t\t\tname=");
	PrintXmlString(szName,0);

	if ((bFlags2 & BIT_GS)!=BIT_GS && (bFlags2 & BIT_DME)!=BIT_DME)
	{
		fprintf(outfile," />\n");
	}
	else
	{
		fprintf(outfile," >\n");

		if ((bFlags2 & BIT_GS)==BIT_GS)
		{
			fprintf(outfile,"\t\t\t\t<GlideSlope lat=\"%s\" lon=\"%s\"\n",
				LatString(fslat2lat(ilsgs.nLat),szLat),
				LatString(fslon2lon(ilsgs.nLon),szLon));
			fprintf(outfile,"\t\t\t\t\talt=%s pitch=\"%.2lf\" range=%s />\n",
				AltString(ilsgs.nAlt,szAlt), (double)ilsgs.fPitch,
				RangeString(ilsgs.fRange,szRange));
		}

		if ((bFlags2 & BIT_DME)==BIT_DME)
		{
			fprintf(outfile,"\t\t\t\t<Dme lat=\"%s\" lon=\"%s\" alt=%s range=%s />\n",
				LatString(fslat2lat(ilsdme.nLat),szLat),
				LatString(fslon2lon(ilsdme.nLon),szLon),
				AltString(ilsdme.nAlt,szAlt),
				RangeString(ilsdme.fRange,szRange)	);
		}
		fprintf(outfile,"\t\t\t</Ils>\n");
	}




	/*j = 56;		// try to find where descriptive name is

	if ( ((ils.bFlags & ILS_GS)==ILS_GS) && ((ils.bFlags & ILS_DME)==ILS_DME) )
		j=108;
	else if ((ils.bFlags & ILS_GS)==ILS_GS)
		j=84;
	else if ((ils.bFlags & ILS_DME)==ILS_DME)
		j=80;*/


	/* 
	 * 2/12/2004 - loop for glideslopes, dme
	 */


/*	while (nStart<nLen)
	{
		wId = GET_U16(nStart);
		switch(wId)
		{
		case 0x15:		// glideslope
			nLength = GET_U32(nStart+2);
			nStart+=nLength;
			break;
		case 0x16:		// dme
			nLength = GET_U32(nStart+2);
			nStart+=nLength;
			break;

		case 0x19:		// ils info
			nLength = GET_U32(nStart+2);
			memset(szName,0x0,sizeof(szName));
			memcpy(szName,&map.ptr[nStart+6],nLength-6); // get descriptive name
			memset(szId,0x0,sizeof(szId));


			DecodeIdStr(ils.nId,szId,0x42);		// decode ICAO ID
			fprintf(outfile,"\t\t\t<Ils lat=\"%s\" lon=\"%s\"\n",
				LatString(fslat2lat(ils.nLat),szLat),
				LatString(fslon2lon(ils.nLon),szLon));

			fprintf(outfile,"\t\t\t\talt=%s heading=\"%0.2lf\"\n",
				AltString(ils.nAlt,szAlt),(double)ils.fHeading);

			fprintf(outfile,"\t\t\t\tfrequency=\"%.3lf\" end=\"%s\" backCourse=\"%s\"\n",
				(double)ils.nFreq/1000000, OrBpTsTable[ils.bEnd>>4].kind,
				(ils.bFlags & ILS_BACKCOURSE) ? truthTable[1] : truthTable[0]);

			fprintf(outfile,"\t\t\t\trange=%s magvar=\"%.2lf\" ident=\"%s\" width=\"%.2lf\"\n",
				RangeString(ils.fRange,szRange),
				MAGVAR(ils.fMagVar),
				szId, (double)ils.fWidth);

			fprintf(outfile,"\t\t\t\tname=");
			PrintXmlString(szName,0);

			if ( ((ils.bFlags & ILS_GS)==ILS_GS) || ((ils.bFlags & ILS_DME)==ILS_DME) )
				fprintf(outfile,">\n");
			else
				fprintf(outfile," />\n");
			nStart+=nLength;
			break;



		default:
			break;
		}

	}


*/	
	/*
	 * repeat the loop for glideslopes and dmes
	 */
/*	nStart = nOffset+56;
	nLen = nOffset+ils.nLen;

	while (nStart<nLen)
	{
		wId = GET_U16(nStart);
		switch(wId)
		{
		case 0x15:		// glideslope
			nLength = GET_U32(nStart+2);
			ilsgs.wId = GET_U16(nStart);
			ilsgs.wFiller = GET_U16(nStart+6);
			ilsgs.nLon = GET_S32(nStart+8);
			ilsgs.nLat = GET_S32(nStart+12);
			ilsgs.nAlt = GET_S32(nStart+16);
			ilsgs.fRange = GET_FLOAT(nStart+20);
			ilsgs.fPitch = GET_FLOAT(nStart+24);
			fprintf(outfile,"\t\t\t\t<GlideSlope lat=\"%s\" lon=\"%s\"\n",
				LatString(fslat2lat(ilsgs.nLat),szLat),
				LatString(fslon2lon(ilsgs.nLon),szLon));
			fprintf(outfile,"\t\t\t\t\talt=%s pitch=\"%.2lf\" range=%s />\n",
				AltString(ilsgs.nAlt,szAlt), (double)ilsgs.fPitch,
				RangeString(ilsgs.fRange,szRange));
			nStart+=nLength;
			break;

		case 0x16:		// dme
			nLength = GET_U32(nStart+2);

			ilsdme.wId = GET_U16(nStart);
			ilsdme.nLen = GET_U32(nStart+2);
			ilsdme.wFiller = GET_U16(nStart+6);
			ilsdme.nLon = GET_S32(nStart+8);
			ilsdme.nLat = GET_S32(nStart+12);
			ilsdme.nAlt = GET_S32(nStart+16);
			ilsdme.fRange = GET_FLOAT(nStart+20);
			fprintf(outfile,"\t\t\t\t<Dme lat=\"%s\" lon=\"%s\" alt=%s range=%s />\n",
				LatString(fslat2lat(ilsdme.nLat),szLat),
				LatString(fslon2lon(ilsdme.nLon),szLon),
				AltString(ilsdme.nAlt,szAlt),
				RangeString(ilsdme.fRange,szRange)	);
			nStart+=nLength;
			break;

		case 0x19:		// ils info
			nLength = GET_U32(nStart+2);
			nStart+=nLength;
			break;


		default:
			break;
		}

	}
*/

/*	if ( ((ils.bFlags & ILS_GS)==ILS_GS) || ((ils.bFlags & ILS_DME)==ILS_DME) )
		fprintf(outfile,"\t\t\t</Ils>\n");
*/

	/*nNameOffset = GET_S32(nOffset+j+2);
	memset(szName,0x0,sizeof(szName));

	memcpy(szName,&map.ptr[nOffset+j+6],nNameOffset-6); // get descriptive name

	memset(szId,0x0,ssizeof(szId));
	DecodeIdStr(ils.nId,szId,0x42);		// decode ICAO ID
	fprintf(outfile,"\t\t\t<Ils lat=\"%s\" lon=\"%s\"\n",
		LatString(fslat2lat(ils.nLat),szLat),
		LatString(fslon2lon(ils.nLon),szLon));

	fprintf(outfile,"\t\t\t\talt=%s heading=\"%0.2lf\"\n",
		AltString(ils.nAlt,szAlt),(double)ils.fHeading);

	fprintf(outfile,"\t\t\t\tfrequency=\"%.3lf\" end=\"%s\" backCourse=\"%s\"\n",
		(double)ils.nFreq/1000000, OrBpTsTable[ils.bEnd>>4].kind,
		GET_FLAG(ils.bFlags,ILS_BACKCOURSE) ? truthTable[1] : truthTable[0]);

	fprintf(outfile,"\t\t\t\trange=%s magvar=\"%.2lf\" ident=\"%s\" width=\"%.2lf\"\n",
		RangeString(ils.fRange,szRange),
		MAGVAR(ils.fMagVar),
		szId, (double)ils.fWidth);

	fprintf(outfile,"\t\t\t\tname=");
	PrintXmlString(szName,0);

	if ( ((ils.bFlags & ILS_GS)==ILS_GS) || ((ils.bFlags & ILS_DME)==ILS_DME) )
		fprintf(outfile,">\n");
	else
		fprintf(outfile," />\n");

	if ((ils.bFlags & ILS_GS)==ILS_GS)	// read additional info for gs
	{
		ilsgs.wId = GET_U16(nOffset+56);
		ilsgs.nLen = GET_U32(nOffset+58);
		ilsgs.wFiller = GET_U16(nOffset+62);
		ilsgs.nLon = GET_S32(nOffset+64);
		ilsgs.nLat = GET_S32(nOffset+68);
		ilsgs.nAlt = GET_S32(nOffset+72);
		ilsgs.fRange = GET_FLOAT(nOffset+76);
		ilsgs.fPitch = GET_FLOAT(nOffset+80);
		fprintf(outfile,"\t\t\t\t<GlideSlope lat=\"%s\" lon=\"%s\"\n",
			LatString(fslat2lat(ilsgs.nLat),szLat),
			LatString(fslon2lon(ilsgs.nLon),szLon));
		fprintf(outfile,"\t\t\t\t\talt=%s pitch=\"%.2lf\" range=%s />\n",
			AltString(ilsgs.nAlt,szAlt), (double)ilsgs.fPitch,
			RangeString(ilsgs.fRange,szRange));
	}
	if ( (ils.bFlags & ILS_DME)==ILS_DME)	// read additional info for dme
	{
		if ((ils.bFlags & ILS_GS)==ILS_GS)
			j = 84;
		else
			j = 56;
		ilsdme.wId = GET_U16(nOffset+j);
		ilsdme.nLen = GET_U32(nOffset+j+2);
		ilsdme.wFiller = GET_U16(nOffset+j+6);
		ilsdme.nLon = GET_S32(nOffset+j+8);
		ilsdme.nLat = GET_S32(nOffset+j+12);
		ilsdme.nAlt = GET_S32(nOffset+j+16);
		ilsdme.fRange = GET_FLOAT(nOffset+20);
		fprintf(outfile,"\t\t\t\t<Dme lat=\"%s\" lon=\"%s\" alt=%s range=%s />\n",
			LatString(fslat2lat(ilsdme.nLat),szLat),
			LatString(fslon2lon(ilsdme.nLon),szLon),
			AltString(ilsdme.nAlt,szAlt),
			RangeString(ilsdme.fRange,szRange)	);

	}
	if ( ((ils.bFlags & ILS_GS)==ILS_GS) || ((ils.bFlags & ILS_DME)==ILS_DME) )
		fprintf(outfile,"\t\t\t</Ils>\n");*/

}

/*
 * see if a taxisign matches and print it if so
 *
 * Parameters:
 * fLat - ARP center latitude
 * fLon - ARP center longitude
 * Return value:
 * none
 */
static void LookupTaxiSign(double fLat, double fLon)
{
	intlist_t *ptr;
	double fEndLat, fEndLon;

    TRACE("LookupTaxiSign\n");

	for (ptr = lpTaxiSign; ptr; ptr=ptr->next)	// for each station
	{
		fEndLat = fslat2lat(GET_S32(ptr->nOffset+8));	// get sign lat
		fEndLon = fslon2lon(GET_S32(ptr->nOffset+4));	// get sign lon

		// pre condition: boundaries within 0.5 degrees and
		// entry not being already examinated
		if ((fabs(fLat-fEndLat)<0.5) && (fabs(fLon-fEndLon)<0.5) && ptr->nParam==1)
		{
			ptr->nParam=0;	// mark this entry as being examinated
			if (gcdist(fLat,fLon,fEndLat,fEndLon)<8000)	// within 8 kilometers
			{
				AnalyzeTaxiSign(ptr->nOffset);			// extract and print
			}
		}
	}
}


/*
 * see if a runway has ILS and print them if so
 * (courtesy of Ted Wright - nav@consequential.org)
 *
 * Parameters:
 * fLat - runway center latitude in decimal degrees
 * fLon - runway center longitude in decimal degrees
 * fLength - runway length in meters
 * fHeading - runway heading in degrees
 *
 * Return value:
 * none
 */
static void LookupIls(/*double fLat, double fLon, double fLength, double fHeading, */
					  DWORD nStartId, DWORD nEndId)
{

	intlist_t *ptr;
	/*double rwcourse,ilscourse;
	double brg,fullRwLength,dist,minLat,maxLat,minLon,maxLon;
    double ilsLat,ilsLon;
	int iLat, iLon;
	float fIlsHeading;*/
	DWORD nId;
	char szId[6], szStartId[6], szEndId[6];

	/*minLat = fLat-0.5;
	maxLat = fLat+0.5;

	minLon = fLon-0.5;
	maxLon = fLon+0.5;*/

    TRACE("LookupIls\n");

	/*
	 * convert packed ICAO identifiers from runway chunk
	 */
	if (nStartId!=0)
		DecodeIlsStr(nStartId,szStartId);
	if (nEndId!=0)
		DecodeIlsStr(nEndId,szEndId);

	for (ptr = lpIls; ptr; ptr=ptr->next)		/* for each ILS				*/
	{
		nId = GET_U32(ptr->nOffset+32);		/* get current ils icao id	*/
		DecodeIdStr(nId,szId,0);				/* new decode routine no needs param */

		if (nStartId!=0)						/* compare with primary id	*/
			if (!strcmp(szId,szStartId))		/* if ICAOS match */
				PrintIlsInfo(ptr->nOffset);

		if (nEndId!=0)							/* compare with secondary id	*/
			if (!strcmp(szId,szEndId))			/* if ICAOS match */
				PrintIlsInfo(ptr->nOffset);
		

    }
}

/*
 * Analyzes and decode taxi names
 *
 * Parameters:
 * nStart - offset to taxi name entry
 *
 * Return value:
 * length of chunk
 */
static DWORD AnalyzeTaxiName(char *pszName, DWORD nStart, DWORD nIcaoId)
{
	taxiname_t ptr;
	WORD i;
	char str[12];
	DWORD n = nStart+8;

    TRACE("AnalyzeTaxiName\n");
	
	ptr.wId = GET_U16(nStart);					// get name
	ptr.nLen = GET_U32(nStart+2);				// get length
	if (IS_PASS2)
	{
		if (!nTerse)
			PrintObjectSpec(pszName,nStart);
		ptr.wNamesCount = GET_U16(nStart+6);	// get count of names
		for (i=0; i<ptr.wNamesCount; i++, n+=8)
		{
			*str ='\0';							// init string
			memcpy(str,OFFSET(n),8);			// get the name
			str[8]='\0';						// add null termination
			{
				fprintf(outfile,"\t\t<%s index=\"%d\" name=\"",
					pszName, i);

				if (*str)							// if string isn't empty
					fprintf(outfile,"%s", str);
				fprintf(outfile,"\" />\n");
			}
		}

	}
	return ptr.nLen;

}

/*
 * Analyzes and decode taxiway paths
 *
 * Parameters:
 * nStart - offset to taxiway path entry
 *
 * Return value:
 * length of chunk
 */
static DWORD AnalyzeTaxiwayPaths(char *pszName, DWORD nStart, DWORD nIcaoId)
{
	taxipath_hdr_t hdr;
	taxiway_path_t path;
	WORD i;
    BYTE a, b, c;
	DWORD n;
	BOOL bDrawSurfaceFlag;
	BOOL bDrawDetailFlag;

	hdr.wId = GET_U16(nStart);			// get id
	hdr.nLen = GET_U32(nStart + 2);	// get length

    TRACE("AnalyzeTaxiwayPaths\n");
	
	if (IS_PASS2)
	{
		hdr.wCount = GET_U16(nStart + 6);	// get count of paths
		if (!nTerse)
			PrintObjectSpec(pszName,nStart);


		for (i=0, n=nStart+8; i<hdr.wCount; i++, n+=20)
		{
			bDrawSurfaceFlag=bDrawDetailFlag=FALSE;

			path.wStart = GET_U16(n);
			path.wEnd = GET_U16(n+2);
			path.bDrawFlags = GET_BYTE(n+4);
			path.bNumber = GET_BYTE(n+5);
			path.bCenterFlags = GET_BYTE(n+6);
			path.bSurface = GET_BYTE(n+7);
			path.fWidth = GET_FLOAT(n+8);
			path.nWeigthLimit = GET_S32(n+12);
			path.nUnk = GET_S32(n+16);

			// extract designator from end and recompose
			b = HIBYTE(path.wEnd);  //path.wEnd >> 8;
			a = LOBYTE(path.wEnd);  //& 0xff;
			c = LO4BITS(b);         //& 0xf;
			b = HI4BITS(b);         // >> 4
            
			path.wEnd &= ~0xf000; //a | c;

			ASSERT(b<=5);

			// see if we have draw flags
			if (path.bDrawFlags & TPATH_DRAW_DETAIL)
			{
				bDrawDetailFlag=TRUE;
			}
			if (path.bDrawFlags & TPATH_DRAW_SURFACE)
			{
				bDrawSurfaceFlag=TRUE;
			}

			path.bDrawFlags &= TPATH_TYPE;
			ASSERT(path.bDrawFlags >= 1 && path.bDrawFlags <= TPATH_TYPE_VEHICLE);

			fprintf(outfile,"\t\t<%s type=\"%s\" start=\"%d\" end=\"%d\"\n",
				pszName, 
				twpathTable[path.bDrawFlags-1],
				path.wStart, path.wEnd/*, b*/);
			fprintf(outfile,"\t\t\tsurface=\"%s\" width=\"%0.2lf\" weightLimit=\"%ld\"\n",
				surfacesTable[GetRwySurface(path.bSurface)],
				(double)path.fWidth, path.nWeigthLimit);

			fprintf(outfile,"\t\t\tdrawSurface=\"%s\" drawDetail=\"%s\"\n",
				bDrawSurfaceFlag ? truthTable[1] : truthTable[0],
				bDrawDetailFlag ? truthTable[1] : truthTable[0]);
		
			fprintf(outfile,"\t\t\tcenterLine=\"%s\" centerLineLighted=\"%s\" leftEdge=\"",
				(path.bCenterFlags & TPATH_CENTERLINE) ?
					truthTable[1] : truthTable[0],
				(path.bCenterFlags & TPATH_CENTERLINE_LIGHTED) ?
					truthTable[1] : truthTable[0]);

			if (path.bCenterFlags & TPATH_LEFTEDGE_SOLID)
				fprintf(outfile,"SOLID");
			else if (path.bCenterFlags & TPATH_LEFTEDGE_DASHED)
				fprintf(outfile,"DASHED");
			else if (path.bCenterFlags & TPATH_LEFTEDGE_SOLID_DASHED)
				fprintf(outfile,"SOLID_DASHED");
			else
				fprintf(outfile,"NONE");

			fprintf(outfile,"\"\n\t\t\tleftEdgeLighted=\"%s\" rightEdgeLighted=\"%s\" rightEdge=\"",
				(path.bCenterFlags & TPATH_LEFTEDGE_LIGHTED) ?
					truthTable[1] : truthTable[0],
				(path.bCenterFlags & TPATH_RIGHTEDGE_LIGHTED) ?
					truthTable[1] : truthTable[0]);


			if (path.bCenterFlags & TPATH_RIGHTEDGE_SOLID)
				fprintf(outfile,"SOLID");
			else if (path.bCenterFlags & TPATH_RIGHTEDGE_DASHED)
				fprintf(outfile,"DASHED");
			else if (path.bCenterFlags & TPATH_RIGHTEDGE_SOLID_DASHED)
				fprintf(outfile,"SOLID_DASHED");
			else
				fprintf(outfile,"NONE");

			fprintf(outfile,"\"\n\t\t\t");

			// if taxy type is not a runway print name, else
			// print number
			if (path.bDrawFlags!=TPATH_TYPE_RUNWAY)
			{
				fprintf(outfile,"name");
				fprintf(outfile,"=\"%d\" ",
					path.bNumber);
			}
			else
			{
				fprintf(outfile,"number");
				fprintf(outfile,"=\"%s\" ",
					GetRwyNumber(path.bNumber));
			}
			if (path.bDrawFlags==TPATH_TYPE_RUNWAY)	// print out designator
				fprintf(outfile,"designator=\"%s\" ",
					lrcTable[b]	);
		
			fprintf(outfile,"/>\n");
		}
	}
	return hdr.nLen;
}

/*
 * Analyzes and decode helipads
 *
 * Parameters:
 * nStart - offset to helipad entry
 *
 * Return value:
 * length of chunk
 */
static DWORD AnalyzeHelipad(char *pszName, DWORD nStart, DWORD nIcaoId)
{
	helipad_t heli;
	char szLat[24], szLon[24], szAlt[24];
	
	heli.wId = GET_U16(nStart);
	heli.nLen = GET_U32(nStart + 2);

    TRACE("AnalyzeHelipad\n");

	if (IS_PASS2)
	{
		heli.bSurface = GET_BYTE(nStart+6);
		heli.bFlags = GET_BYTE(nStart+7);
		heli.r = GET_BYTE(nStart+8);
		heli.g = GET_BYTE(nStart+9);
		heli.b = GET_BYTE(nStart+10);
		heli.a = GET_BYTE(nStart+11);
		heli.nLon = GET_S32(nStart + 12);
		heli.nLat = GET_S32(nStart + 16);
		heli.nAlt = GET_S32(nStart + 20);
		heli.fLength = GET_FLOAT(nStart + 24);
		heli.fWidth = GET_FLOAT(nStart + 28);
		heli.fHeading = GET_FLOAT(nStart + 32);

		fprintf(outfile,"\t\t<%s lat=\"%s\" lon=\"%s\" alt=%s\n",
			pszName,
			LatString(fslat2lat(heli.nLat),szLat),			
			LatString(fslon2lon(heli.nLon),szLon),
			AltString(heli.nAlt,szAlt));
		fprintf(outfile,"\t\t\tsurface=\"%s\" heading=\"%.2lf\"\n",
			surfacesTable[GetRwySurface(heli.bSurface)],
			(double)heli.fHeading);
		
		fprintf(outfile,"\t\t\tlength=%s width=%s\n",
			DimString(heli.fLength,szLat),
			DimString(heli.fWidth,szLon));

		fprintf(outfile,"\t\t\tclosed=\"");
		if (heli.bFlags & HELI_CLOSED)
		{
			heli.bFlags &= ~HELI_CLOSED;
			fprintf(outfile,"%s",truthTable[1]);
		}
		else
			fprintf(outfile,"%s",truthTable[0]);

		fprintf(outfile,"\" transparent=\"");
		if (heli.bFlags & HELI_TRANSPARENT)
		{
			heli.bFlags &= ~HELI_TRANSPARENT;
			fprintf(outfile,"%s",truthTable[1]);
		}
		else
			fprintf(outfile,"%s",truthTable[0]);

		fprintf(outfile,"\" type=\"%s\" />\n",
			heliTable[heli.bFlags]
			);
		
	}
	return heli.nLen;
}

/*
 * Analyzes and decode taxi points
 *
 * Parameters:
 * nStart - offset to taxi point entry
 *
 * Return value:
 * length of chunk
 */
static DWORD AnalyzeTaxiwayPoint(char *pszName, DWORD nStart, DWORD nIcaoId)
{
	twp_t twp;
	twp_entry_t twp_entry;
	WORD i;
    DWORD n = nStart+8;
    DWORD nEnd;
	char szLat[24], szLon[24];

	twp.wId = GET_U16(nStart);				// get rec id
    twp.nLen = GET_U32(nStart+2);          // get length
    nEnd = nStart+twp.nLen;

    TRACE("AnalyzeTaxiwayPoint\n");

	if (IS_PASS2)
	{
		twp.wSize = GET_U16(nStart+6);			// get # of points
		if (!nTerse)
			PrintObjectSpec(pszName,nStart);

        for (i=0; n<nEnd; i++, n+=12)
		{
			twp_entry.bType=GET_BYTE(n);
			twp_entry.bOrientation=GET_BYTE(n+1);
			
			twp_entry.nLon=GET_S32(n+4);
			
			twp_entry.nLat=GET_S32(n+8);

			fprintf(outfile,"\t\t<%s index=\"%d\" type=\"%s\"\n",
				pszName, i, twpTable[twp_entry.bType-1]);
			fprintf(outfile,"\t\t\torientation=\"%s\" lat=\"%s\" lon=\"%s\" />\n",
				twp_entry.bOrientation==1 ?  "REVERSE" : "FORWARD",
				LatString(fslat2lat(twp_entry.nLat),szLat),
				LatString(fslon2lon(twp_entry.nLon),szLon));
		}
	}
	return twp.nLen;
}


/*
 * Analyzes and decode taxiway parkings
 *
 * Parameters:
 * nStart - offset to delete taxiway parkings
 *
 * Return value:
 * length of chunk
 */
static DWORD AnalyzeTaxiwayParking(char *pszName, DWORD nStart, DWORD nIcaoId)
{
	taxiway_parking_header_t hdr;
	taxiway_parking_t ptr;
	DWORD nSubStart, nSubEnd;
	BYTE b;
	DWORD nIndex;
	char szLat[24], szLon[24], szCode[6];
	
	// get header
	hdr.wId = GET_U16(nStart);
	hdr.nLen = GET_S32(nStart+2);

    TRACE("AnalyzeTaxiwayParking\n");
	
	if (IS_PASS2)
	{
		hdr.wCount = GET_U16(nStart+6);	// get count of entries


		if (hdr.wCount)						// should always be true
		{
			if (!nTerse)
				PrintObjectSpec(pszName,nStart);
			nSubStart = nStart+8;
			nSubEnd = (nSubStart-8)+hdr.nLen;
			nIndex=0;
			do								// while we have entries
			{
				/* 
				 * get record entries
				 */
				ptr.bPushBackName = map.ptr[nSubStart++];	
				ptr.wNumberType = GET_U16(nSubStart);
				nSubStart+=2;
				ptr.bCodeCount = map.ptr[nSubStart++];
				ptr.fRadius = GET_FLOAT(nSubStart);
				nSubStart+=4;
				ptr.fHeading = GET_FLOAT(nSubStart);
				nSubStart+=4;
				if (hdr.wId==0x3d)
					nSubStart+=16;	/* Skip unknown FSX entry (teeOffset1-4 ?) */
				ptr.nLon = GET_S32(nSubStart);
				nSubStart+=4;
				ptr.nLat = GET_S32(nSubStart);
				nSubStart+=4;

				fprintf(outfile,"\t\t<%s pushBack=\"", pszName);
				if (GET_FLAG(ptr.bPushBackName,PARKING_PUSHB,PARKING_PUSHB_BOTH))
				{
					fprintf(outfile,"%s", pushBackTable[3]);
				}
				else if (GET_FLAG(ptr.bPushBackName,PARKING_PUSHB,PARKING_PUSHB_RIGHT))
				{
					fprintf(outfile,"%s", pushBackTable[2]);
				}
				else if (GET_FLAG(ptr.bPushBackName,PARKING_PUSHB,PARKING_PUSHB_LEFT))
				{
					fprintf(outfile,"%s", pushBackTable[1]);
				}
				else
					fprintf(outfile,"%s", pushBackTable[0]);

				fprintf(outfile,"\" lat=\"%s\" lon=\"%s\"\n",
					LatString(fslat2lat(ptr.nLat),szLat),
					LatString(fslon2lon(ptr.nLon),szLon));

				fprintf(outfile,"\t\t\theading=\"%0.2lf\" radius=\"%.2lf\" name=\"",
					(double)ptr.fHeading, (double)ptr.fRadius
					);

				if ((ptr.bPushBackName&PARKING_NAME)>0xb)
					fprintf(outfile,"GATE_%c",(ptr.bPushBackName & PARKING_NAME)+53);
				else
					fprintf(outfile,"%s",parkingTable[ptr.bPushBackName&PARKING_NAME]);
				
				fprintf(outfile,"\" type=\"%s\"\n", parkingTypeTable[ptr.wNumberType&PARKING_TYPE]);

				fprintf(outfile,"\t\t\tnumber=\"%d\" index=\"%lu\"",
					ptr.wNumberType>>4,nIndex++);

				// optionally, print airline codes
				if (ptr.bCodeCount)
				{
					
					fprintf(outfile,"\n\t\t\tairlineCodes=\"");
					
					for (b=0; b<ptr.bCodeCount; b++, nSubStart+=4)
					{
						memset(szCode,0x0,sizeof(szCode));
						memcpy(szCode,OFFSET(nSubStart),4);	// copy the code
						fprintf(outfile,"%s",szCode);		// print it
						if (b<ptr.bCodeCount-1)				// print comma if required
							fprintf(outfile,",");
					}
					fprintf(outfile,"\"");					// print trailer
				}
				fprintf(outfile," />\n");


			} while (nSubStart<nSubEnd);					// advance to next station
		}
	}
	return hdr.nLen;
}


/*
 * Analyzes and decode delete structures
 *
 * Parameters:
 * nStart - offset to delete record chunk
 * nLen - delete chunk length
 *
 * Return value:
 * none
 */
static DWORD AnalyzeDeleteRecords(char *pszName, DWORD nStart, DWORD nIcaoId)
{
	delete_airport_t delapt;
	delete_runway_t rwy;
	delete_start_t start;
	BYTE b,c;
	DWORD nSubStart,freq;

    TRACE("AnalyzeDeleteRecords\n");
	delapt.wId = GET_U16(nStart);
	delapt.nLen = GET_U32(nStart+2);
	if (IS_PASS2)
	{
		delapt.wFlags = GET_U16(nStart+6);
		fprintf(outfile,"\t\t<%s\n",pszName);

		fprintf(outfile,"\t\t\tdeleteAllApproaches = \"%s\"\n",
			(delapt.wFlags & BIT_DELETE_ALL_APPROACHES) ?
			truthTable[1] : truthTable[0]);

		fprintf(outfile,"\t\t\tdeleteAllAprons = \"%s\"\n",
			(delapt.wFlags & BIT_DELETE_ALL_APRONS) ?
			truthTable[1] : truthTable[0]);

		fprintf(outfile,"\t\t\tdeleteAllFrequencies = \"%s\"\n",
			(delapt.wFlags & BIT_DELETE_ALL_FREQUENCIES) ?
			truthTable[1] : truthTable[0]);

		fprintf(outfile,"\t\t\tdeleteAllHelipads = \"%s\"\n",
			(delapt.wFlags & BIT_DELETE_ALL_HELIPADS) ?
			truthTable[1] : truthTable[0]);

		fprintf(outfile,"\t\t\tdeleteAllRunways = \"%s\"\n",
			(delapt.wFlags & BIT_DELETE_ALL_RUNWAYS) ?
			truthTable[1] : truthTable[0]);

		fprintf(outfile,"\t\t\tdeleteAllStarts = \"%s\"\n",
			(delapt.wFlags & BIT_DELETE_ALL_STARTS) ?
			truthTable[1] : truthTable[0]);

		fprintf(outfile,"\t\t\tdeleteAllTaxiways = \"%s\"",
			(delapt.wFlags & BIT_DELETE_ALL_TAXIWAYS) ?
			truthTable[1] : truthTable[0]);

		if (delapt.nLen<=0xa)			// we don't have sub-infos
		{
			fprintf(outfile," />\n");
		}
		
		else	// we have sub infos, so decode them
		{
			fprintf(outfile,">\n");
			delapt.bDelRwyCount = map.ptr[nStart+8];
			delapt.bDelStartCount = map.ptr[nStart+9];
			delapt.bDelFreqCount = map.ptr[nStart+10];
			delapt.bPad = map.ptr[nStart+11];

			nSubStart = nStart + 12;
			if (delapt.bDelRwyCount)
				for (b=0; b<delapt.bDelRwyCount; b++)
				{
					rwy.bSurface=map.ptr[nSubStart];
					rwy.bStartNumber=map.ptr[nSubStart+1];
					rwy.bEndNumber=map.ptr[nSubStart+2];
					rwy.bDesignator=map.ptr[nSubStart+3];

					fprintf(outfile, "\t\t\t<DeleteRunway surface=\"%s\" ",
						surfacesTable[GetRwySurface(rwy.bSurface)]);

					fprintf(outfile,"number=\"%s\" designator=\"%s\" />\n",
						GetRwyNumber(rwy.bStartNumber), 
						lrcTable[rwy.bDesignator >> 4]);
					nSubStart+=sizeof(rwy);
				}
			if (delapt.bDelStartCount)
				for (b=0; b<delapt.bDelStartCount; b++)
				{
					start.bNumber=map.ptr[nSubStart];
					start.bDesignator=map.ptr[nSubStart+1];
					start.bType=map.ptr[nSubStart+2];
					start.bPad=map.ptr[nSubStart+3];
					fprintf(outfile, "\t\t\t<DeleteStart type=\"%s\" ",
						rwyStartTable[start.bType]);
					fprintf(outfile, "number=\"%s\" designator=\"%s\" />\n",
						GetRwyNumber(start.bNumber),lrcTable[start.bDesignator]);

					nSubStart+=sizeof(start);
				}
			if (delapt.bDelFreqCount)
				for (b=0; b<delapt.bDelFreqCount; b++)
				{
					freq = GET_U32(nSubStart) & ~0xF0000000;
					c = GET_BYTE(nSubStart+3) >> 4;
					fprintf(outfile,"\t\t\t<DeleteFrequency frequency=\"%.3lf\" type=\"%s\" />\n",
						(double)freq/1000000, commTable[c]);
					nSubStart+=sizeof(DWORD);

				}
			fprintf(outfile,"\t\t</%s>\n",pszName);
		}
	}
	return delapt.nLen;
}

/*
 * print overrun or blastpad info
 *
 * Parameters:
 * bp : overrun/blastpad/threshold structure
 *
 * Return value:
 * none
 */
static void PrintOrBpTsInfo(blastpad_t *ptr)
{
	char szLen[24];
	char szWidth[24];

    TRACE("PrintOrBpTsInfo\n");

	fprintf(outfile,"\t\t\t<%s end=\"%s\" length=%s width=%s surface=\"%s\" />\n",
		OrBpTsTable[ptr->wId-5].ptr,OrBpTsTable[ptr->wId-5].kind,
		DimString(ptr->fLength,szLen), DimString(ptr->fWidth,szWidth),
		surfacesTable[GetRwySurface(ptr->wSurface)]
		);
}

/*
 * analyze and decode approach lights
 *
 * Parameters:
 * nOffset: offset within bgl file this approach light is at
 *
 * Return value:
 * length of approach light chunk
 */
static int AnalyzeApproachLights(const DWORD nOffset)
{
	const char *systems[] = {
		"NONE", "ODALS", "MALSF", "MALSR", "SSALF", "SSALR", "ALSF1", "ALSF2",

		"RAIL", "CALVERT", "CALVERT2", "MALS", "SALS", "SALSF", "SSALS", "SSALS", };
	approachlights_t ptr;
	ptr.wId=GET_U16(nOffset);
	ptr.nLen=GET_S32(nOffset+2);
    TRACE("AnalyzeApproachLights\n");

	if (IS_PASS2)
	{
		ptr.bFlags=map.ptr[nOffset+6];
		ptr.bStrobes=map.ptr[nOffset+7];

		fprintf(outfile,"\t\t\t<ApproachLights end=\"%s\"\n",
			ptr.wId==0xF ? OrBpTsTable[0].kind : OrBpTsTable[1].kind);

		fprintf(outfile,"\t\t\t\tsystem=\"%s\" ",
				systems[ptr.bFlags & AP_SYSTEM]);
		fprintf(outfile,"strobes=\"%d\"\n",ptr.bStrobes);

		fprintf(outfile,"\t\t\t\treil=\"%s\" ",
				((ptr.bFlags & AP_REIL) ?
				truthTable[1] : truthTable[0]));

		fprintf(outfile,"touchdown=\"%s\" ",
				((ptr.bFlags & AP_TOUCHDOWN) ?
				truthTable[1] : truthTable[0]));

		fprintf(outfile,"endLights=\"%s\" />\n",
				((ptr.bFlags & AP_ENDLIGHTS) ?
				truthTable[1] : truthTable[0]));
	}
	return ptr.nLen;
}

/*
 * analyze and decode vasi
 *
 * Parameters:
 * nOffset: offset within bgl file this vasi is at
 *
 * Return value:
 * length of vasi chunk
 */
static int AnalyzeVasi(int nOffset)
{
	vasi_t vasi;
	char szBiasX[24];
	char szBiasY[24];
	char szSpacing[24];
	int nVasiKind;
	int nVasiEnd;
	vasi.wId=GET_U16(nOffset);
	vasi.nLen=GET_S32(nOffset+2);

    TRACE("AnalyzeVasi\n");

	if (IS_PASS2)
	{
		vasi.wType=GET_U16(nOffset+6);
		vasi.fBiasX=GET_FLOAT(nOffset+8);
		vasi.fBiasZ=GET_FLOAT(nOffset+12);
		vasi.fSpacing=GET_FLOAT(nOffset+16);
		vasi.fPitch=GET_FLOAT(nOffset+20);


		switch (vasi.wId)
		{
		case 0xB:	// primary on left
			nVasiKind = 1;
			nVasiEnd = 0;
			break;
		case 0xC:	// primary on right
			nVasiKind = 2;
			nVasiEnd = 0;
			break;
		case 0xD:	// secondary on left
			nVasiKind = 1;
			nVasiEnd = 1;
			break;
		case 0xE:	// secondary on right
			nVasiKind = 2;
			nVasiEnd = 1;
			break;
		}

		fprintf(outfile,"\t\t\t<Vasi end=\"%s\" side=\"%s\" type=\"%s\"\n",
			OrBpTsTable[nVasiEnd].kind,
			lrcTable[nVasiKind],
			vasiTable[vasi.wType]);
		fprintf(outfile,"\t\t\t\tbiasX=%s biasZ=%s spacing=%s pitch=\"%0.2lf\" />\n",
			DimString(vasi.fBiasX,szBiasX), DimString(vasi.fBiasZ,szBiasY),
			DimString(vasi.fSpacing,szSpacing), (double)vasi.fPitch);
	}
	return vasi.nLen;

}

/*
 * analyze and decode start 
 *
 * Parameters:
 * nOffset: offset within bgl file this runway start is at
 *
 * Return value:
 * length of runway start chunk
 * 
 * NOTE: RunwayStart was dropped as it seems to be thee same stuff (?!?)
 */
static DWORD AnalyzeRunwayStart(char *pszName, DWORD nOffset, DWORD nIcaoId)
{
	rwystart_t rwy;
	char szAlt[24];
	char szLat[24];
	char szLon[24];

    TRACE("AnalyzeRunwayStart\n");

	rwy.wId=GET_U16(nOffset);
	rwy.nLen=GET_U32(nOffset+2);

	rwy.lpUn1.bNumber=map.ptr[nOffset+6];
	rwy.lpUn2.bFlags=map.ptr[nOffset+7];

	/*rwy.lpUn1.bEnd=map.ptr[nOffset+6];
	rwy.lpUn2.bType =map.ptr[nOffset+7];*/

	rwy.nLon=GET_S32(nOffset+8);
	rwy.nLat=GET_S32(nOffset+12);
	rwy.nAlt=GET_S32(nOffset+16);
	rwy.fHeading=GET_FLOAT(nOffset+20);

	if (IS_PASS2)
	{
		if (!nTerse)
				PrintObjectSpec(pszName,nOffset);

		fprintf(outfile,"\t\t<%s type=\"%s\" lat=\"%s\" lon=\"%s\"\n",
			pszName,
			rwyStartTable[rwy.lpUn2.bFlags >> 4],
			LatString(fslat2lat(rwy.nLat),szLat),
			LatString(fslon2lon(rwy.nLon),szLon));
		
		fprintf(outfile,"\t\t\talt=%s heading=\"%0.2lf\" number=\"%s\" ",
			AltString(rwy.nAlt,szAlt),(double)rwy.fHeading,
			GetRwyNumber(rwy.lpUn1.bNumber));

		fprintf(outfile,"designator=\"%s\" />\n",
			lrcTable[rwy.lpUn2.bFlags & 0xf]);

		/*fprintf(outfile,"\t\t<!--\n");
		fprintf(outfile,"\t\t\t<RunwayStart type=\"%s\" lat=\"%s\" lon=\"%s\"\n",
			rwyStartTable[rwy.lpUn2.bType >> 4], LatString(fslat2lat(rwy.nLat),szLat),
			LatString(fslon2lon(rwy.nLon),szLon));

		fprintf(outfile,"\t\t\t\talt=%s heading=\"%0.2lf\" end=\"%s\" />\n",
			AltString(rwy.nAlt,szAlt),(double)rwy.fHeading,
			OrBpTsTable[rwy.lpUn1.bEnd >> 4].kind);
		fprintf(outfile,"\t\t-->\n");
		*/
	}
	return rwy.nLen;
}

/*
 * Analyzes and decode approaches
 *
 * Parameters:
 * nStart - offset to approach info
 *
 * Return value:
 * length of chunk
 */
static DWORD AnalyzeApproach(char *pszName, DWORD nStart, DWORD nIcaoId)
{
	approach_t ptr;
	char szId[6];
	char szRegion[4];
	char szFixType[24];
	char szAlt[24];
	BYTE bFixType, bLow, bHigh;
	int nSuffix;
	
	TRACE("AnalyzeApproach\n");

	ptr.wId = GET_U16(nStart);
	ptr.nLen = GET_U32(nStart+2);

	
	if (IS_PASS2)
	{
		ptr.bSuffix = GET_BYTE(nStart+6);
		ptr.bNumber = GET_BYTE(nStart+7);
		ptr.bApprDesignator = GET_BYTE(nStart+8);
		ptr.nId = GET_S32(nStart+12);
		ptr.nRegion = GET_S32(nStart+16);
		ptr.fAltitude = GET_FLOAT(nStart+20);
		ptr.fHeading = GET_FLOAT(nStart+24);
		ptr.fMissedAltitude = GET_FLOAT(nStart+28);

		nSuffix = (int)ptr.bSuffix;

		bFixType=GET_BYTE(nStart+12);				// get fix type


		// quick and dirty method to determine ICAO ID seed
		switch (bFixType & 0xf)
		{
		case 0x2:			// vor
			DecodeIdStr(ptr.nId,szId,0x42);
			strcpy(szFixType,"VOR");
			break;
		case 0x3:			// ndb
			DecodeIdStr(ptr.nId,szId,0x43);
			strcpy(szFixType,"NDB");
			break;
		case 0x4:			// terminal ndb
			DecodeIdStr(ptr.nId,szId,0x44);
			strcpy(szFixType,"TERMINAL_NDB");
			break;
		case 0x5:			// waypoint
			DecodeIdStr(ptr.nId,szId,0x45);
			strcpy(szFixType,"WAYPOINT");
			break;
		case 0x6:			// terminal waypoint
			DecodeIdStr(ptr.nId,szId,0x46);
			strcpy(szFixType,"TERMINAL_WAYPOINT");
			break;

		default:			// bad news
			return ptr.nLen;// skip it
		}

		DecodeRegionStr(ptr.nRegion,szRegion);
		bHigh = ptr.bApprDesignator >> 4;
		bLow =  ptr.bApprDesignator & 0xf;

		if (!nTerse)
			PrintObjectSpec(pszName,nStart);

		

		fprintf(outfile,"\t\t<%s type=\"%s\" runway=\"%s\" suffix=\"",
			pszName,
			approachTable[bLow], GetRwyNumber(ptr.bNumber));
		if (isalnum(nSuffix))
			fprintf(outfile,"%c",ptr.bSuffix);
		fprintf(outfile,"\"\n");
		
		fprintf(outfile,"\t\t\tgpsOverlay=\"");
		if (bHigh & APPROACH_GPS_OVL)
		{
			bHigh &= ~APPROACH_GPS_OVL;
			fprintf(outfile,"%s",truthTable[1]);
		}
		else
			fprintf(outfile,"%s",truthTable[0]);
		
		fprintf(outfile,"\" designator=\"%s\" fixType=\"%s\"\n\t\t\tfixRegion=\"%s\" ",
			lrcTable[bHigh],szFixType,szRegion);

		fprintf(outfile,"fixIdent=\"%s\" altitude=%s\n\t\t\theading=\"%0.2lf\" ",
			szId, DimString(ptr.fAltitude,szAlt), (double)ptr.fHeading);
		
		fprintf(outfile,"missedAltitude=%s>\n", 
			DimString(ptr.fMissedAltitude,szAlt));


		AnalyzeApproachContents(nStart+32,(nStart+ptr.nLen-32), nIcaoId);

		fprintf(outfile,"\t\t</%s>\n",pszName);
	}
	return ptr.nLen;
}

/*
 * analyze and decode aprons
 *
 * Parameters:
 * nOffset: offset within bgl file this apron is at
 *
 * Return value:
 * length of apron chunk
 */
static DWORD AnalyzeAprons(char *pszName, DWORD nOffset, DWORD nIcaoId)
{
	apron_t apron;
	WORD b;
	BYTE bDrawFlags=0;
	char szLat[24], szLon[24];
	int nLat, nLon;
	int nVertexOffset;
	DWORD nAdditionalLen=0;

	TRACE("AnalyzeAprons\n");
	
	apron.wId = GET_U16(nOffset);
	apron.nLen = GET_U32(nOffset+2);
	apron.bSurface = GET_BYTE(nOffset+6);				// get surface
	apron.wVertexCount = GET_U16(nOffset+7);			// get vertex count

	if (GET_U16(nOffset+apron.nLen)==0x030)			// if we have the huge chunk
	{
		bDrawFlags = GET_BYTE(nOffset+apron.nLen+7);	// then get draw flags
		nAdditionalLen=GET_U32(nOffset+apron.nLen+2);	// read huge chunk length
	}

	if (IS_PASS2)
	{
		if (!nTerse)
			PrintObjectSpec(pszName,nOffset);
		fprintf(outfile,"\t\t<%ss>\n", pszName);
		fprintf(outfile,"\t\t\t<%s surface=\"%s\" drawSurface=\"%s\" drawDetail=\"%s\">\n",
			pszName,
			surfacesTable[GetRwySurface(apron.bSurface)],
			(bDrawFlags & APRON_SURFACE_DRAW) ?
			truthTable[1] : truthTable[0],
			(bDrawFlags & APRON_DETAILS_DRAW) ?
			truthTable[1] : truthTable[0] );
		
		// decode vertex list
		for (b=0, nVertexOffset=nOffset+9; b<apron.wVertexCount; b++, nVertexOffset+=8)
		{
			nLon = GET_S32(nVertexOffset);
			nLat = GET_S32(nVertexOffset+4);
			fprintf(outfile,"\t\t\t\t<Vertex lat=\"%s\" lon=\"%s\" />\n",
				LatString(fslat2lat(nLat),szLat),LatString(fslon2lon(nLon),szLon));

		}

		fprintf(outfile,"\t\t\t</%s>\n\t\t</%ss>\n",pszName,pszName);
	}

	return apron.nLen+nAdditionalLen;
}


/*
 * analyze and decode apron edge lights
 *
 * Parameters:
 * nOffset: offset within bgl file this apron is at
 *
 * Return value:
 * length of apron edge lights chunk
 */
static DWORD AnalyzeApronEdgeLights(char *pszName, DWORD nOffset, DWORD nIcaoId)
{
	apron_edgelights_t lights;
	apron_edgelights_vertex_t *vertices = NULL, *ptr=NULL;
	char *lpSzName = "EdgeLights";
	char szLat[24], szLon[24];
	DWORD nStart=nOffset+24;
	WORD i;

	TRACE("AnalyzeApronEdgeLights\n");

	lights.wId=GET_U16(nOffset);
	lights.nLen=GET_U32(nOffset+2);
	if (IS_PASS2)
	{
		if (!nTerse)
			PrintObjectSpec(pszName,nOffset);
		lights.wUnk1=GET_U16(nOffset+6);
		lights.wVertexCount=GET_U16(nOffset+8);
		lights.wEdgeCount=GET_U16(nOffset+10);
		fprintf(outfile,"\t\t<%s>\n", pszName);

		for (i=0; i<lights.wVertexCount; i++,nStart+=8)
		{
			apron_edgelights_vertex_t *p;

			p = MALLOC(sizeof(apron_edgelights_vertex_t));
			p->nLon=GET_S32(nStart);
			p->nLat=GET_S32(nStart+4);
			p->next=NULL;
			if (!vertices)
				vertices=p;
			else
				ptr->next=p;
			ptr=p;
		}
		for (i=0; i<lights.wEdgeCount; i++,nStart+=8)
		{
			float spacing;
			WORD start, end, lastend;
			int j;

			spacing=GET_FLOAT(nStart);
			start=GET_U16(nStart+4);
			end=GET_U16(nStart+6);

			if (i!=0 && start!=lastend)
				fprintf(outfile,"\t\t\t</%s>\n",lpSzName);

			if (i==0 || start!=lastend)
			{
				fprintf(outfile,"\t\t\t<%s>\n",lpSzName);
				for (j=0,ptr=vertices; j<start; j++,ptr=ptr->next);
				fprintf(outfile,"\t\t\t\t<Vertex lat=\"%s\" lon=\"%s\" />\n",
					LatString(fslat2lat(ptr->nLat),szLat),
					LatString(fslon2lon(ptr->nLon),szLon));
			}
			for (j=0,ptr=vertices; j<end; j++,ptr=ptr->next);
			fprintf(outfile,"\t\t\t\t<Vertex lat=\"%s\" lon=\"%s\" />\n",
				LatString(fslat2lat(ptr->nLat),szLat),
				LatString(fslon2lon(ptr->nLon),szLon));
			lastend=end;
		}
		fprintf(outfile,"\t\t\t</%s>\n",lpSzName);
		fprintf(outfile,"\t\t</%s>\n",pszName);
	}
	return lights.nLen;
}

/*
 * analyze and decode blastpad, overrun and threshold
 *
 * Parameters:
 * nOffset: offset within bgl file this runway is at
 *
 * Return value:
 * length of chunk
 */
static DWORD AnalyzeBlast(const DWORD nSubOffset)
{

	blastpad_t bp;
	bp.wId=GET_U16(nSubOffset);
	bp.nLen=GET_S32(nSubOffset+2);
	bp.wSurface=GET_U16(nSubOffset+6);
	bp.fLength=GET_FLOAT(nSubOffset+8);
	bp.fWidth=GET_FLOAT(nSubOffset+8);
	PrintOrBpTsInfo(&bp);
	return bp.nLen;
}

/*
 * analyze and decode runways
 *
 * Parameters:
 * nOffset: offset within bgl file this runway is at
 *
 * Return value:
 * length of runway chunk
 */
static DWORD AnalyzeRunway(char *pszName, DWORD nOffset, DWORD nIcaoId)
{
	runway_t rwy;
	char szLat[24], szLon[24], szAlt[24];
	char szLen[24], szWidth[24];
	WORD wId;
	WORD wLen;
	DWORD nSubStart;
	DWORD nSubEnd;
	DWORD nSubOffset;

	dwnode_t *ptr;
	char szRwyNum[16];
	dwlist_t *vasis = dwlist_init();
	dwlist_t *thresholds = dwlist_init();
	dwlist_t *blastpads = dwlist_init();
	dwlist_t *over_runs = dwlist_init();
	dwlist_t *approach_lights = dwlist_init();

	TRACE("AnalyzeRunway\n");

	rwy.wId=GET_U16(nOffset);
	rwy.nLen=GET_U32(nOffset+2);
	if (IS_PASS2)
	{
		rwy.wSurface=GET_U16(nOffset+6);
		rwy.bStartNumber=map.ptr[nOffset+8];
		rwy.bStartDesignator=map.ptr[nOffset+9];
		rwy.bEndNumber=map.ptr[nOffset+10];
		rwy.bEndDesignator=map.ptr[nOffset+11];
		rwy.nPrimaryIlsId=GET_U32(nOffset+12);
		rwy.nSecondaryIlsId=GET_U32(nOffset+16);
		rwy.nLon=GET_S32(nOffset+20);
		rwy.nLat=GET_S32(nOffset+24);
		rwy.nAlt=GET_S32(nOffset+28);
		rwy.fLength=GET_FLOAT(nOffset+32);
		rwy.fWidth=GET_FLOAT(nOffset+36);
		rwy.fHeading=GET_FLOAT(nOffset+40);
		rwy.fPatternAlt=GET_FLOAT(nOffset+44);
		rwy.wMarkings=GET_U16(nOffset+48);
		rwy.bLights=map.ptr[nOffset+50];
		rwy.bPatternFlags=map.ptr[nOffset+51];

		if (!nTerse)
			PrintObjectSpec(pszName,nOffset);

		fprintf(outfile,"\t\t<%s lat=\"%s\" lon=\"%s\" alt=%s\n",
			pszName,
			LatString(fslat2lat(rwy.nLat),szLat),
			LatString(fslon2lon(rwy.nLon),szLon),
			AltString(rwy.nAlt,szAlt));

		fprintf(outfile,"\t\t\tsurface=\"%s\" heading=\"%0.2lf\" length=%s width=%s\n",
			surfacesTable[GetRwySurface(rwy.wSurface)],
			(double)rwy.fHeading,
			DimString(rwy.fLength,szLen),
			DimString(rwy.fWidth,szWidth));

		strcpy(szRwyNum,GetRwyNumber(rwy.bStartNumber));
		if (rwy.bStartDesignator || rwy.bEndDesignator)
			fprintf(outfile,"\t\t\tnumber=\"%s\" primaryDesignator=\"%s\" secondaryDesignator=\"%s\"\n",
				szRwyNum,
				lrcTable[rwy.bStartDesignator],
				lrcTable[rwy.bEndDesignator]);
		else
			fprintf(outfile,"\t\t\tnumber=\"%s\" designator=\"NONE\"\n",
				szRwyNum);

		fprintf(outfile,"\t\t\tpatternAltitude=%s\n",
			DimString(rwy.fPatternAlt,szAlt));

		fprintf(outfile,"\t\t\tprimaryTakeoff=\"%s\" ",
			(rwy.bPatternFlags & PATTERN_NO_PRIM_TAKEOFF) ?
			YesNoTable[0] : YesNoTable[1] );

		fprintf(outfile,"primaryLanding=\"%s\" ",
			(rwy.bPatternFlags & PATTERN_NO_PRIM_LANDING) ?
			YesNoTable[0] : YesNoTable[1]);

		fprintf(outfile,"primaryPattern=\"%s\"\n",
			(rwy.bPatternFlags & PATTERN_PRIMARY_RIGHT) ?
			lrcTable[2] : lrcTable[1]);

		fprintf(outfile,"\t\t\tsecondaryTakeoff=\"%s\" ",
			(rwy.bPatternFlags & PATTERN_NO_SEC_TAKEOFF) ?
			YesNoTable[0] : YesNoTable[1] );

		fprintf(outfile,"secondaryLanding=\"%s\" ",
			(rwy.bPatternFlags & PATTERN_NO_SEC_LANDING) ?
			YesNoTable[0] : YesNoTable[1]);

		fprintf(outfile,"secondaryPattern=\"%s\">\n",
			(rwy.bPatternFlags & PATTERN_SECONDARY_RIGHT) ?
			lrcTable[2] : lrcTable[1]);

		if (rwy.wMarkings>0)		// runway has markings
		{

			fprintf(outfile,"\t\t\t<Markings ");
			fprintf(outfile,"edges=\"%s\" threshold=\"%s\"\n",
				(rwy.wMarkings & MARKING_EDGE) ?
				truthTable[1] : truthTable[0],
				(rwy.wMarkings & MARKING_THRESHOLD) ?
				truthTable[1] : truthTable[0]);

			fprintf(outfile,"\t\t\t\tfixedDistance=\"%s\" touchdown=\"%s\"\n",
				(rwy.wMarkings & MARKING_FIXED) ?
				truthTable[1] : truthTable[0],
				(rwy.wMarkings & MARKING_TOUCHDOWN) ?
				truthTable[1] : truthTable[0]);

			fprintf(outfile,"\t\t\t\tdashes=\"%s\" ident=\"%s\"\n",
				(rwy.wMarkings & MARKING_DASHES) ?
				truthTable[1] : truthTable[0],
				(rwy.wMarkings & MARKING_IDENT) ?
				truthTable[1] : truthTable[0]);

			fprintf(outfile,"\t\t\t\tprecision=\"%s\" edgePavement=\"%s\"\n",
				(rwy.wMarkings & MARKING_PRECISION) ?
				truthTable[1] : truthTable[0],
				(rwy.wMarkings & MARKING_EDGE_PAVEMENT) ?
				truthTable[1] : truthTable[0]);

			fprintf(outfile,"\t\t\t\tsingleEnd=\"%s\" primaryClosed=\"%s\"\n",
				(rwy.wMarkings & MARKING_SINGLE_END) ?
				truthTable[1] : truthTable[0],
				(rwy.wMarkings & MARKING_PRIMARY_CLOSED) ?
				truthTable[1] : truthTable[0]);

			fprintf(outfile,"\t\t\t\tsecondaryClosed=\"%s\"\n",
				(rwy.wMarkings & MARKING_SECONDARY_CLOSED) ?
				truthTable[1] : truthTable[0]);

			fprintf(outfile,"\t\t\t\tprimaryStol=\"%s\" secondaryStol=\"%s\" />\n",
				(rwy.wMarkings & MARKING_PRIMARY_STOL) ?
				truthTable[1] : truthTable[0],
				(rwy.wMarkings & MARKING_SECONDARY_STOL) ?
				truthTable[1] : truthTable[0]);
		}


		if (rwy.bLights>0)		// runway has lights
		{

			fprintf(outfile,"\t\t\t<Lights ");
			if (GET_FLAG(rwy.bLights,LIGHTS_CENTER,LIGHTS_CENTER_LOW))
				fprintf(outfile,"center=\"LOW\" ");
			else if (GET_FLAG(rwy.bLights,LIGHTS_CENTER,LIGHTS_CENTER_MEDIUM))
				fprintf(outfile,"center=\"MEDIUM\" ");
			else if (GET_FLAG(rwy.bLights,LIGHTS_CENTER,LIGHTS_CENTER_HIGH))
				fprintf(outfile,"center=\"HIGH\" ");

			if (GET_FLAG(rwy.bLights,LIGHTS_EDGE,LIGHTS_EDGE_LOW))
				fprintf(outfile,"edge=\"LOW\" ");
			else if (GET_FLAG(rwy.bLights,LIGHTS_EDGE,LIGHTS_EDGE_MEDIUM))
				fprintf(outfile,"edge=\"MEDIUM\" ");
			else if (GET_FLAG(rwy.bLights,LIGHTS_EDGE,LIGHTS_EDGE_HIGH))
				fprintf(outfile,"edge=\"HIGH\" ");

			fprintf(outfile,"centerRed=\"%s\" ",
				(rwy.bLights & LIGHTS_CENTERED) ?
				truthTable[1] : truthTable[0]);
			fprintf(outfile,"/>\n");
		}







/*
      <xs:element name="Markings" type="ctMarkings" minOccurs="0" maxOccurs="unbounded" />
      <xs:element name="Lights" type="ctLights" minOccurs="0" maxOccurs="unbounded" />
      <xs:element name="OffsetThreshold" type="ctOffsetThreshold" minOccurs="0" maxOccurs="unbounded" />
      <xs:element name="BlastPad" type="ctBlastPad" minOccurs="0" maxOccurs="unbounded" />
      <xs:element name="Overrun" type="ctOverrun" minOccurs="0" maxOccurs="unbounded" />
      <xs:element name="ApproachLights" type="ctApproachLights" minOccurs="0" maxOccurs="unbounded" />
      <xs:element name="Vasi" type="ctVasi" minOccurs="0" maxOccurs="unbounded" />
      <xs:element name="Ils" type="ctIls" minOccurs="0" maxOccurs="unbounded" />
      <xs:element name="RunwayStart" type="ctRunwayStart" minOccurs="0" maxOccurs="unbounded" />

*/




		// 1 analyze sub-navaids and collect informations about then


		// we have to see if runway contains blastpads, overruns etc.
		nSubStart = 52 + nOffset;
		nSubEnd = nOffset + rwy.nLen;

		while (nSubStart<nSubEnd)
		{
			nSubOffset = nSubStart;
			wId = GET_U16(nSubOffset);
			switch (wId)
			{
			case 0x0B: // primary end vasi
			case 0x0C: // primary end vasi
			case 0x0D: // secondary end vasi
			case 0x0E: // secondary end vasi
				dwlist_add(vasis,nSubOffset,0);
				nSubStart+=GET_S32(nSubOffset+2);
				break;

			case 0x5: // primary end threshold
			case 0x6: // secondary end threshold
				dwlist_add(thresholds,nSubOffset,0);
				nSubStart+=GET_S32(nSubOffset+2);
				break;

			case 0x7: // primary end blastpad
			case 0x8: // secondary end blastpad
				dwlist_add(blastpads,nSubOffset,0);
				nSubStart+=GET_S32(nSubOffset+2);
				break;
				
			case 0x9: // primary end overrun
			case 0xA: // secondary end overrun
				dwlist_add(over_runs,nSubOffset,0);
				nSubStart+=GET_S32(nSubOffset+2);
				break;

			case 0x0F: // primary end approach lights
			case 0x10: // secondary end approach lights
				dwlist_add(approach_lights,nSubOffset,0);
				nSubStart+=GET_S32(nSubOffset+2);
				break;

			default:
				wLen=GET_U16(nSubOffset+2);
				nSubStart+=wLen;	// ad hoc
				break;
			}
		}

		// analyze and print threshold
		for (ptr=dwlist_first(thresholds); ptr; ptr=ptr->next)
		{
			AnalyzeBlast(ptr->value);
		}

		// analyze and print blastpad
		for (ptr=dwlist_first(blastpads); ptr; ptr=ptr->next)
		{
			AnalyzeBlast(ptr->value);
		}

		// analyze and print overruns
		for (ptr=dwlist_first(over_runs); ptr; ptr=ptr->next)
		{
			AnalyzeBlast(ptr->value);
		}

		// analyze and print overruns
		for (ptr=dwlist_first(approach_lights); ptr; ptr=ptr->next)
		{
			AnalyzeApproachLights(ptr->value);
		}

		
		// analyze and print vasis
		for (ptr=dwlist_first(vasis); ptr; ptr=ptr->next)
		{
			AnalyzeVasi(ptr->value);
		}




/*		while (nSubStart<nSubEnd)
		{
			nSubOffset = nSubStart;
			wId = GET_U16(nSubOffset);
			switch (wId)
			{
			case 0x5: // primary end threshold
			case 0x6: // secondary end threshold
			case 0x7: // primary end blastpad
			case 0x8: // secondary end blastpad
			case 0x9: // primary end overrun
			case 0xA: // secondary end overrun
				bp.wId=wId;
				bp.nLen=GET_S32(nSubOffset+2);
				bp.wSurface=GET_U16(nSubOffset+6);
				bp.fLength=GET_FLOAT(nSubOffset+8);
				bp.fWidth=GET_FLOAT(nSubOffset+8);
				PrintOrBpTsInfo(&bp);
				nSubStart+=bp.nLen;	// ad hoc
				break;
			case 0x0B: // primary end vasi
			case 0x0C: // primary end vasi
			case 0x0D: // secondary end vasi
			case 0x0E: // secondary end vasi
				nSubStart+=AnalyzeVasi(nSubOffset);
				break;
			case 0x0F: // primary end approach lights
			case 0x10: // secondary end approach lights
				nSubStart+=AnalyzeApproachLights(nSubOffset);
				break;
			default:
				wLen=GET_U16(nSubOffset+2);
				nSubStart+=wLen;	// ad hoc
				break;
			}
		}*/


		dwlist_free(&vasis);
		dwlist_free(&thresholds);
		dwlist_free(&blastpads);
		dwlist_free(&over_runs);
		dwlist_free(&approach_lights);
		
		// see if the runway has ILS
		LookupIls(rwy.nPrimaryIlsId, rwy.nSecondaryIlsId);

		fprintf(outfile,"\t\t</%s>\n",pszName);
	}
	return rwy.nLen;
}


/*
 * analyze and decode frequencies
 *
 * Parameters:
 * nOffset: offset within bgl file this frequency is at
 *
 * Return value:
 * length of chunk
 */
static DWORD AnalyzeFrequency(char *pszName, DWORD nStart, DWORD nIcaoId)
{
	WORD wLen;
	aptcomm_t comm;
	char szFreqName[48];

	TRACE("AnalyzeFrequency\n");

	wLen = GET_U16(nStart+2);	// read length
	comm.wCommType = GET_U16(nStart+6);
	comm.nFreq = GET_S32(nStart+8);

	if (IS_PASS2)
	{
		if (!nTerse)
			PrintObjectSpec(pszName,nStart);
		memset(szFreqName,0x0,sizeof(szFreqName));
		memcpy(szFreqName,&map.ptr[nStart+12],wLen-12);

		fprintf(outfile,"\t\t<%s frequency=\"%0.3lf\" type=\"%s\" name=",
					pszName,
					(double)comm.nFreq/1000000, commTable[comm.wCommType]);
		
		PrintXmlString(szFreqName,0);

		fprintf(outfile," />\n");

	}
	return wLen;
}


static DWORD AnalyzeFence(char *pszName, DWORD nStart, DWORD nIcaoId)
{
	int i;
	fence_t fence;
	int lat,lon;
	char szLat[32], szLon[32];
	fence.wId = GET_U16(nStart);
	fence.nLen=GET_U32(nStart+2);
	if (IS_PASS2)
	{
		fence.wUnknown = GET_U16(nStart+4);
		fence.wVertexCount = GET_U16(nStart+6);
		memcpy(&fence.InstanceId, OFFSET(nStart+8), sizeof(GUID));
		memcpy(&fence.ProfileId, OFFSET(nStart+24), sizeof(GUID));

		fprintf(outfile,"\t\t<%s\n\t\t\tinstanceId=\"{%0.8x-%0.4x-%0.4x-",
			pszName, fence.InstanceId.Data1, fence.InstanceId.Data2,
			fence.InstanceId.Data3);
		for (i=0; i<8; i++)
		{
			fprintf(outfile,"%0.2x", fence.InstanceId.Data4[i]);
			if (i==1)
				fprintf(outfile,"-");
		}
		fprintf(outfile,"}\"\n\t\t\t");


		fprintf(outfile,"profile=\"{%0.8x-%0.4x-%0.4x-",
			fence.ProfileId.Data1, fence.ProfileId.Data2,
			fence.ProfileId.Data3);
		for (i=0; i<8; i++)
		{
			fprintf(outfile,"%0.2x", fence.ProfileId.Data4[i]);
			if (i==1)
				fprintf(outfile,"-");
		}
		fprintf(outfile,"}\" >\n");


		nStart+=40;	// position nStart to vertex list
		for (i=0; i<fence.wVertexCount; i++)
		{
			lat = GET_S32(nStart+4);
			lon = GET_S32(nStart);
			fprintf(outfile,"\t\t\t<Vertex lat=\"%s\" lon=\"%s\" />\n",
					LatString(fslat2lat(lat),szLat),
					LatString(fslon2lon(lon),szLon));
			nStart+=8;

		}


		fprintf(outfile,"\t\t</%s>\n", pszName);

	}
	return fence.nLen;
}

/*
 * decode table
 */
typedef struct
{
	WORD wId;
	char *pszRecName;
	DWORD (*func)(char *, DWORD, DWORD);
} ap_decode_table_t;

ap_decode_table_t apd[] =
{
//		ID,			NAME				FUNC		
	{	0x0004,		"Runway",			AnalyzeRunway				},
	{	0x0011,		"Start",			AnalyzeRunwayStart			},
	{	0x0012,		"Com",				AnalyzeFrequency			},
	{	0x001A,		"TaxiwayPoint",		AnalyzeTaxiwayPoint			},
	{	0x001B,		"TaxiwayParking",	AnalyzeTaxiwayParking		},
	{	0x001C,		"TaxiwayPath",		AnalyzeTaxiwayPaths			},
	{	0x001D,		"TaxiName",			AnalyzeTaxiName				},
	{	0x0024,		"Approach",			AnalyzeApproach				},
	{	0x0026,		"Helipad",			AnalyzeHelipad				},
	{	0x0031,		"ApronEdgeLights",	AnalyzeApronEdgeLights		},
	{	0x0033,		"DeleteAirport",	AnalyzeDeleteRecords		},
	{	0x0037,		"Apron",			AnalyzeAprons				},
	{	0x0038,		"BlastFence",		AnalyzeFence				},
	{	0x0039,		"BoundaryFence",	AnalyzeFence				},
	{	0x003d,		"TaxiwayParking",	AnalyzeTaxiwayParking		},	/* FSX version */
	{	0x0000,		"NULL",				NULL						}
};


/*
 * Analyzes and decode airport services
 *
 * Parameters:
 * v - fuel value
 *
 * Return value:
 * none
 */
static void DoDecodeServices(DWORD v)
{
	fprintf(outfile,"\t\t<Services>\n");
	get_fuel_kind(v);
	fprintf(outfile,"\t\t</Services>\n");
}


/*
 * Analyzes and decode Airports
 *
 * Parameters:
 * nGrpCount - number of Airports available in this group
 * nGrpOffset - offset to current Airports chunk
 * nGrpLen - current chunk length
 *
 * Return value:
 * none
 */
void AnalyzeApt(DWORD nGrpCount, DWORD nGrpOffset, DWORD nChunkLen)
{
	char *lpSzName = "Airport";
	airport_t apt;
    char szDesc[48];
	char szId[6];
	char szLat[24], szLon[24], szAlt[24];
	char szUnknown[80];
	WORD wId;
	DWORD nLen;
    int i,j;
	BYTE a,b;
	DWORD nStart, nEnd;
    DWORD nBeginOfRec;
	name_hdr_t lpName;
    DWORD nSubStart, nSubEnd;
    DWORD nSubBeginOfRec;
	int bHasDeleteChunk;
	DWORD nDeleteChunkStart;
	DWORD nDeleteChunkLen;

    TRACE("AnalyzeApt\n");
	
	nStart = (DWORD)nGrpOffset;
    nEnd = (DWORD)nGrpOffset+(DWORD)nChunkLen;

    while (nStart<nEnd)			// while we have stations
	{
		SET_PASS2;
		nBeginOfRec = nStart;
		bHasDeleteChunk = 0;

		// get airport info
		apt.wId = GET_U16(nBeginOfRec);		/* 3=FS9, 3c=FSX */
		apt.nLen = GET_U32(nBeginOfRec+2);
		apt.nLon = GET_S32(nBeginOfRec+12);
		apt.nLat = GET_S32(nBeginOfRec+16);
		apt.nAlt = GET_S32(nBeginOfRec+20);
		apt.nTowerLon = GET_S32(nBeginOfRec+24);
		apt.nTowerLat = GET_S32(nBeginOfRec+28);
		apt.nTowerAlt = GET_S32(nBeginOfRec+32);
		apt.fMagVar = GET_FLOAT(nBeginOfRec+36);
		apt.nId  = GET_U32(nBeginOfRec+40);		/* ICAO */
		apt.nServices = GET_U32(nBeginOfRec+48);

		if (apt.wId==OBJTYPE_AIRPORT_FSX)
			nBeginOfRec+=4;		/* Skip unknown FSX entry (airportTestRadius & trafficScalar ?) */

		if (nPartialDecode)		// if partial decode is enabled
		{
			if (gcdist(fCenterLat,fCenterLon,
				fslat2lat(apt.nLat),fslon2lon(apt.nLon))>fCenterRad)
			{
				goto skip;	// skip the record if too far away
			}
		}

		if (!nTerse)
			PrintObjectSpec(lpSzName,nBeginOfRec);
		
		nDeleteChunkStart = nDeleteChunkLen = 0;
		wId = GET_U16(nBeginOfRec+52);
		if (wId==APTENTRY_DELAPT)				// we have a deleteAirport chunk
		{										// so we have to move to real name
			bHasDeleteChunk = 1;				// offset and come back here later
			nDeleteChunkStart = nBeginOfRec+52;	// mark start of chunk
			nDeleteChunkLen= GET_U32(nBeginOfRec+54);	// get length of chunk
		}

		lpName.wId = GET_U16(nBeginOfRec+52+nDeleteChunkLen);
		lpName.nStrLen = GET_S32(nBeginOfRec+54+nDeleteChunkLen);

		memset(szDesc,0x0,sizeof(szDesc));

		// read the descriptive name
		memcpy(szDesc,&map.ptr[nBeginOfRec+58+nDeleteChunkLen],lpName.nStrLen-6);

		memset(szId,0x0,sizeof(szId));
		DecodeIdStr(apt.nId,szId,0x41);	// convert the packed ICAO ID


		nSubStart = 52+lpName.nStrLen+nBeginOfRec+nDeleteChunkLen;
		nSubEnd = apt.nLen+nStart;

		// print airport info to file
		fprintf(outfile,"\t<%s ident=\"%s\" name=",
			lpSzName,szId);

		PrintXmlString(szDesc,0);
		fprintf(outfile,"\n");

		fprintf(outfile,"\t\tlat=\"%s\" lon=\"%s\"\n",
			LatString(fslat2lat(apt.nLat),szLat),
			LatString(fslon2lon(apt.nLon),szLon));
		fprintf(outfile,"\t\tmagvar=\"%0.2lf\" alt=%s",
			MAGVAR(apt.fMagVar), AltString(apt.nAlt,szLat));

		// look-up icao id table
		for (i=0; i<cicaos.nCount; i++)
		{
			if (apt.nId==cicaos.cicao[i].nId)
			{
				if (NULL!=ccities)		// look for city
				{
					if (cicaos.cicao[i].wCitiesIndex<ccities->nCount)
						if (*ccities->ptr[cicaos.cicao[i].wCitiesIndex].s)
						{
							fprintf(outfile,"\n\t\tcity=");
							PrintXmlString(ccities->ptr[cicaos.cicao[i].wCitiesIndex].s,0);
						}
				}

				if (NULL!=cstates)		// look for state
				{
					a = cicaos.cicao[i].bStateIndex >> 4;
					b = cicaos.cicao[i].bUnk2 & 0xf;
					j = ((b << 4) | a);
					if (j>=0 && j<cstates->nCount)
						if (*cstates->ptr[j].s)
						{
							fprintf(outfile,"\n\t\tstate=");
							PrintXmlString(cstates->ptr[j].s,0);
						}
				}

				if (NULL!=ccountries)	// look for country
				{
					j = cicaos.cicao[i].bCountryIndex & 0xf;
					if (j>=0 && j<ccountries->nCount)
						if (*ccountries->ptr[j].s)
						{
							fprintf(outfile,"\n\t\tcountry=");
							PrintXmlString(ccountries->ptr[j].s,0);
						}
				}

				if (NULL!=cregions)		// look for region
				{
					j = cicaos.cicao[i].bRegionIndex & 0xf;
					if (j>=0 && j<cregions->nCount)
						if (*cregions->ptr[j].s)
						{
							fprintf(outfile,"\n\t\tregion=");
							PrintXmlString(cregions->ptr[j].s,0);
						}
				}
			}
		}
		fprintf(outfile,">\n");

		// if we have a tower, let's print it
//		if (apt.nTowerAlt!=0 && apt.nTowerLat!=0 && apt.nTowerLon!=0)

		if (apt.nTowerLat!=0x10000000 && apt.nTowerLon!=0x18000000)
		{
			if (apt.nTowerAlt==0)
				apt.nTowerAlt = apt.nAlt;

			/* Hack - check for attached object */
			if (GET_U16(nSubStart)!=OBJTYPE_TOWER_OBJ)
				fprintf(outfile,"\t\t<Tower lat=\"%s\" lon=\"%s\" alt=%s />\n",
						LatString(fslat2lat(apt.nTowerLat),szLat),
						LatString(fslon2lon(apt.nTowerLon),szLon),
						AltString(apt.nTowerAlt,szAlt));
			else
			{
				fprintf(outfile,"\t\t<Tower lat=\"%s\" lon=\"%s\" alt=%s>\n",
						LatString(fslat2lat(apt.nTowerLat),szLat),
						LatString(fslon2lon(apt.nTowerLon),szLon),
						AltString(apt.nTowerAlt,szAlt));
				while (GET_U16(nSubStart)==OBJTYPE_TOWER_OBJ)
				{
					nLen = GET_U32(nSubStart+2);
					AnalyzeSceneryObject(1, nSubStart+10, nLen-12);
					nSubStart+=	nLen;
				}
				fprintf(outfile,"\t\t</Tower>\n");
			}
		}

		if (bHasDeleteChunk)	// if we have delete records, dump them
			AnalyzeDeleteRecords("DeleteAirport",nDeleteChunkStart, apt.nId);

		if (apt.nServices!=0)	// if we have services dump them
			DoDecodeServices(apt.nServices);

        // see what we have under this airport
		while (nSubStart<nSubEnd)
		{
			nSubBeginOfRec = nSubStart;
			wId = GET_U16(nSubBeginOfRec);

			i = 0;
			j=0;
			while (apd[i].wId!=0)		// browse procedural table
			{
				if (wId==apd[i].wId)	// if IDs match
				{
					j=1;							// signal record found
					nSubStart+=(* apd[i].func)(
						apd[i].pszRecName,			// execute decode function
						nSubBeginOfRec, apt.nId);
					break;							// keep going
				}
				i++;
			}
			if (j==0)	// record not found
			{
				nLen = GET_U32(nSubBeginOfRec+2); 	// read length
				if (!nTerse && wId!=0x30 /* apron sub-chunks*/)
				{
					sprintf(szUnknown,"dumping unknown record (0x%x), len: %d",
						wId, nLen);
					PrintObjectSpec(szUnknown,nSubBeginOfRec);

					DumpToHex(nSubBeginOfRec,nLen);
				}
				nSubStart+=nLen; // increase
			}

		} // while
		
		// see if we have taxiway signs within this airport
		LookupTaxiSign(fslat2lat(apt.nLat), fslon2lon(apt.nLon));
		LookUpWaypoints(szId);

		fprintf(outfile,"\t</%s>\n",lpSzName);		// we are at end
		fprintf(outfile,"\n");						// bye bye
skip:
		nStart+=apt.nLen;							// advance to next station
	}
}
