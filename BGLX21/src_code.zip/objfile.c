/*
 *   $Id: objfile.c,v 1.2 2004/04/08 11:57:15 Alessandro Exp $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: module to parse objfile.txt $
 *
 *   $Log: objfile.c,v $
 *   Revision 1.2  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.1  2004/02/12 15:17:07  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"

/*
 * Allocate object file to memory
 *
 * Parameters:
 * szName - name of file to allocate
 * lpMap - pointer to structure which receives allocation info
 *
 * Return value:
 * 0 on success
 */
static DWORD AllocateObjFile(const char *szName, map_file_t *lpMap)
{

	char buff[512];
	DWORD dwErr;

#ifdef NT_API_CALLS
	HANDLE fh;
	WIN32_FIND_DATA fd;
	memset(lpMap,0x0,sizeof(map_file_t));			// initialize map structure
	fh = FindFirstFile(szName, &fd);				// see if file exists
	if (fh==INVALID_HANDLE_VALUE)
	{
		dwErr=GetLastError();						// if error
		sprintf(buff, CANTOPENFILE,
			szName);								// format error message
		PrintError(buff,dwErr); 					// display error
		return dwErr;								// return failure
	}

	lpMap->dwSize = fd.nFileSizeLow;				// get file size
	FindClose(fh);									// close find handle


	if (lpMap->dwSize==0)							// if bogus size
	{
		sprintf(buff, BOGUSFILESIZE,szName);
		return 5;									// return failure
	}

	lpMap->hFile = CreateFile(szName, GENERIC_READ, FILE_SHARE_READ, NULL,
			OPEN_EXISTING, FILE_ATTRIBUTE_READONLY, NULL);
	if (lpMap->hFile == INVALID_HANDLE_VALUE)
	{
		dwErr=GetLastError();						// if error
		sprintf(buff, CANTOPENFILE,
				szName);							// format error message
		PrintError(buff,dwErr); 					// display error
		lpMap->hFile=0;								// invalidate handle
		return dwErr;								// return failure
	}

	lpMap->hMap = CreateFileMapping(lpMap->hFile, NULL, PAGE_READONLY, 0, 0,
			"xml_obj_file");						// try to open file mapping
	dwErr = GetLastError(); 						// check for error
	if ((lpMap->hMap != NULL) && (dwErr == ERROR_ALREADY_EXISTS))
	{
		sprintf(buff,DUPEFILEMAPPING,szName);
		CloseHandle(lpMap->hMap);
		CloseHandle(lpMap->hFile);
		PrintError(buff,dwErr); 					// display error
		lpMap->hFile=0;								// invalidate handle
		lpMap->hMap=0;
		return dwErr;								// return failure
	}
	else if (lpMap->hMap == NULL)
	{
		sprintf(buff, FILEMAPPINGFAILED, szName);
		CloseHandle(lpMap->hMap);
		CloseHandle(lpMap->hFile);
		PrintError(buff,dwErr); 					// display error
		map.hFile=0;								// invalidate handle
		map.hMap=0;
		return dwErr;								// return failure
	}

	lpMap->ptr = (BYTE *) MapViewOfFile(lpMap->hMap, FILE_MAP_READ,
			0, 0, 0);								// try map file to memory
	if (lpMap->ptr == NULL)
	{
		sprintf(buff, MAPVIEWFAILED,szName);
		CloseHandle(lpMap->hMap);
		CloseHandle(lpMap->hFile);
		PrintError(buff,dwErr); 					// display error
		lpMap->hFile=0;								// invalidate handle
		lpMap->hMap=0;
		return dwErr;								// return failure
	}
#else
	unsigned long ulSize;
	FILE *f = fopen(szName,"rb");
	if (f==NULL)									// if file error
	{
		dwErr=errno;
		sprintf(buff,CANTOPENFILE, szName);	// print error message
		PrintError(buff,dwErr);
		return dwErr;
	}
	memset(lpMap,0x0,sizeof(map_file_t));			// initialize map structure

	fseek(f,0L,SEEK_END);
	ulSize = ftell(f);								// get file size in bytes
	fseek(f,0L,SEEK_SET);							// rewind file pointer

	if (ulSize==0)									// if bogus size
	{
		sprintf(buff, BOGUSFILESIZE,szName);
		fclose(f);									// close file
		return 5;									// return failure
	}

	if (NULL == (lpMap->ptr=(BYTE *)MALLOC(ulSize+1)))
	{
		// not enough memory
		printf("Not enough memory to open %s\n", szName);
		fclose(f);
		return 3;									// signal failure
	}

	fread(lpMap->ptr,ulSize,1,f);					// load file into the buffer
	fclose(f);
	lpMap->dwSize=ulSize;							// mark file size
#endif

	return 0;										// return success
}


void DeallocateObjFile(map_file_t *lpMap)
{
#ifdef NT_API_CALLS
	if (lpMap->ptr!=NULL)
	{
		UnmapViewOfFile(lpMap->ptr);				// unmap file and close
		lpMap->ptr=NULL;
	}
	if (0!=lpMap->hMap)
	{
		CloseHandle(lpMap->hMap);					// close file mapping
		lpMap->hMap=0;
	}
	if (0!=lpMap->hFile)
	{
		CloseHandle(lpMap->hFile);					// close file
		lpMap->hFile=0;
	}
#else
	if (lpMap->ptr)
		FREE(lpMap->ptr);							// free memory
#endif
}



void ParseObjFile(const char *szFileName)
{
	#ifdef DEBUG
	FILE *f;
	#endif
	char key[64];
	char *name;
	map_file_t lpMap;
	char *P, *str;
	char *start, *end;
	int i;
	char *p1, *p2;
	if (0==AllocateObjFile(szFileName,&lpMap))		// allocate the stuff
	{

		start = (char *)lpMap.ptr;					// mark start of file
		end = (char *)lpMap.ptr + lpMap.dwSize;		// mark end of file
	
		while (start<end)							// do parsing
		{
			if (*start==';')						// we found a comment
			{
				while (*start!='\r' && *start!='\n')
					start++;
			}
			else if (*start=='\r')					// cr encountered
				start++;
			else if (*start=='\n')					// lf encountered
				start++;
			else
			{
				P = start;
				while (*start!='\r' && *start!='\n' 
					&& *start!=';')					// while the string is valid
					start++;						// increment it
				
				str = (char *)MALLOC((start-P)+1);	// allocate space for string to parse
				if (str)
				{
					memset(str,0x0,(start-P)+1);	// initialize string
					memmove(str,P,start-P);			// transfer string

					p1 = strtok(str,"{");			// grab first token: name
					ASSERT(p1);
					i = strlen(p1);					// get length of string 
					name = (char *)MALLOC(i+1);
					strcpy(name,p1);
					strltrim(name);					// trim the stuff
					strrtrim(name);
				
					p2 = strtok(NULL,"}");			// grab second token: key
					ASSERT(p2);

					// Munge GUID into plain format
					strltrim(p2);					// trim the stuff
					strlwr(p2);						// convert to lower case
					ASSERT(strlen(p2)>=36);
					strncpy(key,p2,8);
					strncpy(key+8,p2+14,4);
					strncpy(key+12,p2+9,4);
					strncpy(key+16,p2+26,2);
					strncpy(key+18,p2+24,2);
					strncpy(key+20,p2+21,2);
					strncpy(key+22,p2+19,2);
					strncpy(key+24,p2+34,2);
					strncpy(key+26,p2+32,2);
					strncpy(key+28,p2+30,2);
					strncpy(key+30,p2+28,2);
					*(key+32)=0;

					if (-1==ChrPoolAdd(cobjects,key,(int)name))
					{
						FREE(name);
					}
					FREE(str);						// free string
				}
			}
		}
		DeallocateObjFile(&lpMap);					// clean up
	}
	#ifdef DEBUG
	f = fopen("objects.out","wt");
	for (i = 0; i<cobjects->nCount; i++)
		fprintf(f," %s , %s\n", cobjects->ptr[i].s, (char *)cobjects->ptr[i].i);
	fclose(f);
	#endif

}

