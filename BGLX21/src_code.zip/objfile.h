/*
 * $Id: objfile.h,v 1.1 2004/02/12 15:20:59 Alessandro Exp $
 */
#ifndef objfile_h
#define objfile_h

typedef struct tag_obj_entry_t
{
	char key[36];		// 128 bit guid
	char szName[92];	// name of entry
} obj_entry_t;

extern void ParseObjFile(const char *);
extern void AvlFree(void *);


#endif

