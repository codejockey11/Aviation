/*
 *   $Id: anamkb.c,v 1.3 2004/04/08 11:57:15 Alessandro Exp $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: Marker (IMO) record analyzer $
 *
 *   $Log: anamkb.c,v $
 *   Revision 1.3  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.2  2004/02/12 15:17:07  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2004/02/04 14:07:48  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"

static const char *mkbTable[] =
{

	"INNER", "MIDDLE", "OUTER", "BACKCOURSE"
};

/*
 * Analyzes and decode Marker Beacons
 *
 * Parameters:
 * nGrpCount - number of MKB available in this group
 * nGrpOffset - offset to current MKB chunk
 * nGrpLen - current chunk length
 *
 * Return value:
 * none
 */
void AnalyzeMkb(DWORD nGrpCount, DWORD nGrpOffset, DWORD nChunkLen)
{
	WORD wType;				// navaid type - 0x18 for marker
	WORD wLen;				// length of record in bytes
	//BYTE bReserved;			// reserved - always 0x0
	WORD wHeading;			// heading in pseudo degrees
	BYTE bMkbType;			// marker type, inner, outer, etc.
	int nLon;				// packed longitude
	int nLat;				// packed latitude
	int nAlt;				// altitude, meters * 1000
	int nId;
	int nRegion;
	char szId[8];			// encrypted navaid ID
	char szRegion[8];		// encrypted navaid Region
	double hdg;
	DWORD i, nBytesRead=0;
	char szLat[24];
	char szLon[24];
	char szAlt[24];
	for (i=0; i<nGrpCount; i++)
	{
		if (nBytesRead>nChunkLen)	// ad hoc
			break;

		wType = GET_U16(nGrpOffset+nBytesRead);
		wLen = GET_U16(nGrpOffset+nBytesRead+2);
		//bReserved = GET_BYTE(nGrpOffset+nBytesRead+4);
		wHeading = GET_U16(nGrpOffset+nBytesRead+5);
		bMkbType = GET_BYTE(nGrpOffset+nBytesRead+7);
		nLon = GET_S32(nGrpOffset+nBytesRead+8);
		nLat = GET_S32(nGrpOffset+nBytesRead+12);
		nAlt = GET_S32(nGrpOffset+nBytesRead+16);
		nId = GET_S32(nGrpOffset+nBytesRead+20);
		nRegion = GET_S32(nGrpOffset+nBytesRead+24);
		hdg = (double)wHeading*360/65280.0;

		if (nPartialDecode)		// if partial decode is enabled
		{
			if (gcdist(fCenterLat,fCenterLon,
				fslat2lat(nLat),fslon2lon(nLon))>fCenterRad)
			{
				goto skip;	// skip the record if too far away
			}
		}

		// many regions are 0 - does FS2004 really use this stuff?
		if (nRegion==0)
			DecodeRegionStr(2,szRegion);
		else
			DecodeRegionStr(nRegion,szRegion);

		// many marker IDs are 7, why?
		if (nId<0x47)
			DecodeIdStr(nId,szId,0x0);
		else
			DecodeIdStr(nId,szId,0x47);

		if (!nTerse)
			PrintObjectSpec("Marker",nGrpOffset+nBytesRead);

		fprintf(outfile,"\t<Marker type=\"%s\" lat=\"%s\" lon=\"%s\"\n"
				"\t\talt=%s heading=\"%0.2lf\" region=\"%s\" ident=\"%s\" />\n",
				mkbTable[bMkbType],
				LatString(ndblat2lat(nLat),szLat),
				LatString(ndblon2lon(nLon),szLon),
				AltString(nAlt,szAlt),
				hdg,szRegion, szId);
		fprintf(outfile,"\n");
skip:
		nBytesRead+=wLen; // ad hoc
	}
	

}
