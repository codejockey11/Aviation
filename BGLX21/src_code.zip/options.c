/*
 *   $Id: options.c,v 1.3 2004/04/08 11:57:15 Alessandro Exp $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: Options switch initialization $
 *
 *   $Log: options.c,v $
 *   Revision 1.3  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.2  2004/02/12 15:17:07  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2004/02/04 14:07:48  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"

int nLatLonAsDeg=0;
int nTerse=0;
int nFeet=0;
int nMiles=0;
int nPartialDecode=0;

UINT nRadius = 0;
char *pszLatStr=0;
char *pszLonStr=0;

double fCenterRad = 0;
double fCenterLat = 0;
double fCenterLon = 0;

Option lpOptions[] =
{
	{ 't', OPT_SWITCH, &nTerse, "Do not print verbose information to output file" },
	{ 'd', OPT_SWITCH, &nLatLonAsDeg, "Print lat/lon as DD/MM/SS instead of decimal deg" },
	{ 'f', OPT_SWITCH, &nFeet, "Print altitudes in feet instead of meters" },
	{ 'm', OPT_SWITCH, &nMiles, "Print ranges in nautical miles instead of meters" },
	{ 'n', OPT_STRING, &pszLatStr, "Center latitude of circle for partial decoding" },
	{ 'e', OPT_STRING, &pszLonStr, "Center longitude of circle for partial decoding" },
	{ 'r', OPT_LUNSIGNED, &nRadius, "Radius of circle (in KM) for partial decoding" }
};

