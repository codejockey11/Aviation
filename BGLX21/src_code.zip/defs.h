/*
 *    $Id: defs.h,v 1.5 2007/10/02 21:48:38 alexanto Exp $
 *    $Desc: compatibility file for cross platform compile $
 */
#ifndef WIN32
	#define TRUE 1
	#define FALSE 0
	#define UNALIGNED
	typedef unsigned char BYTE;
	typedef unsigned short WORD;
	typedef signed long LONG;
	typedef unsigned long DWORD;
	typedef unsigned int UINT;
	typedef int BOOL;
	#define MAKEWORD(a, b)      ((WORD)(((BYTE)(a)) | (((WORD)((BYTE)(b))) << 8)))
	#define MAKELONG(a, b)      ((LONG)(((WORD)(a)) | (((DWORD)((WORD)(b))) << 16)))
	#define LOWORD(l)           ((WORD)(l))
	#define HIWORD(l)           ((WORD)(((DWORD)(l) >> 16) & 0xFFFF))
	#define LOBYTE(w)           ((BYTE)(w))
	#define HIBYTE(w)           ((BYTE)(((WORD)(w) >> 8) & 0xFF))

	typedef struct  _FILETIME
    {
		DWORD dwLowDateTime;
		DWORD dwHighDateTime;
    }	FILETIME;
	typedef struct _GUID {
       DWORD   Data1;
       unsigned short Data2;
       unsigned short Data3;
       unsigned char Data4[8];
   } GUID;
#endif


#ifdef MAC
#define BIG_ENDIAN
#else
#define LITTLE_ENDIAN
#endif

#ifndef min
#define min(a,b) (a < b) ? a : b
#endif

#ifndef max
#define max(a,b) (a > b) ? a : b
#endif



#define LO4BITS(b) (b & 0xf)
#define HI4BITS(b) (b >> 4)

#if (!(defined(WIN32)))
	#ifdef NT_API_CALLS
		#undef NT_API_CALLS
	#endif
#endif

#ifdef _TRACE_
	#define TRACE(x) printf(x);
#else
	#define TRACE(x)
#endif

#ifdef	DEBUG
	extern void AssertFail(char *fname, int lineno);
	#define	ASSERT(x)	if (!(x)) AssertFail(__FILE__, __LINE__)
	#define PRECONDITION(x) ASSERT(x)
#else
	#define	ASSERT(x)
	#define PRECONDITION(x)
#endif

// redefine memory routines
#ifdef NT_API_CALLS
	#define MALLOC(P) GlobalAllocPtr(P)
	#define CALLOC(S,P) MALLOC(S*P)
	#define REALLOC(P,N) GlobalReAllocPtr(P,N)
	#define FREE(P) GlobalFreePtr(P)
#else
	#define MALLOC(P) malloc(P)
	#define CALLOC(S,P) calloc(S,P)
	#define REALLOC(P,N) realloc(P,N)
	#define FREE(P) free(P)
#endif

#ifdef __BORLANDC__
#if (__BORLANDC__ <= 0x460)
#define BC45
#endif
#endif

