/*
 *   $Id: anandb.c,v 1.6 2004/04/08 11:57:15 Alessandro Exp $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: NDB analyzer $
 *
 *   $Log: anandb.c,v $
 *   Revision 1.6  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.5  2004/02/25 13:47:04  alexanto
 *   Added descriptive name print with XML translation
 *
 *   Revision 1.4  2004/02/19 17:51:07  alexanto
 *   Some changes
 *
 *   Revision 1.3  2004/02/16 10:03:01  alexanto
 *   +Id+Log
 *
 *   Revision 1.2  2004/02/12 15:17:07  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2004/02/04 14:07:48  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"


/*
 * Analyzes and decode NDBs
 *
 * Parameters:
 * nGrpCount - number of NDB available in this group
 * nGrpOffset - offset to current NDB chunk
 * nGrpLen - current chunk length
 *
 * Return value:
 * none
 */
void AnalyzeNdb(DWORD nGrpCount, DWORD nGrpOffset, DWORD nChunkLen)
{
	DWORD i,nBytesRead = 0;
	WORD wType;				// navaid type - 0x17 for ndb
	WORD wRegion;			// navaid type - 0x17 for ndb
	UINT nLen;				// length of record in bytes
	WORD wNdbType;			// ndb type, compass_point, h, etc.
	int nFreq;				// navaid frequency * 1000
	int nLon;				// packed longitude
	int nLat;				// packed latitude
	int nAlt;				// navaid altitude, meters * 1000
	float fRange;			// navaid range
	float fMagVar;			// magnetic deviation
	DWORD nId;				// packed navaid ID
	DWORD nRegion;			// packed navaid Region
	WORD wUnk1;				// unknown word 1
	int nNameLen;			// relative pointer to index info ???
	char szDesc[64];		// navaid description
	char szRegion[8];		// unpacked region id
	char szId[16];			// unpacked region id
	char szLat[24];
	char szLon[24];
	char szAlt[24];
	char szRange[24];

	for (i = 0; i<nGrpCount; i++)
	{
		if (nBytesRead>nChunkLen)	// ad hoc
			break;
		

		wType = GET_U16(nGrpOffset+nBytesRead);
		nLen = GET_U32(nGrpOffset+nBytesRead+2);
		wNdbType = GET_U16(nGrpOffset+nBytesRead+6);
		nFreq = GET_U32(nGrpOffset+nBytesRead+8);
		nLon = GET_U32(nGrpOffset+nBytesRead+12);
		nLat = GET_U32(nGrpOffset+nBytesRead+16);

		if (nPartialDecode)		// if partial decode is enabled
		{
			if (gcdist(fCenterLat,fCenterLon,
				fslat2lat(nLat),fslon2lon(nLon))>fCenterRad)
			{
				goto skip;	// skip the record if too far away
			}
		}

		
		nAlt = GET_U32(nGrpOffset+nBytesRead+20);
		fRange = GET_FLOAT(nGrpOffset+nBytesRead+24);
		fMagVar = GET_FLOAT(nGrpOffset+nBytesRead+28);
		nId = GET_U32(nGrpOffset+nBytesRead+32);
		nRegion = GET_U32(nGrpOffset+nBytesRead+36);
		wRegion = GET_U16(nGrpOffset+nBytesRead+36);
		wUnk1 = GET_U16(nGrpOffset+nBytesRead+40);
		nNameLen = GET_U32(nGrpOffset+nBytesRead+42);
		memset(szDesc,0x0,sizeof(szDesc)); // transfer NDB name
		memcpy(szDesc,&map.ptr[nGrpOffset+nBytesRead+46],nNameLen-6);

		if (!nTerse)
			PrintObjectSpec("NDB",nGrpOffset+nBytesRead);
		
		DecodeRegionStr(nRegion,szRegion);
		DecodeIdStr(nId,szId,0x43);
		fprintf(outfile, "\t<Ndb type=\"%s\" name=",
			ndbTable[wNdbType]);
		
		PrintXmlString(szDesc, 0);

		fprintf(outfile, " lat=\"%s\" "
			"lon=\"%s\"\n\t\talt=%s frequency=\"%0.2lf\""
			" range=%s magvar=\"%0.2lf\"\n\t\t"
			"region=\"%s\" ident=\"%s\" />\n",
			 
			LatString(ndblat2lat(nLat),szLat),
			LatString(ndblon2lon(nLon),szLon),
			AltString(nAlt,szAlt), (double)nFreq/1000, 
			RangeString(fRange,szRange), 
			MAGVAR(fMagVar),
			szRegion,szId);
		fprintf(outfile, "\n");
skip:
		nBytesRead+=nLen;
	}
}

