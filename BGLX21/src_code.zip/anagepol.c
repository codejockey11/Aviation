/*
 *   $Id: anagepol.c,v 1.6 2004/04/08 11:57:15 Alessandro Exp $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: Geopol and boundary records analyzer $
 *
 *   $Log: anagepol.c,v $
 *   Revision 1.6  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.5  2004/03/12 15:19:59  alexanto
 *   Added: altitude and anltitude type parameters to Circle
 *
 *   Revision 1.4  2004/02/25 13:47:04  alexanto
 *   Added Boundary decodings
 *
 *   Revision 1.3  2004/02/16 10:03:01  alexanto
 *   Begin adding Boundary extraction
 *
 *   Revision 1.2  2004/02/14 17:47:18  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2004/02/14 17:34:55  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"

/*
 * define a prime numbe table for quickly finding a 
 * prime number
 */
#define PrimeCount 565
#define MaxPrime 4099

static DWORD *HashTab;
static DWORD nHashSize;

WORD Primes[] =
{
        2,    3,    5,    7,   11,   13,   17,   19,   23,   29, 
       31,   37,   41,   43,   47,   53,   59,   61,   67,   71, 
       73,   79,   83,   89,   97,  101,  103,  107,  109,  113, 
      127,  131,  137,  139,  149,  151,  157,  163,  167,  173, 
      179,  181,  191,  193,  197,  199,  211,  223,  227,  229, 
      233,  239,  241,  251,  257,  263,  269,  271,  277,  281, 
      283,  293,  307,  311,  313,  317,  331,  337,  347,  349, 
      353,  359,  367,  373,  379,  383,  389,  397,  401,  409, 
      419,  421,  431,  433,  439,  443,  449,  457,  461,  463, 
      467,  479,  487,  491,  499,  503,  509,  521,  523,  541, 
      547,  557,  563,  569,  571,  577,  587,  593,  599,  601, 
      607,  613,  617,  619,  631,  641,  643,  647,  653,  659, 
      661,  673,  677,  683,  691,  701,  709,  719,  727,  733, 
      739,  743,  751,  757,  761,  769,  773,  787,  797,  809, 
      811,  821,  823,  827,  829,  839,  853,  857,  859,  863, 
      877,  881,  883,  887,  907,  911,  919,  929,  937,  941, 
      947,  953,  967,  971,  977,  983,  991,  997, 1009, 1013, 
     1019, 1021, 1031, 1033, 1039, 1049, 1051, 1061, 1063, 1069, 
     1087, 1091, 1093, 1097, 1103, 1109, 1117, 1123, 1129, 1151, 
     1153, 1163, 1171, 1181, 1187, 1193, 1201, 1213, 1217, 1223, 
     1229, 1231, 1237, 1249, 1259, 1277, 1279, 1283, 1289, 1291, 
     1297, 1301, 1303, 1307, 1319, 1321, 1327, 1361, 1367, 1373, 
     1381, 1399, 1409, 1423, 1427, 1429, 1433, 1439, 1447, 1451, 
     1453, 1459, 1471, 1481, 1483, 1487, 1489, 1493, 1499, 1511, 
     1523, 1531, 1543, 1549, 1553, 1559, 1567, 1571, 1579, 1583, 
     1597, 1601, 1607, 1609, 1613, 1619, 1621, 1627, 1637, 1657, 
     1663, 1667, 1669, 1693, 1697, 1699, 1709, 1721, 1723, 1733, 
     1741, 1747, 1753, 1759, 1777, 1783, 1787, 1789, 1801, 1811, 
     1823, 1831, 1847, 1861, 1867, 1871, 1873, 1877, 1879, 1889, 
     1901, 1907, 1913, 1931, 1933, 1949, 1951, 1973, 1979, 1987, 
     1993, 1997, 1999, 2003, 2011, 2017, 2027, 2029, 2039, 2053, 
     2063, 2069, 2081, 2083, 2087, 2089, 2099, 2111, 2113, 2129, 
     2131, 2137, 2141, 2143, 2153, 2161, 2179, 2203, 2207, 2213, 
     2221, 2237, 2239, 2243, 2251, 2267, 2269, 2273, 2281, 2287, 
     2293, 2297, 2309, 2311, 2333, 2339, 2341, 2347, 2351, 2357, 
     2371, 2377, 2381, 2383, 2389, 2393, 2399, 2411, 2417, 2423, 
     2437, 2441, 2447, 2459, 2467, 2473, 2477, 2503, 2521, 2531, 
     2539, 2543, 2549, 2551, 2557, 2579, 2591, 2593, 2609, 2617, 
     2621, 2633, 2647, 2657, 2659, 2663, 2671, 2677, 2683, 2687, 
     2689, 2693, 2699, 2707, 2711, 2713, 2719, 2729, 2731, 2741, 
     2749, 2753, 2767, 2777, 2789, 2791, 2797, 2801, 2803, 2819, 
     2833, 2837, 2843, 2851, 2857, 2861, 2879, 2887, 2897, 2903, 
     2909, 2917, 2927, 2939, 2953, 2957, 2963, 2969, 2971, 2999, 
     3001, 3011, 3019, 3023, 3037, 3041, 3049, 3061, 3067, 3079, 
     3083, 3089, 3109, 3119, 3121, 3137, 3163, 3167, 3169, 3181, 
     3187, 3191, 3203, 3209, 3217, 3221, 3229, 3251, 3253, 3257, 
     3259, 3271, 3299, 3301, 3307, 3313, 3319, 3323, 3329, 3331, 
     3343, 3347, 3359, 3361, 3371, 3373, 3389, 3391, 3407, 3413, 
     3433, 3449, 3457, 3461, 3463, 3467, 3469, 3491, 3499, 3511, 
     3517, 3527, 3529, 3533, 3539, 3541, 3547, 3557, 3559, 3571, 
     3581, 3583, 3593, 3607, 3613, 3617, 3623, 3631, 3637, 3643, 
     3659, 3671, 3673, 3677, 3691, 3697, 3701, 3709, 3719, 3727, 
     3733, 3739, 3761, 3767, 3769, 3779, 3793, 3797, 3803, 3821, 
     3823, 3833, 3847, 3851, 3853, 3863, 3877, 3881, 3889, 3907, 
     3911, 3917, 3919, 3923, 3929, 3931, 3943, 3947, 3967, 3989, 
     4001, 4003, 4007, 4013, 4019, 4021, 4027, 4049, 4051, 4057, 
     4073, 4079, 4091, 4093, 4099
};


/*
 * Get the closest prime number to a given value
 * (ported from Julian Bucknall's EZ Delphi structure library)
 * 
 * parameters:
 * N: value to get prime number from
 *
 * return:
 * prime number
 */
DWORD GetClosestPrime(DWORD N)
{
	DWORD L, R, M;
	DWORD RootN;
	BOOL IsPrime;
	DWORD DivisorIndex;
	DWORD nRes;

	if (N <= 2)							// treat 2 as a special case
    {
		return N;
	}
	
	if ((N % 2) != 0)					// make the result equal to N, and 
	{									// if it's even, the next odd number
		nRes = N;
	}
	else
	{
		nRes = N+1;
	}
	
	if (nRes <= MaxPrime)				// if the result is within our prime 
	{									// number table, use binary search to
	    L = 0;							//  find the equal or next prime number
		R = PrimeCount-1;
		while (L <= R)
		{
			M = (L + R) >> 1;
			if (nRes == Primes[M])
				return nRes;
			else if (nRes < Primes[M])
				R = M - 1;
			else
				L = M + 1;
		}
		return Primes[L];

	}
	// the result is outside our prime number table range, use the
	// standard method for testing primality (do any of the primes up to
	// the root of the number divide it exactly?) and continue
	// incrementing the result by 2 until it is prime}
	if (nRes <= (MaxPrime * MaxPrime))
	{
		while (TRUE)
		{
			RootN = (DWORD)(sqrt(nRes));
			DivisorIndex = 1;			// ignore the prime number 2
			IsPrime = TRUE;
			while (DivisorIndex < PrimeCount && 
				RootN > Primes[DivisorIndex])
			{
				if ((nRes / Primes[DivisorIndex]) * 
					Primes[DivisorIndex] == nRes)
				{
					IsPrime = FALSE;
					break;
				}
				++DivisorIndex;
			}
			if (IsPrime)
				return nRes;
			nRes+=2;
		}    
	}
	return nRes;
}


void TabCreate(DWORD nSize)
{
	DWORD i, n=GetClosestPrime(nSize);					// get ideal hashsize
	nHashSize = n;
	HashTab = (DWORD *)MALLOC(n*sizeof(DWORD));			// allocate our hash table
	ASSERT(NULL!=HashTab);							
	for (i=0; i<n; i++)
		HashTab[i] = 0;									// clear all entries

}

void TabDestroy(void)
{
	if (HashTab)
		FREE(HashTab);
}

static int Test(DWORD h, DWORD val)
{
	if (HashTab[h]!=0)
		return HashTab[h]!=val;
	else
		return FALSE;
}

int TabFind(DWORD nNumber, DWORD *nPos)
{
	DWORD nKey = nNumber % nHashSize;					// get position of key
	*nPos = 0;
	
	while (Test(nKey,nNumber))
		nKey = nKey % nHashSize + 1;
	
	*nPos=nKey;
	if (HashTab[nKey]!=0)
		return TRUE;
	return FALSE;
}

int TabAdd(DWORD nNumber)
{
	DWORD nPos;
	if (!TabFind(nNumber, &nPos))						// did not find so add
	{
		HashTab[nPos]=nNumber;
		return TRUE;
	}
	else
		return FALSE;

}


/*
 * Analyze and decode a geopol entry
 *
 * Parameters:
 * nStart - offset of this geopol
 * nLen - chunk length
 *
 * return value:
 * none
 */
static void DecodeGeopolEntry(DWORD nStart, DWORD nLen)
{
	geopol_t geopol;
	char *pszName = "Geopol";
	DWORD start = nStart+24;
	DWORD end = nStart+nLen;
	int nLat,nLon;
	char szLat[24], szLon[24];

	geopol.wId = GET_U16(nStart);						// get id
	geopol.nLen = GET_U32(nStart+2);					// get record length
	geopol.bFlagsCount = GET_U16(nStart+6);				// get # of vertex & flags

	geopol.nMinEast = GET_S32(nStart+8);				// min east
	geopol.nMinNorth = GET_S32(nStart+12);				// min north
	geopol.nMaxEast = GET_S32(nStart+16);				// max east
	geopol.nMaxNorth = GET_S32(nStart+20);				// max north

	if (!nTerse)
	{
		PrintObjectSpec(pszName,nStart);
		fprintf(outfile,"\t<!--\n");
		fprintf(outfile,"\t\tMin East  = %.04lf\n", fslon2lon(geopol.nMinEast));
		fprintf(outfile,"\t\tMin North = %.04lf\n", fslat2lat(geopol.nMinNorth));
		fprintf(outfile,"\t\tMax East  = %.04lf\n", fslon2lon(geopol.nMaxEast));
		fprintf(outfile,"\t\tMax North = %.04lf\n", fslat2lat(geopol.nMaxNorth));
		fprintf(outfile,"\t-->\n");
	}

	fprintf(outfile,"\t<%s type=\"",pszName);
	if (geopol.bFlagsCount & GEOPOL_BOUNDARY)
		fprintf(outfile,"BOUNDARY");
	else if (geopol.bFlagsCount & GEOPOL_COASTLINE)
		fprintf(outfile,"COASTLINE");
	fprintf(outfile,"\">\n");

	while (start<end)
	{
		nLon = GET_S32(start);
		nLat = GET_S32(start+4);
		fprintf(outfile,"\t\t<Vertex lat=\"%s\" lon=\"%s\" />\n",
			LatString(fslat2lat(nLat),szLat),
			LatString(fslon2lon(nLon),szLon));
		start+=8;
	}
	fprintf(outfile,"\t</%s>\n",pszName);
}



/*
 * write boundary sub-entry extra-parameters
 *
 * Parameters:
 * ptr - pointer to boundary info
 *
 * return value:
 * none
 */
static void PrintBoundaryEntryInfo(boundary_t *ptr)
{
	char szAltMin[24], szAltMax[24];
	
	fprintf(outfile,"\n\t\t\tmaximumAltitudeType=\"%s\" minimumAltitudeType=\"%s\"\n",
		boundaryAltTypeTable[HI4BITS(ptr->bAltKind)],
		boundaryAltTypeTable[LO4BITS(ptr->bAltKind)]);
	fprintf(outfile,"\t\t\taltitudeMinimum=%s altitudeMaximum=%s\n\t\t\t",
		AltString(ptr->nMinAlt,szAltMin),AltString(ptr->nMaxAlt,szAltMax));


}

/*
 * Analyze and decode boundary sub-entry
 *
 * Parameters:
 * nStart - offset of boundary sub-entry
 * ptr - pointer to boundary info
 *
 * return value:
 * none
 */
static void DecodeBoundarySubEntry(DWORD nStart, boundary_t *ptr)
{

	char *latlonstr = "lat=\"%s\" lon=\"%s\"";

	// get sub-entry header
	WORD wId = GET_U16(nStart);		// == 0x21		
	DWORD nLen = GET_U32(nStart+2);		// block length
	WORD w,wCount = GET_U16(nStart+6);	// # of sub entries
	char szLat[24], szLon[24], szRange[24];
	WORD bId, bIdx;
	int nLat, nLon;
	float fRad;

	DWORD start=nStart+8;				// start of sub entries
	for (w=0; w<wCount; w++)			// for each sub entry
	{
		bId = GET_BYTE(start);			// get id
		bIdx = GET_BYTE(start+1);		// get index
		switch(bId)
		{
		case 1:							// boundary start
			nLon = GET_S32(start+6);	// get longitude
			nLat = GET_S32(start+2);	// get latitude
			fprintf(outfile,"\t\t<BoundaryStart ");
			PrintBoundaryEntryInfo(ptr);
			fprintf(outfile,latlonstr,
				LatString(fslat2lat(nLat),szLat),
				LatString(fslon2lon(nLon),szLon));
			break;
		case 2:							// line
			nLon = GET_S32(start+6);	// get longitude
			nLat = GET_S32(start+2);	// get latitude
			fprintf(outfile,"\t\t<Line ");
			fprintf(outfile,latlonstr,
				LatString(fslat2lat(nLat),szLat),
				LatString(fslon2lon(nLon),szLon));
			break;
		case 3:							// origin
			nLon = GET_S32(start+6);	// get longitude
			nLat = GET_S32(start+2);	// get latitude
			fprintf(outfile,"\t\t<Origin ");
			fprintf(outfile,latlonstr,
				LatString(fslat2lat(nLat),szLat),
				LatString(fslon2lon(nLon),szLon));
			break;
		case 4:							// arc cw
			nLon = GET_S32(start+6);	// get longitude
			nLat = GET_S32(start+2);	// get latitude
			fprintf(outfile,"\t\t<Arc type=\"CLOCKWISE\" index=\"%d\" ",
				bIdx);
			fprintf(outfile,latlonstr,
				LatString(fslat2lat(nLat),szLat),
				LatString(fslon2lon(nLon),szLon));
			break;
		case 5:							// arc ccw
			nLon = GET_S32(start+6);	// get longitude
			nLat = GET_S32(start+2);	// get latitude
			fprintf(outfile,"\t\t<Arc type=\"COUNTER_CLOCKWISE\" index=\"%d\" ",
				bIdx);
			fprintf(outfile,latlonstr,
				LatString(fslat2lat(nLat),szLat),
				LatString(fslon2lon(nLon),szLon));
			break;
		case 6:							// circle
			fRad = GET_FLOAT(start+6);	// get radius
			fprintf(outfile,"\t\t<Circle");
			PrintBoundaryEntryInfo(ptr);
			fprintf(outfile,"index=\"%d\" radius=%s",
				bIdx,RangeString(fRad,szRange));
			break;
		}
		fprintf(outfile," />\n");
		start+=10;
	}
}


/*
 * Analyze and decode a boundary entry
 *
 * Parameters:
 * nStart - offset of this boundary
 * nLen - chunk length
 *
 * return value:
 * none
 */
static void DecodeBoundaryEntry(DWORD nStart, DWORD nLen)
{
	/*
	 * commenting out until I properly hack all boundary
	 * sub-entries
	 */
	char *szName = 0, *szCenterName;
	char *szIdent = "Boundary";
	DWORD nSubStart, nSubEnd, nRecBegin;
	boundary_t boundary;
	WORD wId;
	DWORD nRecLen;
	WORD wNameId;
	center_freq_t freq;
	boundary.wType = GET_U16(nStart);
	boundary.nLen = GET_U32(nStart+2);
	boundary.bBoundaryKind = GET_BYTE(nStart+6);
	boundary.bAltKind = GET_BYTE(nStart+7);
	boundary.nMinLon = GET_S32(nStart+8);
	boundary.nMinLat = GET_S32(nStart+12);
	boundary.nMinAlt = GET_S32(nStart+16);
	boundary.nMaxLon = GET_S32(nStart+20);
	boundary.nMaxLat = GET_S32(nStart+24);
	boundary.nMaxAlt = GET_S32(nStart+28);
	
	wNameId = GET_U16(nStart+32);					// see if we have a name entry here
	if (wNameId==0x19)
	{												// yes we have
		boundary.wNameId = wNameId;
		boundary.nNameLen = GET_S32(nStart+34);
	
		nSubStart = nStart+32+boundary.nNameLen;	
		nSubEnd = nStart+boundary.nLen;

		szName = (char *)MALLOC(boundary.nNameLen);	// transfer the name
		memset(szName,0x0,boundary.nNameLen);
		memcpy(szName,OFFSET(nStart+38),boundary.nNameLen-6);
	}
	else if (wNameId==0x12)							// we have a center frequency
	{
		freq.wId=wNameId;
		freq.nLen=GET_U32(nStart+34);
		freq.wUnk1=GET_U16(nStart+38);
		freq.nFreq=GET_U32(nStart+40);
		
		// allocate memory for center name
		szCenterName = (char *)MALLOC(freq.nLen+1 - 12);
		memset(szCenterName,0x0,freq.nLen+1-12);
		// transfer center name
		memcpy(szCenterName,OFFSET(nStart+44),freq.nLen-12);


		// just print the info commented, since Microsoft seems
		// to provide no means for specifying them
		fprintf(outfile,"\t<!--\n");
		fprintf(outfile,"\t\tCenter %s, Freq: %0.3lf\n\t-->\n",
			szCenterName, (double)freq.nFreq/1000000);

		FREE(szCenterName);							// release memory
		
		boundary.nNameLen=0;

		wNameId = GET_U16(nStart+32+freq.nLen);	// see if we have a name entry here
		if (wNameId==0x19)
		{												// yes we have
			boundary.wNameId = wNameId;
			boundary.nNameLen = GET_S32(nStart+32+freq.nLen+2);
			szName = (char *)MALLOC(boundary.nNameLen);	// transfer the name
			memset(szName,0x0,boundary.nNameLen);
			memcpy(szName,OFFSET(nStart+32+freq.nLen+8),boundary.nNameLen-6);
		}
		nSubStart = nStart+32+freq.nLen+boundary.nNameLen;
		nSubEnd = nStart+boundary.nLen;
		
	}
	else
	{
		nSubStart = nStart+32;						// we don't have names or frequencies
		nSubEnd = nStart+boundary.nLen;
	}
	if (!nTerse)
		PrintObjectSpec(szIdent,nStart);

	fprintf(outfile,"\t<%s type=\"%s\" ",
		szIdent, boundaryTypeTable[boundary.bBoundaryKind]);
	
	if (szName)
	{
		fprintf(outfile,"name=");
		PrintXmlString(szName,0);
		
		FREE(szName);
	}
	fprintf(outfile,">\n");

	// print boundary start parameters

	while (nSubStart<nSubEnd)
	{
		nRecBegin=nSubStart;
		wId=GET_U16(nRecBegin);
		nRecLen=GET_U32(nRecBegin+2);
		switch (wId)
		{
		case 0x0021:		// origin
			DecodeBoundarySubEntry(nRecBegin,&boundary);
			break;
		}

		nSubStart+=nRecLen;
	}
	fprintf(outfile,"\t</%s>\n",szIdent);

}

/*
 * loop through a geopol or boundary info table and analyze geopol entries
 *
 * Parameters:
 *
 * nKind - 0x20 for boundary, 0x23 for geopol
 * nGroups - number of geopol/boundary groups
 * nStart - offset of this geopol/boundary
 * nLen - chunk length
 *
 * return value:
 * none
 */
void GeopolBoundaryGroupLoop(DWORD nKind, DWORD nGroups, DWORD nStart, DWORD nLen)
{
	DWORD nThisOffset, nThisSize;
	DWORD nOffset = nStart + (nGroups * 16);				// position to geopol/bdry offsets table
	DWORD nEnd = nStart+nLen;
	
	
	TabCreate((nEnd-nOffset)/8);						// initialize hash table

	for (; nOffset<nEnd; nOffset+=8)
	{
		nThisOffset = GET_U32(nOffset);				// get offset of geopol/bdry
		nThisSize = GET_U32(nOffset+4);				// get size of geopol/bdry
		if (TabAdd(nThisOffset))						// if not a duplicate geopol/bdry
		{
			if (nKind ==OBJTYPE_GEOPOL)					// then decode it
				DecodeGeopolEntry(nThisOffset,nThisSize);	
			else
				DecodeBoundaryEntry(nThisOffset,nThisSize);	
		}
	}
	TabDestroy();										// free memory from hash table

}

