/* $Id */

#ifndef dwlist_h
#define dwlist_h

typedef struct _tag_dwnode
{
	unsigned long value;
	unsigned long data;
	struct _tag_dwnode *next;
} dwnode_t;

typedef struct _tag_dwlist
{
	dwnode_t *head;
	dwnode_t *tail;
	int count;
} dwlist_t;

dwlist_t *dwlist_init();
void dwlist_free(dwlist_t **);
void dwlist_clear(dwlist_t *);
int dwlist_add(dwlist_t *, const unsigned long, const unsigned long);
#define dwlist_first(dwlist) dwlist->head

#endif
