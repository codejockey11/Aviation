/*
 * $Id: bglxml.h,v 1.3 2007/10/20 00:17:03 Alessandro Exp Alessandro $
 */

#ifndef bglxml_h
#define bglxml_h

#if (defined(WIN32))
	#define NT_API_CALLS
	#include <windows.h>
#endif


#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <ctype.h>

#ifndef NT_API_CALLS
	#include <errno.h>
#endif

#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif

#include "defs.h"
#include "charvec.h"
#include "fueltab.h"
#include "getopt.h"
#include "objfile.h"
#include "options.h"
#include "tabs.h"
#include "util.h"
#include "dwlist.h"

#ifdef __cplusplus
}
#endif

#endif

