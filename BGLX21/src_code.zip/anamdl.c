/*
 *   $Id: anamdl.c,v 1.7 2007/10/20 00:15:15 Alessandro Exp Alessandro $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: ModelData analyzer $
 *
 *   $Log: anamdl.c,v $
 *   Revision 1.7  2007/10/20 00:15:15  Alessandro
 *   Code to translate GUI IDs
 *
 *   Revision 1.6  2007/10/02 21:52:00  alexanto
 *   Reenabled print of model data :-)
 *
 *   Revision 1.5  2007/10/02 21:46:38  alexanto
 *   commented out modeldata generation
 *
 *   Revision 1.4  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.3  2004/03/12 15:19:59  alexanto
 *   Modified to make it compatible with BGL to Radar Contact
 *
 *   Revision 1.2  2004/02/12 15:17:07  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2004/02/04 14:07:48  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"

/*
 * Print ModelData to file
 *
 * Parameters:
 * szModelName - ModelName
 * szGuid - Guid
 * nOffset - offset of the model into bgl
 * nLen - length of model chunk
 *
 * Return value:
 * none
 */
static void PrintModelData(const char *szModelName, const char *szGuid,
						   DWORD nOffset, DWORD nLen)
{
#ifndef BGLDECD
	char ModelPath[1024];
	printf("Writing model %s.mdl...\n",szModelName);

/*	if (map.ptr[nOffset+11] <= '9')		// peek inside MDL file to get version
		// FS9 bglcomp gets GUID from 'name'
		fprintf(outfile,"\t<ModelData\n\t\tname=\"%s\"\n"
				"\t\tsourceFile=\"%s.mdl\" />\n\n",
				szGuid,szModelName);
	else*/
		// FSX bglcomp doesn't support 'name' - the GUID is pulled from the MDL file
                fprintf(outfile,"\t<!-- guid=\"%s\" -->\n"
						"\t<ModelData sourceFile=\"%s.mdl\" />\n\n",
                              szGuid,szModelName);

	strcpy(ModelPath,OutFileDir);
	strcat(ModelPath,szModelName);
	strcat(ModelPath,".mdl");
	WriteChunkToFile(ModelPath,&map.ptr[nOffset],nLen);
#endif
}

/*
 * Analyzes and decode modeldata
 *
 * Parameters:
 * nGrpCount - number of model datas available in this group
 * nGrpOffset - offset to current model data chunk
 * nGrpLen - current chunk length
 *
 * Return value:
 * none
 */
void AnalyzeModelData(DWORD nGrpCount, DWORD nGrpOffset, DWORD nChunkLen)
{
	DWORD i;
	DWORD d1,d2,d3,d4;
	DWORD dwOffset;
	DWORD dwPointer=nGrpOffset;
	DWORD dwLen;
	int found,index;
	char szGuid[36];
	char *p, *pszModel;
	for (i=0; i<nGrpCount; i++)
	{
		d1 = GET_U32(dwPointer);
		d2 = GET_U32(dwPointer+4);
		d3 = GET_U32(dwPointer+8);
		d4 = GET_U32(dwPointer+12);
		dwOffset = GET_U32(dwPointer+16);
		dwLen = GET_U32(dwPointer+20);
		dwPointer+=24;

		// make GUID
		sprintf(szGuid,"%0.8x%0.8x%0.8x%0.8x",d1,d2,d3,d4);
		found = ChrPoolFind(cobjects,szGuid, &index);
		if (found)
		{
			p = (char *)cobjects->ptr[index].i;
			if (p)
				pszModel = p;
			else
				pszModel = szGuid;
		}
		else
			pszModel = szGuid;
		PrintModelData(pszModel, szGuid, nGrpOffset+dwOffset, dwLen);
	}
}

