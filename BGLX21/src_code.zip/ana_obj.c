/*
 *   $Id: ana_obj.c,v 1.1 2007/09/23 23:21:18 Alessandro Exp $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: SceneryObject record analyzer $
 *
 *   $Log: ana_obj.c,v $
 *   Revision 1.1  2007/09/23 23:21:18  Alessandro
 *   Initial revision
 *
 *   Revision 1.5  2005/10/12 17:26:03  alexanto
 *   some changes
 *
 *   Revision 1.4  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.3  2004/03/12 15:19:59  alexanto
 *   Added XML Transoframtion string to Effect
 *   decoding routine
 *
 *   Revision 1.2  2004/02/12 15:17:07  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2004/02/04 14:07:48  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"

// decode structure
typedef struct
{
	WORD wId;       // object ID
	char *pszName;	// object name
	int (* lpfnDecode)(WORD, char *, int, int);
} decode_t;

/*
 * Analyzes and decode unknown objects (dump to hex)
 *
 * Parameters:
 * pszName - object name
 * nOffset - offset to current obj chunk
 * nRecLen - current chunk length
 *
 * Return value:
 * none
 */
int DecodeUnknown(WORD wId, char *pszName, int nOffset, int nRecLen)
{
	int i, j, nBytesRead=0;
	if (!nTerse)
		fprintf(outfile, "<!-- current offset: 0x%.8X -->\n",nOffset);

        
	fprintf(outfile, "\n\t\t<!-- dumping unknown object (ID: 0x%0.X), length: %d", wId, nRecLen);

	j = 0;
	for (i=0; i<nRecLen; i++, nBytesRead++)
	{
		if (j==0)
			fprintf(outfile,"\n\t\t\t");
                
		fprintf(outfile,"%0.2X ", map.ptr[nOffset+i]);
		j++;
		if (j>15)
			j=0;
	}
	fprintf(outfile,"\n\t\t-->\n\n");
	return nBytesRead;
}


#if (defined(__BORLANDC__))
#pragma argsused
#endif
/*
 * Analyzes and decode effect
 *
 * Parameters:
 * pszName - object name
 * nOffset - offset to current obj chunk
 * nRecLen - current chunk length
 *
 * Return value:
 * none
 */
int DecodeEffect(WORD wId,char *pszName, int nOffset, int nRecLen)
{
	int diff,nBytesRead=0;
	char szEffectName[80];
	memcpy(szEffectName, &map.ptr[nOffset], sizeof(szEffectName));
	nBytesRead+=sizeof(szEffectName);
	
	fprintf(outfile,"\t\t<%s\n\t\t\teffectName=", pszName);
	PrintXmlString(szEffectName,0);
	
	// see whether we have params
	diff = nRecLen-nBytesRead;
	if (diff > 1)
	{
		fprintf(outfile,"\n\t\t\teffectParams=\"");
		while (map.ptr[nOffset+nBytesRead]!=0)
		{
			if (isalnum((int)map.ptr[nOffset+nBytesRead]) ||
				isspace(map.ptr[nOffset+nBytesRead]))
				fprintf(outfile,"%c",map.ptr[nOffset+nBytesRead++]);
			else
				fprintf(outfile,"&#x%0.2X;",map.ptr[nOffset+nBytesRead++]);

			
		}
		nBytesRead++;
		fprintf(outfile,"\"");
	}
	else
	{
		nBytesRead+=diff;
	}
	fprintf(outfile," />\n");
	return nBytesRead;
}


#if (defined(__BORLANDC__))
#pragma argsused
#endif
/*
 * Analyzes and decode windsocks
 *
 * Parameters:
 * pszName - object name
 * nOffset - offset to current obj chunk
 * nRecLen - current chunk length
 *
 * Return value:
 * none
 */
int DecodeWindSock(WORD wId,char *pszName, int nOffset, int nRecLen)
{
	int nBytesRead=0;
	windsock_t lpWindSock;
	lpWindSock.fPoleHeight=GET_FLOAT(nOffset);
	lpWindSock.fSockLength=GET_FLOAT(nOffset+4);
	lpWindSock.lpPoleColor.b=GET_BYTE(nOffset+8);
	lpWindSock.lpPoleColor.g=GET_BYTE(nOffset+9);
	lpWindSock.lpPoleColor.r=GET_BYTE(nOffset+10);
	lpWindSock.lpPoleColor.a=GET_BYTE(nOffset+11);
	lpWindSock.lpSockColor.b=GET_BYTE(nOffset+12);
	lpWindSock.lpSockColor.g=GET_BYTE(nOffset+13);
	lpWindSock.lpSockColor.r=GET_BYTE(nOffset+14);
	lpWindSock.lpSockColor.a=GET_BYTE(nOffset+15);
	lpWindSock.wLighted=GET_U16(nOffset+16);
	nBytesRead+=sizeof(lpWindSock);
	
	fprintf(outfile,"\t\t<%s poleHeight=\"%0.2lf\" sockLength=\"%0.2lf\" lighted=\"%s\">\n"
		"\t\t\t<PoleColor red=\"%d\" blue=\"%d\" green=\"%d\" />\n"
		"\t\t\t<SockColor red=\"%d\" blue=\"%d\" green=\"%d\" />\n"
		"\t\t</%s>\n",
		pszName, lpWindSock.fPoleHeight, lpWindSock.fSockLength, 
		truthTable[lpWindSock.wLighted],
		lpWindSock.lpPoleColor.r,lpWindSock.lpPoleColor.b,lpWindSock.lpPoleColor.g,
		lpWindSock.lpSockColor.r,lpWindSock.lpSockColor.b,lpWindSock.lpSockColor.g,
		pszName);
	
	
	return nBytesRead;
}

#if (defined(__BORLANDC__))
#pragma argsused
#endif
/*
 * Analyzes and decode trigger data
 *
 * Parameters:
 * pszName - object name
 * nOffset - offset to current obj chunk
 * nRecLen - current chunk length
 *
 * Return value:
 * number of bytes read
 */
int DecodeTrigger(WORD wId,char *pszName, int nOffset, int nRecLen)
{
	int i, nVertexCount, nVertexOffset;
	trigger_refuel_t fuel;
	trigger_weather_t weather;
	float X, Z;

	WORD wTriggerId = GET_U16(nOffset);
	
	fprintf(outfile,"\t\t<%s type=",pszName);
	
	if (wTriggerId==TRIGGER_REFUEL_REPAIR)
	{
		fuel.wId=GET_U16(nOffset);
		fuel.fHeight=GET_FLOAT(nOffset+2);
		fuel.nAvailability=GET_U32(nOffset+6);
		fuel.nVertexCount=GET_S32(nOffset+10);
		nVertexCount=fuel.nVertexCount;
		nVertexOffset=nOffset+14;
		fprintf(outfile,"\"REFUEL_REPAIR\" triggerHeight=\"%0.2lf\" >\n",
			fuel.fHeight);
		get_fuel_kind(fuel.nAvailability);		
	}
	else            // weather station
	{
		weather.wId=GET_U16(nOffset);
		weather.fHeight=GET_FLOAT(nOffset+2);
		weather.wWeatherType=GET_U16(nOffset+6);
		weather.fDataHdg=GET_FLOAT(nOffset+8);
		weather.fDataScalar=GET_FLOAT(nOffset+12);
		weather.nVertexCount=GET_S32(nOffset+16);
		nVertexCount=weather.nVertexCount;
		nVertexOffset=nOffset+20;
		
		fprintf(outfile,"\"WEATHER\" triggerHeight=\"%0.2lf\" >\n",
			weather.fHeight);
		fprintf(outfile,"\t\t\t<TriggerWeatherData type=\"%s\"\n"
			"\t\t\t\theading=\"%0.2lf\" scalar=\"%0.2lf\" />\n",
			weatherTable[weather.wWeatherType-1],
			weather.fDataHdg,weather.fDataScalar);
	}
	for (i=0; i<nVertexCount; i++)  // decode vertexes
	{
		X = GET_FLOAT(nVertexOffset);
		nVertexOffset+=sizeof(float);

		Z = GET_FLOAT(nVertexOffset);
		nVertexOffset+=sizeof(float);
		fprintf(outfile,"\t\t\t<Vertex biasX=\"%0.2lf\" biasZ=\"%0.2lf\" />\n", X,Z);
	}
	
	fprintf(outfile,"\t\t</%s>\n",pszName);
	
	return nRecLen;
}


/*
 BEACON TYPES:
 0xf5 : civilian, airport
 0xf6 : civilian, heliport
 0xf7 : civilian, sea_base
 0xf8 : military, airport
 0xf9 : military, heliport
 0xfa : military, sea_base
 */
static const char *beacon_table[] =
{
	"CIVILIAN",		// 0
	"MILITARY",		// 1
	"AIRPORT",		// 2
	"SEA_BASE",		// 3
	"HELIPORT",		// 4
};

#if (defined(__BORLANDC__))
#pragma argsused
#endif
/*
 * Analyze and decode library objects
 *
 * Parameters:
 * pszName - object name
 * nOffset - offset to current obj chunk
 * nRecLen - current chunk length
 *
 * Return value:
 * number of bytes read
 *
 * NOTE: this is a partial decoding...
 * I'm not sure I have discovered all the info nested in this chunk
 */
int DecodeLibraryObject(WORD wId,char *pszName, int nOffset, int nRecLen)
{
	libobj_t ptr;
	char *p;
	char guid[48];
	int index;
	int bType, bBaseType;
	WORD wAttObj;
	WORD wObjLen;
	WORD wObjPitch;
	WORD wObjBank;
	WORD wObjHeading;
	char *pszObjName;

	ptr.lpGuid[0]=(DWORD)GET_S32(nOffset);
	ptr.lpGuid[1]=(DWORD)GET_U32(nOffset+4);
	ptr.lpGuid[2]=(DWORD)GET_U32(nOffset+8);
	ptr.lpGuid[3]=(DWORD)GET_U32(nOffset+12);
	ptr.fScale=GET_FLOAT(nOffset+16);
	sprintf(guid,"%0.8x%0.8x%0.8x%0.8x",ptr.lpGuid[0],ptr.lpGuid[1],
		ptr.lpGuid[2],ptr.lpGuid[3]);
	if (ChrPoolFind(cobjects,guid, &index))
	{
		p = (char *)cobjects->ptr[index].i;
		if (p)
			fprintf(outfile,"\t\t<!-- Object %s -->\n", p);
	}
	
	fprintf(outfile,"\t\t<%s name=\"%s\" scale=\"%0.2lf\" />\n",
		pszName, guid, ptr.fScale);
	
	// see if we have an "attached object" here
	wAttObj=GET_U16(nOffset+20);

	// if wAttObj is 0x1000 then we have
	if (wAttObj==SCNOBJ_ATTACHED || wAttObj==SCNOBJ_ATTACHED_FSX)
	{
		// get length of attached object chunk
		wObjLen = GET_U16(nOffset+26);

		wObjPitch = GET_U16(nOffset+20+10);	// get pitch
		wObjBank = GET_U16(nOffset+20+12);		// get bank
		wObjHeading = GET_U16(nOffset+20+14);	// get heading

		if (wAttObj==SCNOBJ_ATTACHED_FSX)
			nOffset+=20;		// Skip FSX instanceID + unknown

		pszObjName = PSZ_STR(nOffset+20+32);	// get name
												// hope it's null terminated :-)
		// print info
		fprintf(outfile,"\t\t\t<AttachedObject attachpointName=");

		PrintXmlString(pszObjName,0);
		fprintf(outfile,"\n");

		fprintf(outfile,"\t\t\t\tpitch=\"%0.2lf\" bank=\"%0.2lf\" heading=\"%0.2lf\">\n",
			(double)wObjPitch*360.0/65536.0,
			(double)wObjBank*360.0/65536.0,
			(double)wObjHeading*360.0/65536.0);

		
		// try to decode beacon
		switch (map.ptr[nOffset+20+28])
		{
			case 0xf5:	// civilian, airport
				bType=0;
				bBaseType=2;
				break;
			case 0xf6:	// civilian, heliport
				bType=0;
				bBaseType=3;
				break;
			case 0xf7:	// civilian, sea_base
				bType=0;
				bBaseType=4;
				break;
			case 0xf8:	// military, airport
				bType=1;
				bBaseType=2;
				break;
			case 0xf9:	// military, heliport
				bType=1;
				bBaseType=3;
				break;
			case 0xfa:	// military, sea_base
				bType=1;
				bBaseType=4;
				break;
			default:	// stuff a beacon - whether we have it or not
				bType=0;
				bBaseType=2;
				break;
		}

		fprintf(outfile,"\t\t\t\t<Beacon type=\"%s\" baseType=\"%s\" />\n",
			beacon_table[bType],beacon_table[bBaseType]);	// et voila


		fprintf(outfile,"\t\t\t</AttachedObject>\n");


		return 28+wObjLen;	//	size of libobj+6+size of word + objlen
	}
	else
		return nRecLen;
}


#if (defined(__BORLANDC__))
#pragma argsused
#endif
/*
 * finish printing header info
 *
 * parameters
 * 
 *
 *
 */
static void PrintBuildingInfo(WORD wBottomText,WORD wRoofText, WORD wTopText,
                                                          WORD wWindowText)
{
	fprintf(outfile," bottomTexture=\"%d\"\n"
		"\t\t\troofTexture=\"%d\" "
		"topTexture=\"%d\" "
		"windowTexture=\"%d\" >\n",
		wBottomText, wRoofText, wTopText, wWindowText);
}


/*
 * print roof type info for rectangular buildings
 *
 * Parameters:
 * str - type of roof
 *
 * Return value:
 * none
 */
static void PrintRoofInfo(char *str, WORD wSizeX, WORD wSizeZ, WORD wSizeBottomY )
{

	fprintf(outfile,"\t\t\t<RectangularBuilding\n"
		"\t\t\t\troofType=\"%s\"\n", str);
	
	fprintf(outfile,"\t\t\t\tsizeX=\"%d\"\n"
		"\t\t\t\tsizeZ=\"%d\"\n"
		"\t\t\t\tsizeBottomY=\"%d\"\n",
		wSizeX, wSizeZ, wSizeBottomY);
}



#if (defined(__BORLANDC__))
#pragma argsused
#endif
/*
 * Analyzes and decode peaked-roof buildings
 *
 * Parameters:
 * nOffset - offset to current obj chunk
 * hdr - pointer to building header info
 *
 * Return value:
 * number of bytes read
 */
static int DecodePeakedRoofBuilding(int nOffset,building_hdr_t *hdr)
{
	rect_bldgpr_t ptr;
	int nBytesRead = 0;
	
	// get building
	ptr.wSizeX=GET_U16(nOffset);
	ptr.wSizeZ=GET_U16(nOffset+2);
	ptr.wBottomTexture=GET_U16(nOffset+4);
	ptr.wSizeBottomY=GET_U16(nOffset+6);
	ptr.wTextIdxBottomX=GET_U16(nOffset+8);
	ptr.wTextIdxBottomZ=GET_U16(nOffset+10);
	ptr.wWindowTexture=GET_U16(nOffset+12);
	ptr.wSizeWindowY=GET_U16(nOffset+14);
	ptr.wTextIdxWindowX=GET_U16(nOffset+16);
	ptr.wTextIdxWindowY=GET_U16(nOffset+18);
	ptr.wTextIdxWindowZ=GET_U16(nOffset+20);
	ptr.wTopTexture=GET_U16(nOffset+22);
	ptr.wSizeTopY=GET_U16(nOffset+24);
	ptr.wTextIdxTopX=GET_U16(nOffset+26);
	ptr.wTextIdxTopZ=GET_U16(nOffset+28);
	ptr.wRoofTexture=GET_U16(nOffset+30);
	ptr.wTextIdxRoofX=GET_U16(nOffset+32);
	ptr.wTextIdxRoofZ=GET_U16(nOffset+34);
	ptr.wSizeRoofY=GET_U16(nOffset+36);
	ptr.wTextIdxRoofY=GET_U16(nOffset+38);
	ptr.wUnk5=GET_U16(nOffset+40);
	nBytesRead+=sizeof(rect_bldgpr_t);
	
	PrintBuildingInfo(ptr.wBottomTexture, ptr.wRoofTexture, ptr.wTopTexture, 
		ptr.wWindowTexture);
	
	
	PrintRoofInfo("PEAKED", ptr.wSizeX, ptr.wSizeZ, ptr.wSizeBottomY);
	
	fprintf(outfile,"\t\t\t\ttextureIndexBottomX=\"%d\"\n"
		"\t\t\t\ttextureIndexBottomZ=\"%d\"\n"
		"\t\t\t\tsizeWindowY=\"%d\"\n"
		"\t\t\t\ttextureIndexWindowX=\"%d\"\n",
		ptr.wTextIdxBottomX, ptr.wTextIdxBottomZ,
		ptr.wSizeWindowY, ptr.wTextIdxWindowX);
	
	fprintf(outfile,"\t\t\t\ttextureIndexWindowY=\"%d\"\n"
		"\t\t\t\ttextureIndexWindowZ=\"%d\"\n"
		"\t\t\t\tsizeTopY=\"%d\"\n",
		ptr.wTextIdxWindowY, ptr.wTextIdxWindowZ,
		ptr.wSizeTopY);
	
	fprintf(outfile,"\t\t\t\ttextureIndexTopX=\"%d\"\n"
		"\t\t\t\ttextureIndexTopZ=\"%d\"\n"
		"\t\t\t\ttextureIndexRoofX=\"%d\"\n"
		"\t\t\t\ttextureIndexRoofZ=\"%d\"\n",
		ptr.wTextIdxTopX, ptr.wTextIdxTopZ,
		ptr.wTextIdxRoofX, ptr.wTextIdxRoofZ);
	
	fprintf(outfile,"\t\t\t\tsizeRoofY=\"%d\"\n"
		"\t\t\t\ttextureIndexRoofY=\"%d\" />\n",
		ptr.wSizeRoofY,ptr.wTextIdxRoofY);

	return nBytesRead;
}


#if (defined(__BORLANDC__))
#pragma argsused
#endif
/*
 * Analyzes and decode flat-roof buildings
 *
 * Parameters:
 * nOffset - offset to current obj chunk
 * hdr - pointer to building header info
 *
 * Return value:
 * number of bytes read
 */
static int DecodeFlatRoofBuilding(int nOffset,building_hdr_t *hdr)
{
	rect_bldgfr_t ptr;
	int nBytesRead = 0;
	
	// get building
	ptr.wSizeX=GET_U16(nOffset);
	ptr.wSizeZ=GET_U16(nOffset+2);
	ptr.wBottomTexture=GET_U16(nOffset+4);
	ptr.wSizeBottomY=GET_U16(nOffset+6);
	ptr.wTextIdxBottomX=GET_U16(nOffset+8);
	ptr.wTextIdxBottomZ=GET_U16(nOffset+10);
	ptr.wWindowTexture=GET_U16(nOffset+12);
	ptr.wSizeWindowY=GET_U16(nOffset+14);
	ptr.wTextIdxWindowX=GET_U16(nOffset+16);
	ptr.wTextIdxWindowY=GET_U16(nOffset+18);
	ptr.wTextIdxWindowZ=GET_U16(nOffset+20);
	ptr.wTopTexture=GET_U16(nOffset+22);
	ptr.wSizeTopY=GET_U16(nOffset+24);
	ptr.wTextIdxTopX=GET_U16(nOffset+26);
	ptr.wTextIdxTopZ=GET_U16(nOffset+28);
	ptr.wRoofTexture=GET_U16(nOffset+30);
	ptr.wTextIdxRoofX=GET_U16(nOffset+32);
	ptr.wTextIdxRoofZ=GET_U16(nOffset+34);
	ptr.wUnk5=GET_U16(nOffset+36);
	nBytesRead+=sizeof(rect_bldgfr_t);
	
	PrintBuildingInfo(ptr.wBottomTexture, ptr.wRoofTexture, ptr.wTopTexture, 
		ptr.wWindowTexture);
	
	PrintRoofInfo("FLAT", ptr.wSizeX, ptr.wSizeZ, ptr.wSizeBottomY);
	
	
	fprintf(outfile,"\t\t\t\ttextureIndexBottomX=\"%d\"\n"
		"\t\t\t\ttextureIndexBottomZ=\"%d\"\n"
		"\t\t\t\tsizeWindowY=\"%d\"\n"
		"\t\t\t\ttextureIndexWindowX=\"%d\"\n",
		ptr.wTextIdxBottomX, ptr.wTextIdxBottomZ,
		ptr.wSizeWindowY, ptr.wTextIdxWindowX);
	
	fprintf(outfile,"\t\t\t\ttextureIndexWindowY=\"%d\"\n"
		"\t\t\t\ttextureIndexWindowZ=\"%d\"\n"
		"\t\t\t\tsizeTopY=\"%d\"\n",
		ptr.wTextIdxWindowY, ptr.wTextIdxWindowZ,
		ptr.wSizeTopY);
	
	fprintf(outfile,"\t\t\t\ttextureIndexTopX=\"%d\"\n"
		"\t\t\t\ttextureIndexTopZ=\"%d\"\n"
		"\t\t\t\ttextureIndexRoofX=\"%d\"\n"
		"\t\t\t\ttextureIndexRoofZ=\"%d\" />\n",
		ptr.wTextIdxTopX, ptr.wTextIdxTopZ,
		ptr.wTextIdxRoofX, ptr.wTextIdxRoofZ);
	
	return nBytesRead;
}


#if (defined(__BORLANDC__))
#pragma argsused
#endif
/*
 * Analyzes and decode ridge roof buildings
 *
 * Parameters:
 * nOffset - offset to current obj chunk
 * hdr - pointer to building header info
 *
 * Return value:
 * number of bytes read
 */
static int DecodeRidgeRoofBuilding(int nOffset,building_hdr_t *hdr)
{
	rect_bldgrr_t ptr;
	int nBytesRead = 0;
	
	// get building
	ptr.wSizeX=GET_U16(nOffset);
	ptr.wSizeZ=GET_U16(nOffset+2);
	ptr.wBottomTexture=GET_U16(nOffset+4);
	ptr.wSizeBottomY=GET_U16(nOffset+6);
	ptr.wTextIdxBottomX=GET_U16(nOffset+8);
	ptr.wTextIdxBottomZ=GET_U16(nOffset+10);
	ptr.wWindowTexture=GET_U16(nOffset+12);
	ptr.wSizeWindowY=GET_U16(nOffset+14);
	ptr.wTextIdxWindowX=GET_U16(nOffset+16);
	ptr.wTextIdxWindowY=GET_U16(nOffset+18);
	ptr.wTextIdxWindowZ=GET_U16(nOffset+20);
	ptr.wTopTexture=GET_U16(nOffset+22);
	ptr.wSizeTopY=GET_U16(nOffset+24);
	ptr.wTextIdxTopX=GET_U16(nOffset+26);
	ptr.wTextIdxTopZ=GET_U16(nOffset+28);
	ptr.wRoofTexture=GET_U16(nOffset+30);
	ptr.wTextIdxRoofX=GET_U16(nOffset+32);
	ptr.wTextIdxRoofZ=GET_U16(nOffset+34);
	ptr.wSizeRoofY=GET_U16(nOffset+36);
	ptr.wTextIdxGableY=GET_U16(nOffset+38);
	ptr.wGableTexture=GET_U16(nOffset+40);
	ptr.wTextIdxGableZ=GET_U16(nOffset+42);
	ptr.wUnk5=GET_U16(nOffset+44);
	nBytesRead+=sizeof(rect_bldgrr_t);
	
	PrintBuildingInfo(ptr.wBottomTexture, ptr.wRoofTexture, ptr.wTopTexture, 
		ptr.wWindowTexture);
	
	PrintRoofInfo("RIDGE", ptr.wSizeX, ptr.wSizeZ, ptr.wSizeBottomY);
	
	
	fprintf(outfile,"\t\t\t\ttextureIndexBottomX=\"%d\"\n"
		"\t\t\t\ttextureIndexBottomZ=\"%d\"\n"
		"\t\t\t\tsizeWindowY=\"%d\"\n"
		"\t\t\t\ttextureIndexWindowX=\"%d\"\n"
		"\t\t\t\ttextureIndexWindowY=\"%d\"\n"
		"\t\t\t\ttextureIndexWindowZ=\"%d\"\n",
		ptr.wTextIdxBottomX, ptr.wTextIdxBottomZ,
		ptr.wSizeWindowY, ptr.wTextIdxWindowX,
		ptr.wTextIdxWindowY, ptr.wTextIdxWindowZ);
	
	
	fprintf(outfile,"\t\t\t\tsizeTopY=\"%d\"\n"
		"\t\t\t\ttextureIndexTopX=\"%d\"\n"
		"\t\t\t\ttextureIndexTopZ=\"%d\"\n"
		"\t\t\t\ttextureIndexRoofX=\"%d\"\n"
		"\t\t\t\ttextureIndexRoofZ=\"%d\"\n"
		"\t\t\t\tsizeRoofY=\"%d\"\n"
		"\t\t\t\tgableTexture=\"%d\"\n"
		"\t\t\t\ttextureIndexGableY=\"%d\"\n"
		"\t\t\t\ttextureIndexGableZ=\"%d\" />\n",
		ptr.wSizeTopY, ptr.wTextIdxTopX,
		ptr.wTextIdxTopZ, ptr.wTextIdxRoofX,
		ptr.wTextIdxRoofZ, ptr.wSizeRoofY,
		ptr.wGableTexture, ptr.wTextIdxGableY,
		ptr.wTextIdxGableZ);
	
	return nBytesRead;
}


#if (defined(__BORLANDC__))
#pragma argsused
#endif
/*
 * Analyzes and decode slant roof buildings
 *
 * Parameters:
 * nOffset - offset to current obj chunk
 * hdr - pointer to building header info
 *
 * Return value:
 * number of bytes read
 */
static int DecodeSlantRoofBuilding(int nOffset,building_hdr_t *hdr)
{
	rect_bldgsr_t ptr;
	int nBytesRead = 0;
	
	// get building
	ptr.wSizeX=GET_U16(nOffset);
	ptr.wSizeZ=GET_U16(nOffset+2);
	ptr.wBottomTexture=GET_U16(nOffset+4);
	ptr.wSizeBottomY=GET_U16(nOffset+6);
	ptr.wTextIdxBottomX=GET_U16(nOffset+8);
	ptr.wTextIdxBottomZ=GET_U16(nOffset+10);
	ptr.wWindowTexture=GET_U16(nOffset+12);
	ptr.wSizeWindowY=GET_U16(nOffset+14);
	ptr.wTextIdxWindowX=GET_U16(nOffset+16);
	ptr.wTextIdxWindowY=GET_U16(nOffset+18);
	ptr.wTextIdxWindowZ=GET_U16(nOffset+20);
	ptr.wTopTexture=GET_U16(nOffset+22);
	ptr.wSizeTopY=GET_U16(nOffset+24);
	ptr.wTextIdxTopX=GET_U16(nOffset+26);
	ptr.wTextIdxTopZ=GET_U16(nOffset+28);
	ptr.wRoofTexture=GET_U16(nOffset+30);
	ptr.wTextIdxRoofX=GET_U16(nOffset+32);
	ptr.wTextIdxRoofZ=GET_U16(nOffset+34);
	ptr.wSizeRoofY=GET_U16(nOffset+36);
	ptr.wTextIdxGableY=GET_U16(nOffset+38);
	ptr.wGableTexture=GET_U16(nOffset+40);
	ptr.wTextIdxGableZ=GET_U16(nOffset+42);
	ptr.wFaceTexture=GET_U16(nOffset+44);
	ptr.wTextIdxFaceX=GET_U16(nOffset+46);
	ptr.wTextIdxFaceY=GET_U16(nOffset+48);
	ptr.wUnk5=GET_U16(nOffset+50);
	nBytesRead+=sizeof(rect_bldgsr_t);
	
	PrintBuildingInfo(ptr.wBottomTexture, ptr.wRoofTexture, ptr.wTopTexture, 
		ptr.wWindowTexture);
	
	PrintRoofInfo("SLANT", ptr.wSizeX, ptr.wSizeZ, ptr.wSizeBottomY);
	
	fprintf(outfile,"\t\t\t\ttextureIndexBottomX=\"%d\"\n"
		"\t\t\t\ttextureIndexBottomZ=\"%d\"\n"
		"\t\t\t\tsizeWindowY=\"%d\"\n"
		"\t\t\t\ttextureIndexWindowX=\"%d\"\n"
		"\t\t\t\ttextureIndexWindowY=\"%d\"\n"
		"\t\t\t\ttextureIndexWindowZ=\"%d\"\n",
		ptr.wTextIdxBottomX, ptr.wTextIdxBottomZ,
		ptr.wSizeWindowY, ptr.wTextIdxWindowX,
		ptr.wTextIdxWindowY, ptr.wTextIdxWindowZ);
	
	fprintf(outfile,"\t\t\t\tsizeTopY=\"%d\"\n"
		"\t\t\t\ttextureIndexTopX=\"%d\"\n"
		"\t\t\t\ttextureIndexTopZ=\"%d\"\n"
		"\t\t\t\ttextureIndexRoofX=\"%d\"\n"
		"\t\t\t\ttextureIndexRoofZ=\"%d\"\n"
		"\t\t\t\tsizeRoofY=\"%d\"\n"
		"\t\t\t\tgableTexture=\"%d\"\n"
		"\t\t\t\ttextureIndexGableY=\"%d\"\n"
		"\t\t\t\ttextureIndexGableZ=\"%d\"\n",
		ptr.wSizeTopY, ptr.wTextIdxTopX,
		ptr.wTextIdxTopZ, ptr.wTextIdxRoofX,
		ptr.wTextIdxRoofZ, ptr.wSizeRoofY,
		ptr.wGableTexture, ptr.wTextIdxGableY,
		ptr.wTextIdxGableZ);
	
	fprintf(outfile,"\t\t\t\tfaceTexture=\"%d\"\n"
		"\t\t\t\ttextureIndexFaceX=\"%d\"\n"
		"\t\t\t\ttextureIndexFaceY=\"%d\" />\n",
		ptr.wFaceTexture, ptr.wTextIdxFaceX,
		ptr.wTextIdxFaceY);
	
	return nBytesRead;
}

#if (defined(__BORLANDC__))
#pragma argsused
#endif
/*
 * Analyzes and decode pyramidal buildings
 *
 * Parameters:
 * nOffset - offset to current obj chunk
 * hdr - pointer to building header info
 *
 * Return value:
 * number of bytes read
 */
static int DecodePyramidalBuilding(int nOffset,building_hdr_t *hdr)
{
	int nBytesRead=0;
	pyram_bldg_t ptr;
	
	// get building
	ptr.wSizeX=GET_U16(nOffset);
	ptr.wSizeZ=GET_U16(nOffset+2);
	ptr.wSizeTopX=GET_U16(nOffset+4);
	ptr.wSizeTopZ=GET_U16(nOffset+6);
	ptr.wBottomTexture=GET_U16(nOffset+8);
	ptr.wSizeBottomY=GET_U16(nOffset+10);
	ptr.wTextIdxBottomX=GET_U16(nOffset+12);
	ptr.wTextIdxBottomZ=GET_U16(nOffset+14);
	ptr.wWindowTexture=GET_U16(nOffset+16);
	ptr.wSizeWindowY=GET_U16(nOffset+18);
	ptr.wTextIdxWindowX=GET_U16(nOffset+20);
	ptr.wTextIdxWindowY=GET_U16(nOffset+22);
	ptr.wTextIdxWindowZ=GET_U16(nOffset+24);
	ptr.wTopTexture=GET_U16(nOffset+26);
	ptr.wSizeTopY=GET_U16(nOffset+28);
	ptr.wTextIdxTopX=GET_U16(nOffset+30);
	ptr.wTextIdxTopZ=GET_U16(nOffset+32);
	ptr.wRoofTexture=GET_U16(nOffset+34);
	ptr.wTextIdxRoofX=GET_U16(nOffset+36);
	ptr.wTextIdxRoofZ=GET_U16(nOffset+38);
	ptr.wUnk5=GET_U16(nOffset+40);
	nBytesRead+=sizeof(pyram_bldg_t);
	
	PrintBuildingInfo(ptr.wBottomTexture, ptr.wRoofTexture, ptr.wTopTexture, 
		ptr.wWindowTexture);
	
	fprintf(outfile,"\t\t\t<PyramidalBuilding\n"
		"\t\t\t\tsizeX=\"%d\"\n"
		"\t\t\t\tsizeZ=\"%d\"\n",
		ptr.wSizeX, ptr.wSizeZ);
	
	fprintf(outfile,"\t\t\t\tsizeTopX=\"%d\"\n"
		"\t\t\t\tsizeTopZ=\"%d\"\n"
		"\t\t\t\tsizeBottomY=\"%d\"\n",
		ptr.wSizeTopX, ptr.wSizeTopZ,
		ptr.wSizeBottomY);
	
	fprintf(outfile,"\t\t\t\ttextureIndexBottomX=\"%d\"\n"
		"\t\t\t\ttextureIndexBottomZ=\"%d\"\n"
		"\t\t\t\tsizeWindowY=\"%d\"\n",
		ptr.wTextIdxBottomX, ptr.wTextIdxBottomZ,
		ptr.wSizeWindowY);
	
	fprintf(outfile,"\t\t\t\ttextureIndexWindowX=\"%d\"\n"
		"\t\t\t\ttextureIndexWindowY=\"%d\"\n"
		"\t\t\t\ttextureIndexWindowZ=\"%d\"\n",
		ptr.wTextIdxWindowX,ptr.wTextIdxWindowY,
		ptr.wTextIdxWindowZ);
	
	fprintf(outfile,"\t\t\t\tsizeTopY=\"%d\"\n"
		"\t\t\t\ttextureIndexTopX=\"%d\"\n"
		"\t\t\t\ttextureIndexTopZ=\"%d\"\n",
		ptr.wSizeTopY,ptr.wTextIdxTopX,
		ptr.wTextIdxBottomZ);
	
	fprintf(outfile,"\t\t\t\ttextureIndexRoofX=\"%d\"\n"
		"\t\t\t\ttextureIndexRoofZ=\"%d\" />\n",
		ptr.wTextIdxRoofX, ptr.wTextIdxRoofZ);
	
	return nBytesRead;
}

#if (defined(__BORLANDC__))
#pragma argsused
#endif
/*
 * Analyzes and decode multiside buildings
 *
 * Parameters:
 * nOffset - offset to current obj chunk
 * hdr - pointer to building header info
 *
 * Return value:
 * number of bytes read
 */
static int DecodeMultiSideBuilding(int nOffset,building_hdr_t *hdr)
{
	int nBytesRead=0;
	ms_bldg_t ptr;
	
	// get building
	ptr.wSidesCount=GET_U16(nOffset);
	ptr.wSizeX=GET_U16(nOffset+2);
	ptr.wSizeZ=GET_U16(nOffset+4);
	ptr.wBottomTexture=GET_U16(nOffset+6);
	ptr.wSizeBottomY=GET_U16(nOffset+8);
	ptr.wTextIdxBottomX=GET_U16(nOffset+10);
	ptr.wWindowTexture=GET_U16(nOffset+12);
	ptr.wSizeWindowY=GET_U16(nOffset+14);
	ptr.wTextIdxWindowX=GET_U16(nOffset+16);
	ptr.wTextIdxWindowY=GET_U16(nOffset+18);
	ptr.wTopTexture=GET_U16(nOffset+20);
	ptr.wSizeTopY=GET_U16(nOffset+22);
	ptr.wTextIdxTopX=GET_U16(nOffset+24);
	ptr.wRoofTexture=GET_U16(nOffset+26);
	ptr.wSizeRoofY=GET_U16(nOffset+28);
	ptr.wTextIdxRoofX=GET_U16(nOffset+30);
	ptr.wTextIdxRoofZ=GET_U16(nOffset+32);
	ptr.wUnk5=GET_U16(nOffset+34);
	nBytesRead+=sizeof(ms_bldg_t);
	
	PrintBuildingInfo(ptr.wBottomTexture,ptr.wRoofTexture,ptr.wTopTexture,
		ptr.wWindowTexture);
	
	fprintf(outfile,"\t\t\t<!-- WARNING: \"textureIndexRoofY\" and \"smoothing\""
		" are ignored\n\t\t\t\t(do not compare in BGL files), although required by BglComp -->\n");
	fprintf(outfile,"\t\t\t<MultiSidedBuilding\n"
		"\t\t\t\tbuildingSides=\"%d\"\n",
		ptr.wSidesCount);
	fprintf(outfile,"\t\t\t\tsizeX=\"%d\"\n"
		"\t\t\t\tsizeZ=\"%d\"\n"
		"\t\t\t\tsizeBottomY=\"%d\"\n",
		ptr.wSizeX, ptr.wSizeZ,ptr.wSizeBottomY);
	
	fprintf(outfile,"\t\t\t\ttextureIndexBottomX=\"%d\"\n"
		"\t\t\t\tsizeWindowY=\"%d\"\n"
		"\t\t\t\ttextureIndexWindowX=\"%d\"\n"
		"\t\t\t\ttextureIndexWindowY=\"%d\"\n",
		ptr.wTextIdxBottomX,ptr.wSizeWindowY,
		ptr.wTextIdxWindowX,ptr.wTextIdxWindowY);
	
	
	fprintf(outfile,"\t\t\t\tsizeTopY=\"%d\"\n"
		"\t\t\t\ttextureIndexTopX=\"%d\"\n"
		"\t\t\t\tsizeRoofY=\"%d\"\n",
		ptr.wSizeTopY,ptr.wTextIdxTopX,
		ptr.wSizeRoofY);
	
	fprintf(outfile,"\t\t\t\ttextureIndexRoofX=\"%d\"\n"
		"\t\t\t\ttextureIndexRoofZ=\"%d\"\n",
		ptr.wTextIdxRoofX, ptr.wTextIdxRoofZ);
	
	fprintf(outfile,"\t\t\t\ttextureIndexRoofY=\"256\"\n"
		"\t\t\t\tsmoothing=\"TRUE\" />\n");
	
	return nBytesRead;
}


#if (defined(__BORLANDC__))
#pragma argsused
#endif
/*
 * Analyzes and decode buildings
 *
 * Parameters:
 * pszName - object name
 * nOffset - offset to current obj chunk
 * nRecLen - current chunk length
 *
 * Return value:
 * number of bytes read
 */
int DecodeBuilding(WORD wId,char *pszName, int nOffset, int nRecLen)
{
	int nBytesRead=0;
	building_hdr_t hdr;

	TRACE("DecodeBuilding\n");
	
	// get building header
	hdr.fScale=GET_FLOAT(nOffset);
	hdr.wUnk1=GET_U16(nOffset+4);
	hdr.wChunkLen=GET_U16(nOffset+6);
	hdr.wId=GET_U16(nOffset+8);
	nBytesRead+=sizeof(building_hdr_t);
	
	// print initial informations
	fprintf(outfile,"\t\t<%s scale=\"%0.2lf\"",
		pszName,hdr.fScale);
	
	// see what kind of building we have there
	switch (hdr.wId)
	{
	case BLDG_FLAT_ROOF:
		nBytesRead+=DecodeFlatRoofBuilding(nOffset+nBytesRead, &hdr);
		break;
	case BLDG_PEAKED_ROOF:
		nBytesRead+=DecodePeakedRoofBuilding(nOffset+nBytesRead, &hdr);
		break;
	case BLDG_RIDGE_ROOF:
		nBytesRead+=DecodeRidgeRoofBuilding(nOffset+nBytesRead, &hdr);
		break;
	case BLDG_SLANT_ROOF:
		nBytesRead+=DecodeSlantRoofBuilding(nOffset+nBytesRead, &hdr);
		break;
	case BLDG_MULTISIDED:
		nBytesRead+=DecodeMultiSideBuilding(nOffset+nBytesRead, &hdr);
		break;
	case BLDG_PYRAMIDAL:
		nBytesRead+=DecodePyramidalBuilding(nOffset+nBytesRead, &hdr);
		break;
		
		
	}
	
	// print closing bracket
	fprintf(outfile,"\t\t</%s>\n", pszName);
	
	
	// return value
	return nBytesRead;
}


decode_t decode_table[] =
{
	{ SCNOBJ_BUILDING,		"GenericBuilding", DecodeBuilding },
	{ SCNOBJ_BUILDING_FSX,	"GenericBuilding", DecodeBuilding },
	{ SCNOBJ_LIBRARY_OBJ,	"LibraryObject", DecodeLibraryObject },
	{ SCNOBJ_LIBRARY_OBJ_FSX, "LibraryObject", DecodeLibraryObject },
	{ SCNOBJ_WINDSOCK,		"Windsock", DecodeWindSock },
	{ SCNOBJ_WINDSOCK_FSX,	"Windsock", DecodeWindSock },
	{ SCNOBJ_EFFECT,		"Effect", DecodeEffect },
	{ SCNOBJ_EFFECT_FSX,	"Effect", DecodeEffect },
	{ SCNOBJ_TRIGGER,		"Trigger", DecodeTrigger },
	{ SCNOBJ_TRIGGER_FSX,	"Trigger", DecodeTrigger },
	{ 0, "Unknown Object", NULL }
};


static void AddTaxiToList(UINT nOffset)
{
	intlist_t *ptr = MALLOC(sizeof(intlist_t));
	TRACE("AddTaxiToList\n");

	PRECONDITION(NULL!=ptr);
	ptr->nOffset=nOffset;	// mark its offset
	ptr->nParam=1;
	ptr->next=NULL;
	if (NULL==lpTaxiSign)		// add new node on bottom of the list
	{
		lpTaxiSign=ptr;
		lpTaxiSignTail=ptr;
	}
	else
	{
		lpTaxiSignTail->next=ptr;
		lpTaxiSignTail=ptr;
	}
}

/*
 * Analyzes and decode scenery objects
 *
 * Parameters:
 * nGrpCount - number of obj available in this group
 * nGrpOffset - offset to current obj chunk
 * nGrpLen - current chunk length
 *
 * Return value:
 * none
 */
void AnalyzeSceneryObject(DWORD nGrpCount, DWORD nGrpOffset, DWORD nChunkLen)
{
	objheader_t hdr;                // object header
	int j;
	BOOL rec_found;
	char szLat[24];
	char szLon[24];
	char szAlt[24];
	DWORD nSize;
	DWORD nStart, nEnd;
	DWORD nBeginOfRec;

	TRACE("AnalyzeSceneryObject\n");
	nStart = nGrpOffset;
    nEnd = nGrpOffset+nChunkLen;
    while (nStart<nEnd)			// while we have objects
	{
		nBeginOfRec = nStart;

		hdr.wId = GET_U16(nBeginOfRec);
		hdr.wRecLen = GET_U16(nBeginOfRec+2);
		nSize=hdr.wRecLen;

		if ((hdr.wId==SCNOBJ_TAXISIGN) || (hdr.wId==SCNOBJ_TAXISIGN_FSX))
		{
			if (!nTerse)
				PrintObjectSpec("TaxiwaySign",nStart);
			AddTaxiToList((UINT)nBeginOfRec);
			goto skip;
		}
		hdr.nLon = GET_S32(nBeginOfRec+4);
		hdr.nLat = GET_S32(nBeginOfRec+8);
		hdr.nAlt = GET_S32(nBeginOfRec+12);
		hdr.bAltIsAgl = GET_U16(nBeginOfRec+16) ? 1 : 0;
		hdr.wPitch = GET_U16(nBeginOfRec+18);
		hdr.wBank = GET_U16(nBeginOfRec+20);
		hdr.wHeading= GET_U16(nBeginOfRec+22);
		hdr.nComplexity = GET_S32(nBeginOfRec+24);
		if (hdr.wId>=SCNOBJ_FSX)
			nBeginOfRec+=16;	/* Skip FSX InstanceId */

		if (nPartialDecode)		// if partial decode is enabled
		{
			if (gcdist(fCenterLat,fCenterLon,
				fslat2lat(hdr.nLat),fslon2lon(hdr.nLon))>fCenterRad)
			{
				goto skip;	// skip the record if too far away
			}
		}
		
		// dirty workaround ???
		if (hdr.nComplexity<COMPLEXITY_VERY_SPARSE ||
			hdr.nComplexity>COMPLEXITY_EXTREMELY_DENSE)
		hdr.nComplexity=COMPLEXITY_VERY_SPARSE;

		if (!nTerse)
			PrintObjectSpec("SceneryObject",nStart);
		
		fprintf(outfile,"\t<SceneryObject lat=\"%s\" lon=\"%s\" alt=%s\n"
			"\t\taltitudeIsAgl=\"%s\" pitch=\"%0.2lf\" bank=\"%0.2lf\" heading=\"%0.2lf\"\n"
			"\t\timageComplexity=\"%s\">\n",
			LatString(fslat2lat(hdr.nLat),szLat), 
			LatString(fslon2lon(hdr.nLon),szLon), 
			AltString(hdr.nAlt,szAlt),
			truthTable[hdr.bAltIsAgl], (double)hdr.wPitch*360.0/65536.0,
			(double)hdr.wBank*360.0/65536.0, (double)hdr.wHeading*360.0/65536.0,
			cplxTable[hdr.nComplexity]);
		
		j = 0;
		rec_found = FALSE;
		while (decode_table[j].wId!=0)
		{
			if (decode_table[j].wId==hdr.wId)
			{
				rec_found = TRUE;
				nSize=28+nBeginOfRec-nStart+
					decode_table[j].lpfnDecode(
					hdr.wId, decode_table[j].pszName,
					nBeginOfRec+28,hdr.wRecLen-(28+nBeginOfRec-nStart));
				break;
			}
			++j;
		}
		if (!rec_found)
			DecodeUnknown(hdr.wId, "Unknown", nStart, hdr.wRecLen-28);

		fprintf(outfile, "\t</SceneryObject>\n");               
		fprintf(outfile,"\n");

skip:
		nStart+=nSize;
	}
}
