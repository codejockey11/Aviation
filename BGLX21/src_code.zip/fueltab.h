/*
 *   $Id: fueltab.h,v 1.3 2005/10/12 17:27:24 Alessandro Exp $
 */
#ifndef fueltab_h
#define fueltab_h

#define FUELNO	"NO"
#define FUELYES	"YES"
#define FUELUNK	"UNKNOWN"
#define FUELPR	"PRIOR_REQUEST"

typedef struct tag_fueltab_t
{
	UINT nKey;		// search key
	char *pszKind;	// fuel kind
	char *pszAvail;	// fuel availability
} fueltab_t;

/*extern fueltab_t fueltab[];*/

void get_fuel_kind(DWORD);

#endif

