/*
 *   $Id: util.h,v 1.12 2007/10/02 21:48:38 alexanto Exp $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#ifndef util_h
#define util_h

#include "charvec.h"
#include "fs2004.h"

#ifdef WIN32
#define VERSION "2.1 / WIN32"
#else
#define VERSION "2.1"
#endif

#define METERSTOFEET 3.2808
#define KMSTONAUTMILES 1.852
#define Pi 3.141592653589
#define RADVALUE (Pi/180)
#define DEGVALUE (180/Pi)


#ifdef LITTLE_ENDIAN	/* Little-endian same as BGL format */
# define GET_U16(p) *((UNALIGNED WORD *)&map.ptr[p])
# define GET_S32(p) *((signed long *)&map.ptr[p])
# define GET_U32(p) *((unsigned long *)&map.ptr[p])
# define GET_FLOAT(p) *((float *)&map.ptr[p])
#else			/* Endian-safe versions (assumes ints and floats have same endianess) */
# define GET_U16(p) (((WORD)map.ptr[p]) | (((WORD)map.ptr[p+1])<<8))
# define GET_S32(p) (((LONG)map.ptr[p]) |		\
		     (((LONG)map.ptr[p+1])<<8) |	\
		     (((LONG)map.ptr[p+2])<<16) |	\
		     (((LONG)map.ptr[p+3])<<24))
# define GET_U32(p) (((DWORD)map.ptr[p]) |		\
		     (((DWORD)map.ptr[p+1])<<8) |	\
		     (((DWORD)map.ptr[p+2])<<16) |	\
		     (((DWORD)map.ptr[p+3])<<24))
# define GET_FLOAT(p) get_float(p)
#endif	/* WIN32 */
#define GET_BYTE(p) map.ptr[p]
#define PSZ_STR(p) (char *)&map.ptr[p]
#define OFFSET(p) &map.ptr[p]

#define MAGVAR(d) ((double)d>=180.0 ? (double)d-360.0 : (double)d)

/*
 * Bit Flag Constants
 */
#define BIT0	0x00000001
#define BIT1	0x00000002
#define BIT2	0x00000004
#define BIT3	0x00000008
#define BIT4	0x00000010
#define BIT5	0x00000020
#define BIT6	0x00000040
#define BIT7	0x00000080
#define BIT8	0x00000100
#define BIT9	0x00000200
#define BIT10	0x00000400
#define BIT11	0x00000800
#define BIT12	0x00001000
#define BIT13	0x00002000
#define BIT14	0x00004000
#define BIT15	0x00008000
#define BIT16	0x00010000
#define BIT17	0x00020000
#define BIT18	0x00040000
#define BIT19	0x00080000
#define BIT20	0x00100000
#define BIT21	0x00200000
#define BIT22	0x00400000
#define BIT23	0x00800000
#define BIT24	0x01000000
#define BIT25	0x02000000
#define BIT26	0x04000000
#define BIT27	0x08000000
#define BIT28	0x10000000
#define BIT29	0x20000000
#define BIT30	0x40000000
#define BIT31	0x80000000


#define GET_FLAG(value,mask,flag) flag==(value & mask)

typedef struct _tag_map_file_t
{
#ifdef NT_API_CALLS
        HANDLE hFile;           // handle to file
        HANDLE hMap;            // handle to mapping
#endif
        BYTE *ptr;              // pointer to mapped file
        DWORD dwSize;           // file size in bytes
} map_file_t;

/*
 * sructure to accomodate icao ids
 */
typedef struct
{
	int nCount;
	icaoid_t *cicao;
} icaos_t;

/*
 * singly linked list of ILS offset withtin bgl file
 */
typedef struct tag_intlist_t
{
	DWORD nOffset;
	DWORD nParam;
	struct tag_intlist_t *next;
} intlist_t;

extern char OutFileDir[1024];
extern map_file_t map;
extern char_pool_t *cobjects;
extern char_pool_t *cairports;
extern char_pool_t *ccities;
extern char_pool_t *cstates;
extern char_pool_t *ccountries;
extern char_pool_t *cregions;

extern intlist_t *lpIls;
extern intlist_t *lpIlsTail;
extern intlist_t *lpTaxiSign;
extern intlist_t *lpTaxiSignTail;


extern icaos_t cicaos;

extern FILE *outfile;
extern int nPass;

#define SET_PASS1 nPass=1
#define SET_PASS2 nPass=2
#define IS_PASS1 (1==nPass)
#define IS_PASS2 (2==nPass)


DWORD Strip11Bits(DWORD d);

extern DWORD OpenInputFile(char *);
extern void CloseInputFile(void);
extern int ValidateInputFile(void);
extern void StartObjLoop(void);
extern FILE *OpenOutputFile(char *);
extern void AnalyzeNdb(DWORD, DWORD, DWORD);
extern void AnalyzeVor(DWORD, DWORD, DWORD);
extern char *DecodeRegionStr(DWORD, char *);
extern double fslat2lat(int);
extern double fslon2lon(int);
extern char *DecodeIdStr(DWORD, char *, DWORD);
void AnalyzeMkb(DWORD, DWORD, DWORD);
extern void AnalyzeWpt(DWORD, DWORD, DWORD);
extern void AnalyzeApt(DWORD, DWORD, DWORD);
extern void AnalyzeSceneryObject(DWORD, DWORD, DWORD);
extern void AnalyzeModelData(DWORD, DWORD, DWORD);
extern void AnalyzeExclusionRectangle(DWORD, DWORD, DWORD);
extern void AnalyzeRegion(DWORD, DWORD, DWORD);

extern void FreeArrays(void);
extern int InitArrays(void);
extern void PrintObjectSpec(char *, int);
extern char *RangeString(float, char *);
extern char *LatString(double, char *);
extern char *AltString(int, char *);
extern DWORD WriteChunkToFile(const char *, BYTE *, DWORD);
extern double gcdist(double,double,double,double);
extern double gcbearing(double,double,double,double);
extern char *DimString(float, char *);
extern double deg2real(char *);
extern void DumpToHex(DWORD, DWORD);
extern void PrintError(char *, DWORD);
extern char *strrtrim(char *);
extern char *strltrim(char *);
extern const char *BOGUSFILESIZE;
extern const char *MAPVIEWFAILED;
extern const char *DUPEFILEMAPPING;
extern const char *FILEMAPPINGFAILED;

extern void AnalyzeApproachContents(DWORD, DWORD, DWORD);
extern void CartesianOffset(double, double, double, double, double *, double *);

extern void AnalyzeTaxiSign(DWORD);

char *strreplace(char *str, char *oldstr, char *newstr);

extern DWORD GetClosestPrime(DWORD);
/*
 * geopol routines - defined in anagepol.c
 */
extern void TabCreate(DWORD nSize);
extern void TabDestroy(void);
extern int TabFind(DWORD nNumber, DWORD *nPos);
extern int TabAdd(DWORD nNumber);
void GeopolBoundaryGroupLoop(DWORD,DWORD, DWORD, DWORD);



#define vorlat2lat(i) ndblat2lat(i)
#define vorlon2lon(i) ndblon2lon(i)

#define ndblat2lat(i) fslat2lat(i)
#define ndblon2lon(i) fslon2lon(i)

extern intlist_t *lpWpt;
extern intlist_t *lpWptTail;


extern const char *CANTOPENFILE;
extern const char *INVALIDFILE;
extern void PrintXmlString(unsigned char *, DWORD);
extern char *DecodeIlsStr(DWORD number, char *p);

#ifdef ANSI
char *strlwr(char * string);
#endif

float get_float(int p);

#endif
