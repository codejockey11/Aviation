/*
 *   $Id: charvec.c,v 1.3 2004/04/08 11:57:15 Alessandro Exp $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: Dynamic Array of String-z structure $
 *
 *   $Log: charvec.c,v $
 *   Revision 1.3  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.2  2004/02/12 15:17:07  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2004/02/04 14:07:48  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"

#ifdef NT_API_CALLS

#define AllocFlags (GMEM_MOVEABLE | GMEM_ZEROINIT)

void *GlobalAllocPtr(DWORD dwSize)
{
	HGLOBAL hGlob = GlobalAlloc(AllocFlags,dwSize);
    return (0==hGlob) ? NULL : GlobalLock(hGlob);

}

void *GlobalReAllocPtr(void *buf, DWORD dwSize)
{

	HGLOBAL hGlob = GlobalHandle(buf);
	HGLOBAL hRealloc;
	GlobalUnlock(hGlob);
	hRealloc = GlobalReAlloc(hGlob,dwSize,AllocFlags);
	return (hRealloc==0) ? NULL : GlobalLock(hRealloc);
}

HGLOBAL GlobalFreePtr(void *buf)
{

	HGLOBAL hFree;
	HGLOBAL hGlob = GlobalHandle(buf);
	GlobalUnlock(hGlob);
	hFree = GlobalFree(hGlob);
	return hFree;
}
#endif

int ChrPoolFind(char_pool_t *p, char *S, int *Index)
{
	int L, H, I, C;
	int Result = 0;
	L = 0;
	H = p->nCount - 1;
	while (L <= H)
	{
		I = (L + H) >> 1;
		C = strcmp(p->ptr[I].s,S);
		if (C < 0)
			L = I + 1;
		else
		{
			H = I - 1;
			if (C == 0)
			{
				Result = 1;
				if (p->nDupMode!=DUP_ACCEPT)
					L = I;
			}
		}
	}
	*Index = L;
	return Result;

}

static void ChrPoolInsertItem(char_pool_t **p, int Index, char *S, int i)
{
	int Delta, newCapacity, nSize=strlen(S);
	if ((*p)->lpOnChanging!=NULL)
		(*(*p)->lpOnChanging)();

	if ((*p)->nCapacity==(*p)->nCount)
	{
		if ((*p)->nCapacity>64)
			Delta = (*p)->nCapacity / 4;
		else if ((*p)->nCapacity>16)
			Delta = 8;
		else
			Delta = 4;

		newCapacity = (*p)->nCapacity + Delta;

		if ((*p)->ptr)
			(*p)->ptr=(char_entry_t *)REALLOC((*p)->ptr,
				newCapacity*sizeof(char_entry_t));
		else
			(*p)->ptr=(char_entry_t *)CALLOC(newCapacity,sizeof(char_entry_t));
		(*p)->nCapacity = newCapacity;
	}


	if (Index<(*p)->nCount)
		memmove(&(*p)->ptr[Index+1],&(*p)->ptr[Index],
			((*p)->nCount - Index) * sizeof(char_entry_t));

	(*p)->ptr[Index].i=i;
	(*p)->ptr[Index].s = (char *)MALLOC(nSize+1);
	memmove((*p)->ptr[Index].s,S,nSize);
	(*p)->ptr[Index].s[nSize]='\0';
	(*p)->nCount++;
	if ((*p)->lpOnChanged!=NULL)
		(*(*p)->lpOnChanged)();
}

char_pool_t *ChrPoolInit(void)
{
	char_pool_t *p =
		(char_pool_t *)CALLOC(1,sizeof(char_pool_t));
	if (p)
	{
		p->nCapacity=0; p->nCount=0;
		p->ptr=0;
	}

	return p;
}

void ChrPoolFlush(char_pool_t *p)
{
	int i;
	if (p)
	{
		if (p->ptr)
		{
			for (i=0; i<p->nCount; i++)
			{
				if (p->ptr[i].s)
				{
					FREE(p->ptr[i].s);
					p->ptr[i].s=0;
				}
			}
			FREE(p->ptr);
			p->ptr=0;
		}
		p->nCapacity=p->nCount=0;
	}
}


void ChrPoolFree(char_pool_t *p)
{
	if (p)
	{
		ChrPoolFlush(p);
		FREE(p);
		p=0;
	}
}

int ChrPoolAdd(char_pool_t *p, char *str, int i)
{

	int Result;
	if (!p->nSorted)
	{
		Result = p->nCount;
	}
	else
	{
		if (ChrPoolFind(p, str, &Result))
		{
			switch (p->nDupMode)
			{
				case DUP_IGNORE:
					return -1;
				case DUP_ERROR:
					if (p->lpOnError)
						(* p->lpOnError)(ERR_DUPE,0,0);
			}
		}
	}
	ChrPoolInsertItem(&p,Result,str,i);
	return Result;
}


void ChrPoolInsert(char_pool_t *p, int Index, char *str, int i)
{
	if (p->nSorted)
	{
		if (p->lpOnError)
			(* p->lpOnError)(ERR_SORTED_LIST,0,0);
	}
	else if (Index<0 || Index > p->nCount)
	{
		if (p->lpOnError)
			(* p->lpOnError)(ERR_OUT_OF_BOUNDS,Index,p->nCount);
	}
	else
		ChrPoolInsertItem(&p,Index,str,i);
}

void ChrPoolDelete(char_pool_t *p, int Index)
{
	if (Index<0 || Index > p->nCount)
	{
		if (p->lpOnError)
			(* p->lpOnError)(ERR_OUT_OF_BOUNDS,Index,p->nCount);
	}
	else
	{
		if (p->lpOnChanging!=NULL)
			(*p->lpOnChanging)();

		if (p->ptr[Index].s)
			FREE(p->ptr[Index].s);
		p->nCount--;
		if (Index<p->nCount)
			memcpy(&p->ptr[Index],&p->ptr[Index+1],
				(p->nCount - Index) * sizeof(char_entry_t));

		if (p->lpOnChanged!=NULL)
			(*p->lpOnChanged)();
	}
}


