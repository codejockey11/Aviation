/*
 *   $Id: util.c,v 1.12 2007/10/20 00:15:15 Alessandro Exp Alessandro $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: miscellaneous utilities $
 *
 *   $Log: util.c,v $
 *   Revision 1.12  2007/10/20 00:15:15  Alessandro
 *   Minor hanges
 *
 *   Revision 1.11  2007/10/02 21:46:38  alexanto
 *   Added FSX support
 *
 *   Revision 1.10  2005/10/20 10:57:11  alexanto
 *   +Id+Log
 *
 *   Revision 1.9  2005/05/01 16:12:32  alexanto
 *   Some changes
 *
 *   Revision 1.8  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.7  2004/03/12 15:19:59  alexanto
 *   Modified DecodeIdStr with no brute force algorithm
 *   Added DecodeIlsStr (to lookup ILS correctly)
 *
 *   Revision 1.6  2004/02/25 13:47:04  alexanto
 *   Added XML translation routine
 *
 *   Revision 1.5  2004/02/19 17:51:07  alexanto
 *   Modified DecodeRegionStr to handle seeded
 *   region numbers (terminal_ndbs) and so on
 *
 *   Revision 1.4  2004/02/16 10:03:01  alexanto
 *   Added routines for increasing compatibility with
 *   compilers which don't fully support ANSI
 *
 *   Revision 1.3  2004/02/14 17:34:55  alexanto
 *   Changed object sort routine to use default qsort RTL func
 *
 *   Revision 1.2  2004/02/12 15:17:07  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2004/02/04 14:07:48  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"


int nPass;

map_file_t map;
intlist_t *lpIls;
intlist_t *lpIlsTail;

intlist_t *lpWpt;
intlist_t *lpWptTail;


intlist_t *lpTaxiSign;
intlist_t *lpTaxiSignTail;


char_pool_t *cairports;
char_pool_t *ccities;
char_pool_t *cstates;
char_pool_t *ccountries;
char_pool_t *cregions;
icaos_t cicaos;
char_pool_t *cobjects;

static const char *CANTWRITEFILE = "Can't write %s";
const char *CANTOPENFILE = "Can't open %s";
const char *INVALIDFILE = "Input file: not a valid FS2004 or FSX facility data BGL!";
const char *BOGUSFILESIZE = "%s is 0 bytes in size. Nothing to decode";
const char *MAPVIEWFAILED = "Could not map %s - MapViewOfFile() failed";
const char *DUPEFILEMAPPING = "File mapping failed, object already exists\n, file: %s";
const char *FILEMAPPINGFAILED = "File mapping failed file: %s";
static const char *RegionLookUpTable = "  0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
FILE *outfile;


/*
 * trim white chars from end of string
 *
 * input:
 * st - string to trim
 *
 * return value:
 * trimmed string
 */
char *strrtrim(char *st)
{
	int i =strlen(st);
    while(st[i]<=' ') 
	{
		st[i]='\0';
        i--;
    }
	return st;
}

/*
 * trim white chars from begin of string
 *
 * input:
 * st - string to trim
 *
 * return value:
 * trimmed string
 */
char *strltrim(char *str)
{ 
	DWORD i = 0;
    register char *r = str;
    register char t;
	while ((t = *r++) != '\0' && t <= ' ')
	{
		i++;
		if (t == '\0')				// If no match found
			break;
	}
	if (i)
		strcpy(str,str+i);			// shift string
	return str;						// Return pointer to string
}

/*
 * initialize arrays for airports
 *
 * Parameters:
 * none
 *
 * Return value:
 * true on success
 */
int InitArrays(void)
{
	cairports = ChrPoolInit();
	ccities = ChrPoolInit();
	if (ccities)
	{
		ccities->nSorted=TRUE;
		ccities->nDupMode=DUP_IGNORE;
	}
	cstates = ChrPoolInit();
	if (cstates)
	{
		cstates->nSorted=TRUE;
		cstates->nDupMode=DUP_IGNORE;
	}
	ccountries = ChrPoolInit();
	if (ccountries)
	{
		ccountries->nSorted=TRUE;
		ccountries->nDupMode=DUP_IGNORE;
	}

	cregions = ChrPoolInit();
	if (cregions)
	{
		cregions->nSorted=TRUE;
		cregions->nDupMode=DUP_IGNORE;
	}
	cobjects = ChrPoolInit();
	if (cobjects)
	{
		cobjects->nSorted=TRUE;
		cobjects->nDupMode=DUP_IGNORE;
	}

	// init ILS lookup linked list
	lpIls = NULL;
	lpIlsTail=NULL;

	// init TAXI SIGN lookup linked list
	lpTaxiSign=NULL;
	lpTaxiSignTail=NULL;

	lpWpt=lpWptTail=NULL;

	cicaos.cicao=NULL;
	cicaos.nCount=0;
	return (cobjects && cregions && cairports && ccities && cstates && ccountries);



}

/*
 * finalize arrays for airports
 *
 * Parameters:
 * none
 *
 * Return value:
 * none
 */
void FreeArrays(void)
{
	int i;
	char *ptr;
	intlist_t *p,*p1;

#ifdef DEBUG
	char szId[6];
	int j;
	if (cregions->nCount)
	{
		fprintf(outfile,"<!--\n\tdump of region names\n");
		for (i=0; i<cregions->nCount; i++)
		{
			fprintf(outfile,"\t%s\n",cregions->ptr[i].s);

		}
		fprintf(outfile,"-->\n");
	}

	if (ccountries->nCount)
	{
		fprintf(outfile,"<!--\n\tdump of country names\n");
		for (i=0; i<ccountries->nCount; i++)
		{
			fprintf(outfile,"\t%s\n",ccountries->ptr[i].s);

		}
		fprintf(outfile,"-->\n");
	}

	if (cstates->nCount)
	{
		fprintf(outfile,"<!--\n\tdump of state names\n");
		for (i=0; i<cstates->nCount; i++)
		{
			fprintf(outfile,"\t%s\n",cstates->ptr[i].s);

		}
		fprintf(outfile,"-->\n");
	}

	if (ccities->nCount)
	{
		fprintf(outfile,"<!--\n\tdump of city names\n");
		for (i=0; i<ccities->nCount; i++)
		{
			fprintf(outfile,"\t%s\n",ccities->ptr[i].s);

		}
		fprintf(outfile,"-->\n");
	}

	if (cairports->nCount)
	{
		fprintf(outfile,"<!--\n\tdump of airport names\n");
		for (i=0; i<cairports->nCount; i++)
		{
			fprintf(outfile,"\t%s\n",cairports->ptr[i].s);

		}
		fprintf(outfile,"-->\n");
	}

	if (cicaos.nCount)
	{
		fprintf(outfile,"<!--\n\tdump of icao structures\n");
		for (i=0; i<cicaos.nCount; i++)
		{
			DecodeIdStr(cicaos.cicao[i].nId,szId,0x41);	// convert packed ICAO ID

			fprintf(outfile,"\tAirport idx: %d\n",cicaos.cicao[i].wAirportIndex);
			fprintf(outfile,"\tUnknown 1: %d - %.2X - low: %.2X, high: %.2X\n",
				cicaos.cicao[i].bStateIndex,cicaos.cicao[i].bStateIndex,
				cicaos.cicao[i].bStateIndex & 0xf, cicaos.cicao[i].bStateIndex >> 4
				);
			fprintf(outfile,"\tUnknown 2: %d - %.2X - low: %.2X, high: %.2X\n",
				cicaos.cicao[i].bUnk2,cicaos.cicao[i].bUnk2,
				cicaos.cicao[i].bUnk2 & 0xf, cicaos.cicao[i].bUnk2 >> 4
				);
			fprintf(outfile,"\tUnknown 3: %d - %.2X - low: %.2X, high: %.2X\n",
				cicaos.cicao[i].bRegionIndex,cicaos.cicao[i].bRegionIndex,
				cicaos.cicao[i].bRegionIndex & 0xf, cicaos.cicao[i].bRegionIndex >> 4
				);
			fprintf(outfile,"\tUnknown 4: %d - %.2X - low: %.2X, high: %.2X\n",
				cicaos.cicao[i].bCountryIndex,cicaos.cicao[i].bCountryIndex,
				cicaos.cicao[i].bCountryIndex & 0xf, cicaos.cicao[i].bCountryIndex >> 4
				);

			fprintf(outfile,"\tCity idx: %d\n",cicaos.cicao[i].wCitiesIndex);
			fprintf(outfile,"\tICAO: %d - %s\n",cicaos.cicao[i].nId,szId);
			fprintf(outfile,"\t");
			for (j=0; j<8; j++)
				fprintf(outfile,"%3d ",cicaos.cicao[i].lpUnk[j]);
			fprintf(outfile,"\n\n");
		}
		fprintf(outfile,"-->\n");
	}
#endif

	if (cicaos.cicao)
		FREE(cicaos.cicao);
	ChrPoolFree(cairports);
	ChrPoolFree(ccities);
	ChrPoolFree(cstates);
	ChrPoolFree(ccountries);
	ChrPoolFree(cregions);
	for (i=0; i<cobjects->nCount; i++)
	{
		ptr = (char *)cobjects->ptr[i].i;
		if (ptr)
			FREE(ptr);
	}

	ChrPoolFree(cobjects);
	p=lpIls;				// free ILS list
	while (p!=NULL)
	{
		p1 = p;
		p=p->next;
#ifdef DEBUG
		fprintf(outfile,"\t<!-- ILS, offset 0x%.8X (%d) -->\n",
			p1->nOffset, p1->nOffset);
#endif
		if (p1)
			FREE(p1);
	}

	p=lpTaxiSign;				// free Taxi sign list
	while (p!=NULL)
	{
		p1 = p;
		p=p->next;
#ifdef DEBUG
		fprintf(outfile,"\t<!-- TAXISIGN, offset 0x%.8X (%d) -->\n",
			p1->nOffset, p1->nOffset);
#endif
		if (p1)
			FREE(p1);
	}

	
	p = lpWpt;					// free terminal waypoint list
	while (NULL!=p)
	{
		p1 = p;
		p=p->next;
		if (p1)
			FREE(p1);
	}
}

/*
 * print an error message to stdout
 *
 * Parameters:
 * p - personalized string
 * dwErr - error code
 *
 * Return value:
 *
 * none
 */
void PrintError(char *p, DWORD dwErr)
{
#ifndef BGLDECD
#ifdef NT_API_CALLS
	char buffer[512];
	DWORD dwLen = FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM |
		FORMAT_MESSAGE_ARGUMENT_ARRAY, NULL, dwErr, 0,
		buffer, sizeof(buffer), NULL);

	while (dwLen > 0 && (buffer[dwLen - 1]<=32 || buffer[dwLen - 1]=='.'))
	{
		buffer[dwLen - 1]= '\0';
		dwLen--;
	}
	printf("%s\n(%s)\nError code: %d\n",p,buffer,dwErr);
#else
	printf("%s\n(%s)\n",p,strerror(dwErr));
#endif
#endif
}


/*
 * Open input BGL file
 *
 * Parameters:
 * pszFileName - file name to open
 *
 * Return value:
 *
 * 0 on success, else error defined by GetLastError()
 */
DWORD OpenInputFile(char *pszFileName)
{

	char buff[512];
	DWORD dwErr;

#ifdef NT_API_CALLS
	HANDLE fh;
	WIN32_FIND_DATA fd;

	memset(&map,0x0,sizeof(map));					// initialize map structure
	fh = FindFirstFile(pszFileName, &fd);			// see if file exists
	if (fh==INVALID_HANDLE_VALUE)
	{
		dwErr=GetLastError();						// if error
		sprintf(buff, CANTOPENFILE,
			pszFileName);							// format error message
		PrintError(buff,dwErr); 					// display error
		return dwErr;								// return failure
	}

	map.dwSize = fd.nFileSizeLow;					// get file size
	FindClose(fh);									// close find handle


	if (map.dwSize==0)								// if bogus size
	{
		sprintf(buff, BOGUSFILESIZE,pszFileName);
		return 5;									// return failure
	}

	map.hFile = CreateFile(pszFileName, GENERIC_READ, FILE_SHARE_READ, NULL,
			OPEN_EXISTING, FILE_ATTRIBUTE_READONLY, NULL);
	if (map.hFile == INVALID_HANDLE_VALUE)
	{
		dwErr=GetLastError();						// if error
		sprintf(buff, CANTOPENFILE,
				pszFileName);						// format error message
		PrintError(buff,dwErr); 					// display error
		map.hFile=0;								// invalidate handle
		return dwErr;								// return failure
	}

	map.hMap = CreateFileMapping(map.hFile, NULL, PAGE_READONLY, 0, 0,
			"bgl_xml_file");						// try to open file mapping
	dwErr = GetLastError(); 						// check for error
	if ((map.hMap != NULL) && (dwErr == ERROR_ALREADY_EXISTS))
	{
		sprintf(buff, DUPEFILEMAPPING,	pszFileName);
		CloseHandle(map.hMap);
		CloseHandle(map.hFile);
		PrintError(buff,dwErr); 					// display error
		map.hFile=0;								// invalidate handle
		map.hMap=0;
		return dwErr;								// return failure
	}
	else if (map.hMap == NULL)
	{
		sprintf(buff, FILEMAPPINGFAILED, pszFileName);
		CloseHandle(map.hMap);
		CloseHandle(map.hFile);
		PrintError(buff,dwErr); 					// display error
		map.hFile=0;								// invalidate handle
		map.hMap=0;
		return dwErr;								// return failure
	}

	map.ptr = (BYTE *) MapViewOfFile(map.hMap, FILE_MAP_READ,
			0, 0, 0);								// try map file to memory
	if (map.ptr == NULL)
	{
		sprintf(buff, MAPVIEWFAILED,pszFileName);
		CloseHandle(map.hMap);
		CloseHandle(map.hFile);
		PrintError(buff,dwErr); 					// display error
		map.hFile=0;								// invalidate handle
		map.hMap=0;
		return dwErr;								// return failure
	}
#else
	unsigned long ulSize;
	FILE *f = fopen(pszFileName,"rb");
	if (f==NULL)									// if file error
	{
		dwErr=errno;
		sprintf(buff,CANTOPENFILE, pszFileName);	// print error message
		PrintError(buff,dwErr);
		return dwErr;
	}
	memset(&map,0x0,sizeof(map));					// initialize map structure

	fseek(f,0L,SEEK_END);
	ulSize = ftell(f);								// get file size in bytes
	fseek(f,0L,SEEK_SET);							// rewind file pointer

	if (ulSize==0)									// if bogus size
	{
		sprintf(buff,BOGUSFILESIZE,pszFileName);
		fclose(f);									// close file
		return 5;									// return failure
	}

	if (NULL == (map.ptr=(BYTE *)MALLOC(ulSize+1)))
	{
		// not enough memory
		printf("Not enough memory to open %s\n", pszFileName);
		fclose(f);
		return 3;									// signal failure
	}

	fread(map.ptr,ulSize,1,f);						// load file into the buffer
	fclose(f);
	map.dwSize=ulSize;								// mark file size
#endif

	return 0;										// return success
}


/*
 * Close input BGL file
 *
 * Parameters:
 * none
 *
 * Return value:
 * none
 */
void CloseInputFile(void)
{
#ifdef NT_API_CALLS
	if (map.ptr!=NULL)
	{
		UnmapViewOfFile(map.ptr);       // unmap file and close
		map.ptr=NULL;
	}
	if (0!=map.hMap)
	{
		CloseHandle(map.hMap);          // close file mapping
		map.hMap=0;
	}
	if (0!=map.hFile)
	{
		CloseHandle(map.hFile);         // close file
		map.hFile=0;
	}
#else
	if (map.ptr)
		FREE(map.ptr);
#endif
}

/*
 * Do extra validation on input file
 *
 * Parameters:
 * none
 *
 * Return value:
 * 0 on success
 */
extern int ValidateInputFile(void)
{
	int nMagicNumber;
	if (map.dwSize<56)
	{
		return 1;
	}
	if (map.ptr[0]!=0x1 && map.ptr[1]!=0x1)
	{
		return 1;
	}
	nMagicNumber = GET_U32(0x10);	// position at magic number offset
	if (nMagicNumber!=FAC_DATA_NUMBER)
	{
		return 1;
	}
	return 0;										// return success
}

/*
 * analyze an object group
 *
 * Parameters:
 * nKind - kind of objects being examinated
 * nCount - count of groups to examinate
 * nOffset - offset to this group info table
 *
 * Return value:
 * none
 */
static void AnaObjGroup(DWORD nKind, DWORD nCount, DWORD nOffset)
{
	DWORD i;
	DWORD nLatInfo;
	DWORD nGrpCount;
	DWORD nGrpOffset;
	DWORD nChunkLen;

	if (nOffset>=map.dwSize ) /* some scenery start might be corrupted */
		return;

	for (i=0; i<nCount; i++)
	{
		TRACE("AnaObjGroup\n");
		nLatInfo = GET_U32(nOffset);
		nGrpCount = GET_U32(nOffset+4);
		nGrpOffset = GET_U32(nOffset+8);
		nChunkLen = GET_U32(nOffset+12);

		if (!nTerse)
		{
			fprintf(outfile, "<!--\n\tLatInfo: 0x%0.8X, offset: 0x%0.8X, length: 0x%0.8X, count: %d\n-->\n",
			nLatInfo, nGrpOffset, nChunkLen, nGrpCount);
		}

		switch (nKind)
		{
		case OBJTYPE_AIRPORT:
			AnalyzeApt(nGrpCount, nGrpOffset, nChunkLen);
			break;
		case OBJTYPE_VOR:
			AnalyzeVor(nGrpCount, nGrpOffset, nChunkLen);
			break;
		case OBJTYPE_NDB:
			AnalyzeNdb(nGrpCount, nGrpOffset, nChunkLen);
			break;
		case OBJTYPE_MKB:
			AnalyzeMkb(nGrpCount, nGrpOffset, nChunkLen);
			break;
		case OBJTYPE_WPT:
			AnalyzeWpt(nGrpCount, nGrpOffset, nChunkLen);
			break;
		case OBJTYPE_SCNOBJ:
			AnalyzeSceneryObject(nGrpCount, nGrpOffset, nChunkLen);
			break;
		case OBJTYPE_MDLDATA:
			AnalyzeModelData(nGrpCount, nGrpOffset, nChunkLen);
			break;
		case OBJTYPE_REGIONINF:
			AnalyzeRegion(1, nGrpOffset, nChunkLen);
			break;
		case OBJTYPE_EXCREC:
			AnalyzeExclusionRectangle(nGrpCount, nGrpOffset, nChunkLen);
			break;

		default:
			break;
		}

		nOffset+=16;
	}

}

static int qsCompare(const void *arg1, const void *arg2)
{
	obj_table_group_t *p1 = (obj_table_group_t *)arg1;
	obj_table_group_t *p2 = (obj_table_group_t *)arg2;
	return (p2->nObjType - p1->nObjType);
}


/*
 * start objects loop
 *
 * Parameters:
 * none
 *
 * Return value:
 * none
 */
void StartObjLoop(void)
{
	obj_table_group_t *ptr;
	DWORD n, i,j = GET_U32(20);										// get number of object kinds
	TRACE("StartObjLoop\n");

	// new code - with structure sort
	ptr = (obj_table_group_t *)MALLOC(j*sizeof(obj_table_group_t)); // allocate structure
	if (ptr)														// if enough memory
	{
		for (i=0, n=56; i<j; i++, n+=sizeof(obj_table_group_t))		// for each station
		{
			ptr[i].nObjType =GET_U32(n);							// get data for
			ptr[i].nUnk1=GET_U32(n+4);
			ptr[i].nGroupsCount=GET_U32(n+8);
			ptr[i].nGroupOffset=GET_U32(n+12);
			ptr[i].nTableSize=GET_U32(n+16);
		}


		qsort((void *)ptr, j, sizeof(obj_table_group_t),qsCompare);	// sort chain in descending order

		for (i=0; i<j; i++)
		{
			if (!nTerse)
				fprintf(outfile, "<!--\n\tObject type: 0x%0.8X\n\toffset: 0x%0.8X"
					"\n\tgroup count: %d\n"
					"\tunknown1: 0x%0.8X\n\ttable size: 0x%0.8X\n-->\n",
					ptr[i].nObjType,ptr[i].nGroupOffset,ptr[i].nGroupsCount,
					ptr[i].nUnk1,ptr[i].nTableSize);

			if (ptr[i].nObjType==OBJTYPE_GEOPOL)					// special case for Geopol's
				GeopolBoundaryGroupLoop(OBJTYPE_GEOPOL,ptr[i].nGroupsCount,
					ptr[i].nGroupOffset,ptr[i].nTableSize);
			else if (ptr[i].nObjType==OBJTYPE_BOUNDARY)				// special case for Boundary's
				GeopolBoundaryGroupLoop(OBJTYPE_BOUNDARY,ptr[i].nGroupsCount,
					ptr[i].nGroupOffset,ptr[i].nTableSize);
			else
				AnaObjGroup(ptr[i].nObjType,ptr[i].nGroupsCount,ptr[i].nGroupOffset);
		}
		FREE(ptr);
	}
}


static char buf[16384];

/*
 * Open output XML file
 *
 * Parameters:
 * pszFileName - file name to open
 *
 * Return value:
 *
 * pointer to file on success, else NULL
 */
FILE *OpenOutputFile(char *pszFileName)
{
	FILE *p=fopen(pszFileName,"wt");
	if (p)
		setvbuf( p, buf, _IOFBF, sizeof( buf ) );
	return p;
}


/*
 * convert FS2K4 packed latitude to decimal degrees
 *
 * Parameters:
 * ndblat - packed latitude
 *
 * Return value:
 * decimal degrees
 */
double fslat2lat(int ndblat)
{
	double f = (((double)ndblat)*180)/MAXSOUTH;
	if (f>90.0)
		return -((f-180)+90);
	else
		return 90-f;
}

/*
 * convert FS2K4 packed longitude to decimal degrees
 *
 * Parameters:
 * ndblon - packed longitude
 *
 * Return value:
 * decimal degrees
 */
double fslon2lon(int ndblon)
{
	double f = (((double)ndblon)*360)/MAXEAST;
	return f - 180;
}

/*
 * convert FS2K4 packed region identifiers
 *
 * Parameters:
 * number - packed identifier
 * p - pointer to string which returns the conversion
 *
 * Return value:
 * p, modified in place
 */
char *DecodeRegionStr(DWORD number, char *p)
{
	DWORD a,b;
	char *str = p;
	if (str)
	{
		if (number>1443)
		{
			number = LOWORD(number) & ~0xf800;
		}
		if (number==0)
		{
			*str = '\0';
		}
		else if (number>=2 && number<=1443)
		{
			b = number % 38;
			a = number / 38;
			str[0] = RegionLookUpTable[a];
			str[1] = RegionLookUpTable[b];
			str[2] = '\0';
		}
		else
		{
			str[0] = 'A';
			str[1] = 'A';
			str[2] = '\0';
		}
	}
	// trim out leading space, if any
	if (str[0]== ' ')
	{
		str[0]=str[1];
		str[1]='\0';
	}
	return p;
}

/*
 * not all compilers have strrev
 */
char *str_rev(char *string)
{		
	DWORD i, j;
	DWORD length = strlen(string);	/* Number of characters in string	*/
	char temp;
	for (i = 0, j = length-1;		/* Counting from front and rear		*/
		i < length / 2; i++, j--) 
	{								/* until we reach the middle		*/

		
		temp = string[i];			/* Save front character				*/
		string[i] = string[j];		/* Switch with rear character		*/
		string[j] = temp;			/* Copy new rear character			*/
		
	}
	return string;
}


/*
 * convert FS2K4 packed ICAO ILS IDs identifiers inside rwy chunks
 *
 * Parameters:
 * number - packed identifier
 * p - pointer to string which returns the conversion
 *
 * Return value:
 * p, modified in place
 */
char *DecodeIlsStr(DWORD number, char *p)
{
	char *ptr = p;
	char r/*,c*/;
	DWORD q = number;
	for (; q>0; q/=38)
	{
		r = (char)(q % 38);
		*ptr++ = (r<12) ? r+46 : r+53;
	}
	*ptr= '\0';
    str_rev(p);

	return p;
}


/*
 * convert FS2K4 packed ICAO IDs identifiers
 *
 * Parameters:
 * number - packed identifier
 * p - pointer to string which returns the conversion
 * lparam - value to subtract from number (!!!!)
 *
 * Return value:
 * p, modified in place
 *
 * Remarks:
 * very rough converter (like a pre-alpha :-))
 * sure there must be better ways
 *
 * Remarks2:
 * rewritten using method suggested by Marco Sinchetto
 */
char *DecodeIdStr(DWORD number, char *p, DWORD lparam)
{
	BYTE b = LO4BITS(LOBYTE(LOWORD(number))); // strip lowest 4 bits from number
	char r, c;
	char *ptr = p;
	DWORD q;
	number -= b;
	q = (number >> 5);
	for (; q>0; q/=38)
	{
		r = (char)(q % 38);
		c = (r<12) ? r+46 : r+53;
		*ptr++=c;
	}
	*ptr= '\0';
	if (!*p)
	{
    	*p='0';
		*++p='\0';
	}
	else
	    str_rev(p);
	return p;


/*	
	old method - just commented out, it could always turn useful
	DWORD b1,b2,b3,b4,b5, b6;
	DWORD i = number - lparam;
	if (number==0)		// empty id
	{
		*p='\0';
	}
	else
	{
		if (i<=1120UL)
		{
			sprintf(p,"%c",RegionLookUpTable[(i/32)+2]);
		}
		else if (i>=2432UL && i<=47424UL)
		{
			b1 = (i - 2432UL) / 32;
			b3 = b1 / 38;
			b2 = b1 % 38;
			sprintf(p,"%c%c",RegionLookUpTable[b3+2],RegionLookUpTable[b2+2]);
		}
		else if (i>=94848UL && i<=1755808UL)
		{
			b1 = (i - 94848UL) / 32;
			b3 = b1 / 38 / 38;
			b2 = b1 / 38 % 38;
			b4 = b1 % 38 % 38;
			sprintf(p,"%c%c%c",RegionLookUpTable[b3+2],RegionLookUpTable[b2+2],RegionLookUpTable[b4+2]);
		}
		else if (i>=3606656UL && i<=66724256UL)
		{
			b1 = (i - 3606656UL) / 32;
			b3 = b1 / 38 / 38 / 38;
			b2 = b1 / 38 / 38 % 38;
			b5 = b1 / 38 % 38  % 38;
			b4 = b1 % 38 % 38  % 38;
			sprintf(p,"%c%c%c%c",RegionLookUpTable[b3+2],RegionLookUpTable[b2+2],
				RegionLookUpTable[b5+2],RegionLookUpTable[b4+2]);
		}
		else if (i>=137055360UL && i<=2535525280UL)
		{
		//	b1 = (i - 3606656) / 32;
			b1 = (i - 137055360UL) / 32;
			
			b3 = b1 / 38 / 38 / 38 / 38;
			b6 = b1 / 38 / 38 / 38 % 38;
			b2 = b1 / 38 / 38 % 38 % 38;
			b5 = b1 / 38 % 38 % 38 % 38;
			b4 = b1 % 38 % 38 % 38 % 38;
			sprintf(p,"%c%c%c%c%c",
				RegionLookUpTable[b3+2],
				RegionLookUpTable[b6+2],
				RegionLookUpTable[b2+2],
				RegionLookUpTable[b5+2],
				RegionLookUpTable[b4+2]);
		}
		else if (i==0)
		{
			p[0]='\0';
			p[1]='\0';
		}
		else
		{
			sprintf(p,"%0.8X",number);
		}
	}
	return p;
*/
}

static char latbuff[24];

/*
 * convert lat/lon to dec.deg otr dd/mm/ss format
 *
 * Parameters:
 * ll - lat/lon value to convert (fp)
 * str - pointer to string to store converted coordinate
 *
 * Return value:
 * converted string (str is modified in place)
 */
char *LatString(double ll, char *str)
{

	double cxx/*,cxs*/;
	int cxd;
	double cxm;

	if (str==NULL)
		str=latbuff;

	if (nLatLonAsDeg)
	{
		if (ll<0.0)
		{
			cxx=-ll;
			cxd = (int) (cxx);
			/*cxm = (int) ((cxx-cxd) * 60);
			cxs =  (((cxx-cxd)*60-cxm)*60);
			sprintf(str,"-%d %d %0.2lf", cxd, cxm, cxs);*/
			cxm = ((cxx-cxd) * 60);
			sprintf(str,"-%d %0.5lf", cxd, cxm);
		}
		else
		{
			cxx=ll;
			cxd = (int) (cxx);
			cxm = ((cxx-cxd) * 60);
			sprintf(str,"%d %0.5lf", cxd, cxm);
			/*cxm = (int) ((cxx-cxd) * 60);
			cxs =  (((cxx-cxd)*60-cxm)*60);
			sprintf(str,"%d %d %0.2lf", cxd, cxm, cxs);*/
		}

	}
	else
		sprintf(str,"%0.6lf",ll);

	return str;
}


/*
 * convert altitudes to proper value
 *
 * Parameters:
 * nAlt - altitude in FS format
 * str - pointer to string to store converted measure
 *
 * Return value:
 * converted string (str is modified in place)
 */
char *AltString(int nAlt, char *str)
{
	if (str==NULL)
		str=latbuff;
	if (nFeet)              // convert to feet
		sprintf(str,"\"%0.3lfF\"", ((double)nAlt/1000)*METERSTOFEET);
	else                    // convert to meters
		sprintf(str,"\"%0.2lf\"", (double)nAlt/1000);
	return str;
}


/*
 * convert ranges to proper value
 *
 * Parameters:
 * fRange - range in meters
 * str - pointer to string to store converted measure
 *
 * Return value:
 * converted string (str is modified in place)
 */
char *RangeString(float fRange, char *str)
{
	if (str==NULL)
		str=latbuff;
	if (nMiles)             // convert to nm
		sprintf(str,"\"%0.2lfN\"", ((double)fRange/1000)/KMSTONAUTMILES);
	else                    // convert to meters
		sprintf(str,"\"%0.2lf\"", (double)fRange);
	return str;
}

/*
 * convert dimensions to proper value
 *
 * Parameters:
 * fDim - altitude in FS format
 * str - pointer to string to store converted measure
 *
 * Return value:
 * converted string (str is modified in place)
 */
char *DimString(float fDim, char *str)
{
	if (str==NULL)
		str=latbuff;
	if (nFeet)              // convert to feet
		sprintf(str,"\"%0.3lfF\"", ((double)fDim)*METERSTOFEET);
	else                    // convert to meters
		sprintf(str,"\"%0.2lf\"", (double)fDim);
	return str;
}

/*
 * print object specifications if verbose info is enabled
 *
 * Parameters:
 * s - name of object
 * nPos - absolute offset of this object
 *
 * Return value:
 * none
 */
void PrintObjectSpec(char *s, int nPos)
{
	fprintf(outfile,"\n\t<!-- %s, offset 0x%.8X (%d) -->\n",
		s, nPos, nPos);
	#ifdef DEBUG
	if (!nTerse)
		printf("%s, offset 0x%.8X (%d)\n",s, nPos, nPos);
	#endif
}


/*
 * write a chunk out to a new file in one pass
 *
 * Parameters:
 * pszFileName - file name to create
 * lpBuff - pointer to buff to write to
 * dwSize - number of bytes to write
 *
 * Return value:
 * 0 on success, else error code defined by GetLastError()
 */
DWORD WriteChunkToFile(const char *pszFileName, BYTE *lpBuff, DWORD dwSize)
{
	char str[512];
	DWORD dwErr;
#ifdef NT_API_CALLS
	DWORD dwWritten;
	HANDLE hFile = CreateFile(pszFileName,GENERIC_WRITE,0,
		NULL,CREATE_ALWAYS,
		FILE_ATTRIBUTE_ARCHIVE,NULL);					// do create new file

	TRACE("WriteChunkToFile\n");

	if (hFile==INVALID_HANDLE_VALUE)					// if error
	{
		dwErr=GetLastError();							// mark error code
		sprintf(str, CANTOPENFILE,pszFileName); 		// format error message
		PrintError(str,dwErr);							// display error
		return dwErr;									// return failure
	}

	if (!WriteFile(hFile,lpBuff,dwSize,&dwWritten,NULL))// write the chunk
	{													// if error
		dwErr=GetLastError();							// mark error code
		sprintf(str, CANTWRITEFILE, pszFileName);		// format error message
		PrintError(str,dwErr);							// display error
		CloseHandle(hFile); 							// close the file
		return dwErr;									// return failure
	}
	CloseHandle(hFile); 								// close the file

#else
	FILE *f = fopen(pszFileName,"wb");					// create new file
	TRACE("WriteChunkToFile\n");
	if (!f)												// if failure
	{
		dwErr=errno;									// mark error code
		sprintf(str, CANTOPENFILE,pszFileName); 		// format error message
		PrintError(str,dwErr);							// display error
		return dwErr;									// return failure
	}
	if (!fwrite(lpBuff,dwSize,1L,f))					// write the chunk
	{
		dwErr=errno;									// mark error code
		sprintf(str, CANTWRITEFILE, pszFileName);		// format error message
		PrintError(str,dwErr);							// display error
		fclose(f);
		return dwErr;									// return failure
	}
	fclose(f);
#endif
	return 0;											// signal success
}



/*
 * calculate great circle distance between points
 *
 * Parameters:
 * lat1 - start latitude in degrees
 * lon1 - start longitude in degrees
 * lat2 - end latitude in degrees
 * lon2 - end longitude in degrees
 *
 * Return value:
 * distance in meters among the two points
 */
double gcdist(double lat1, double lon1, double lat2, double lon2)
{
	double e, cosdeltalon = cos((lon2 - lon1) * RADVALUE);
	TRACE("gcdist\n");

	lat1 *= RADVALUE;
	lat2 *= RADVALUE;
	e = 0.5 * (cos(lat2 - lat1) * (1 + cosdeltalon) - cos(lat2 + lat1) *
		(1 - cosdeltalon));
	return (0.5 * 40007000 / Pi) * acos(e);
}


/*
 * Equivalent of spreadsheet Mod(y,x)
 * Returns the remainder on dividing y by x in the range
 * 0<=Md <x
 */
double mod(double y, double x)
{
	return (y>=0) ?	y - x * (int)(y / x) : y + x * ((int)(-y / x)+1);
}


/*
 * calculate bearing between points
 *
 * Parameters:
 * lat1 - start latitude in degrees
 * lon1 - start longitude in degrees
 * lat2 - end latitude in degrees
 * lon2 - end longitude in degrees
 *
 * Return value:
 * bearing in degrees among the two points
 */
double gcbearing(double lat1, double lon1, double lat2, double lon2)
{
/*	double deltalon, f,e, cosdeltalon;
	deltalon = (lon2 - lon1) * RADVALUE;
	cosdeltalon = cos(deltalon);
	TRACE("gcbearing\n");

	lat1 *= RADVALUE;
	lat2 *= RADVALUE;
	e = 0.5 * (sin(lat1+lat2) * (1 - cosdeltalon) - sin(lat1-lat2)*(1+cosdeltalon));
	f = mod(atan2(sin(deltalon) * cos(lat2), e), Pi*2) * DEGVALUE;
	if (f<0) f+=360;
	return f;
*/
	double bearing;
	double dlon = (lon2-lon1) * RADVALUE;
	lat1 *=  RADVALUE;
	lat2 *=  RADVALUE;

	bearing = atan2(sin(dlon), (-sin(lat1)*cos(dlon) + tan(lat2)*cos(lat1))) / RADVALUE;
	if (bearing < 0)
		bearing += 360;
	return bearing;



}


/*
 * convert lat/lon string to floating constant
 *
 * Parameters:
 * str - latitude/longitude format in dd:mm:ss notation
 * 
 * Return:
 * converted value in decimal degrees
 */
double deg2real(char *str)
{
	int sign = 1;
	char *p;
	double deg;

	switch (str[0])
	{
	case 'N':
	case 'E':
	case '+':
		sign = 1;
		str++;
		break;

	case 'S':
	case 'W':
	case '-':
		sign = -1;
		str++;
		break;
	}
	
	/* deg */
	p = strtok(str, ":");

	if (!p)	// do we have a decimal string ?
	{
		deg = atof(str); // try to return it
		return deg;
	}
	deg = atof(p);

	/* minute */
	p = strtok(NULL, ":");
	if (p)
	{
		deg += atof(p) / 60.0;
		
		/* second */
		p = strtok(NULL, ":");
		if (p)
		{
			deg += atof(p) / 3600.0;
		}
	}
	deg *= sign;
	return deg;
}


/*
 * dump a block to HEX
 *
 * Parameters:
 * nStart - offset of block into file
 * nLent - length of block
 * 
 * Return:
 * none
 */
void DumpToHex(DWORD nStart, DWORD nLen)
{
	DWORD i;
	int j = 0;
	ASSERT(outfile);
	fprintf(outfile,"\t\t<!--");

	for (i=nStart; i<nStart+nLen; i++)
	{
		if (j==0)
			fprintf(outfile,"\n\t\t\t");
		else if (j==8)
			fprintf(outfile," ");	// print one more space in the middle
                
		fprintf(outfile,"%0.2X ", map.ptr[i]);
		j++;
		if (j>15)
			j=0;
	}
	fprintf(outfile,"\n\t\t-->\n\n");

}


#ifndef max
#define max(a,b) (a>b) ? a : b
#endif
#ifndef min
#define min(a,b) (a>b) ? a : b
#endif

/*
 * calculate arc cosine of an angle with bound checking to 
 * prevent floating point overruns
 *
 * Input values:
 * X - angle (in radians) to calculate arc cosine of
 *
 * Return:
 * arc cosine of the angle
 */
double SafeAcos(double X)
{
	double F = max(-1, min(X, 1));
	if (F > 1)
		return 0;
	else if (F < -1)
		return Pi;
	else
	{
		printf("%0.6f\n",F);
		F=acos(F);
		printf("%0.6f\n",F);
		return F;
	}	
}


/*
 * print string with XML translation
 *
 * Input values:
 * str : string to print
 * nSpaces: number of characters to print. This can be 0, if we need
 *          to determine string length automatically
 *
 * Return:
 * none
 */
void PrintXmlString(unsigned char *str, DWORD nSpaces)
{
	DWORD i,j;
	if (nSpaces==0)
		j = strlen(str);
	else
		j = nSpaces;

	fprintf(outfile,"\"");
	for (i=0; i<j; i++)
	{
		/* with typecast to make borland compiler happy */
		/* if (isspace((int)str[i]) || isalnum((int)str[i]) || str[i]=='/') */
		if (str[i]=='<')
		{
			fprintf(outfile,"&lt;");
		}
		else if (str[i]=='>')
		{
			fprintf(outfile,"&gt;");
		}
		if (str[i]>=32 && str[i]<128 && str[i]!='<' && str[i]!='>' && str[i]!='`')
		{													/* if we have a alpha character */
			fprintf(outfile,"%c",str[i]);
		}
		else												/* use the trick posted in tthe list */
		{													/* by flederes to print an hex code  */
			fprintf(outfile,"&#x%0.2X;",str[i]);
		}
	}
	fprintf(outfile,"\"");

}




DWORD Strip11Bits(DWORD d)
{
	DWORD low = d >> 6;
	return low;
}


/*
 * calculate cartesian offset of a lat/lon pair
 *
 * Input values:
 * fLat - latitude in degrees
 * fLon - longitude in degrees
 * fX - offset along the X axis in meters
 * fY - offset along the Y axis in meters
 * fEndLat - pointer to value which receives the offset'd latitude
 * fEndLon - pointer to value which receives the offset'd longitude
 *
 * Note: derived from Lee Swordy's FS2002 AFD file structures documentation
 *
 * Return:
 * none
 */
void CartesianOffset(double fLat, double fLon, double fX, double fY, 
					 double *fEndLat, double *fEndLon)
{
	#define EarthPolarCircumference 40007000.0
	#define EarthEquatorCircumference 40075000.0
	double rx, ry, sinlat, radianlat, radianlon;
    double coslat, srx,f;
    double NodeRadianLat, NodeRadianLon;

	TRACE("CartesianOffset\n");

    /*
	 * convert input lat & lon to radians
	 */
    radianlat = fLat * RADVALUE;
    radianlon = fLon * RADVALUE;
    
    /*
	 * convert the X/Y offsets to radians:
	 */
    rx = (fX / EarthEquatorCircumference) * (2 * Pi);
    ry = (fY / EarthPolarCircumference) * (2 * Pi);

	if (rx!=0 && ry!=0)
	{
        sinlat = sin(radianlat);
		coslat = cos(radianlat);
		if (coslat < 0.000001)
			srx = 0.0;
		else
		{
			f=(cos(rx)-(sinlat * sinlat))/(coslat * coslat);
			if (f > 1)
				srx=0;
			else if (f < -1)
				srx= Pi;
			else if (f!=0)
				srx = acos(f);
			else
				srx=0;
		}
	}
	else
		srx = 0;

	NodeRadianLat = radianlat + ry;
    if (rx > 0.0)
        NodeRadianLon = radianlon + srx;
    else
        NodeRadianLon = radianlon - srx;
    
	*fEndLat = (NodeRadianLat * DEGVALUE);
	*fEndLon = (NodeRadianLon * DEGVALUE);

}


/*#define FUELNO	"NO"
#define FUELYES	"YES"
#define FUELUNK	"UNKNOWN"
#define FUELPR	"PRIOR_REQUEST"
*/


#ifdef DEBUG
void AssertFail(char *fname, int lineno)
{
	fprintf(stderr, "Assertion Failed %s line %d\n",
		fname, lineno);
	exit(1);
}

#endif



// ANSI emulation routines for those compilers which don't have 
#ifdef ANSI
char *strlwr(char * string)
{
	char *ptr = string;
	while (*ptr)
	{
		if (*ptr >= 'A' && *ptr <= 'Z')
			*ptr += 'a' - 'A';
		ptr++;
	}
	return(string);
}
#endif  /* defined ANSI */

/* Return float from little-endian data.
   Assumes ints and floats have same endianess */
float get_float(int p)
{
	DWORD v=GET_U32(p);
	return *((float*) &v);
}

