/*
 *   $Id: options.h,v 1.2 2004/02/12 15:20:59 Alessandro Exp $
 */
#ifndef options_h
#define options_h

#include "getopt.h"

extern int nLatLonAsDeg;
extern int nPartialDecode;
extern int nTerse;
extern char InputFileName[1024];
extern char OutputFileName[1024];
extern int nFeet;
extern int nMiles;
extern UINT nRadius;
extern char *pszLatStr;
extern char *pszLonStr;
extern double fCenterRad;
extern double fCenterLat;
extern double fCenterLon;

extern Option lpOptions[];


#endif
