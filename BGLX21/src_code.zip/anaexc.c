/*
 *   $Id: anaexc.c,v 1.2 2007/10/02 21:46:38 alexanto Exp $
 *
 *   BGL to XML converter
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: ExclusionRect record analyzer $
 *
 *   $Log: anaexc.c,v $
 *   Revision 1.2  2007/10/02 21:46:38  alexanto
 *   +Id+Log
 *
 *   Revision 1.1  2007/09/23 23:21:18  Alessandro
 *   Initial revision
 *
 *   Revision 1.2  2004/04/08 11:57:15  alexanto
 *   Made all unsigned types as DWORD
 *
 *   Revision 1.1  2004/02/04 14:07:48  alexanto
 *   Initial revision
 *
 */
#include "bglxml.h"

#define GET_EXC(f,b) b==(f & b)

/*
 * Analyzes and decode Exclusion rectangles
 *
 * Parameters:
 * nGrpCount - number of MKB available in this group
 * nGrpOffset - offset to current MKB chunk
 * nGrpLen - current chunk length
 *
 * Return value:
 * none
 */
void AnalyzeExclusionRectangle(DWORD nGrpCount, DWORD nGrpOffset, DWORD nChunkLen)
{
	int nLatMin;
	int nLonMin;
	int nLatMax;
	int nLonMax;
	WORD wFlags;
	BYTE bHi, bLow;
	char szLatMin[24];
	char szLonMin[24];
	char szLatMax[24];
	char szLonMax[24];

	wFlags = GET_U16(nGrpOffset);
	nLonMin = GET_S32(nGrpOffset+4);
	nLatMax = GET_S32(nGrpOffset+8);
	nLonMax = GET_S32(nGrpOffset+12);
	nLatMin = GET_S32(nGrpOffset+16);


	
	bLow = (BYTE)(wFlags & 0xFF);
	bHi = (BYTE)(wFlags >> 8);


	if (bLow==BIT_EXCLUDE_ALL || GET_EXC(bLow,BIT_EXCLUDE_BEACON) ||
		GET_EXC(bLow,BIT_EXCLUDE_EFFECT) ||
		GET_EXC(bLow,BIT_EXCLUDE_BUILDING) ||
		GET_EXC(bLow,BIT_EXCLUDE_LIBOBJ) ||
		GET_EXC(bHi,BIT_EXCLUDE_TAXIWAY) ||
		GET_EXC(bHi,BIT_EXCLUDE_TRIGGER) ||
		GET_EXC(bHi,BIT_EXCLUDE_TRIGGER) ||
		GET_EXC(bHi,BIT_EXCLUDE_WINDSOCK) )
	{
		fprintf(outfile,"\t<ExclusionRectangle\n"
					"\t\tlatitudeMinimum = \"%s\"\n"
					"\t\tlatitudeMaximum = \"%s\"\n"
					"\t\tlongitudeMinimum = \"%s\"\n"
					"\t\tlongitudeMaximum = \"%s\"\n",
		LatString(fslat2lat(nLatMin),szLatMin),
		LatString(fslat2lat(nLatMax),szLatMax),
		LatString(fslon2lon(nLonMin),szLonMin),
		LatString(fslon2lon(nLonMax),szLonMax)
		);
	
		if (bLow==BIT_EXCLUDE_ALL)
			fprintf(outfile,"\t\texcludeAllObjects = \"TRUE\"");
		else
		{
			fprintf(outfile,"\t\texcludeAllObjects = \"FALSE\"");
		
			fprintf(outfile,"\n\t\texcludeBeaconObjects = \"%s\"",
				GET_EXC(bLow,BIT_EXCLUDE_BEACON) ? truthTable[1] : truthTable[0]);
			fprintf(outfile,"\n\t\texcludeEffectObjects = \"%s\"",
				GET_EXC(bLow,BIT_EXCLUDE_EFFECT) ? truthTable[1] : truthTable[0]);
			fprintf(outfile,"\n\t\texcludeGenericBuildingObjects = \"%s\"",
				GET_EXC(bLow,BIT_EXCLUDE_BUILDING) ? truthTable[1] : truthTable[0]);
			fprintf(outfile,"\n\t\texcludeLibraryObjects = \"%s\"",
				GET_EXC(bLow,BIT_EXCLUDE_LIBOBJ) ? truthTable[1] : truthTable[0]);
			fprintf(outfile,"\n\t\texcludeTaxiwaySignObjects = \"%s\"",
				GET_EXC(bHi,BIT_EXCLUDE_TAXIWAY) ? truthTable[1] : truthTable[0]);
			fprintf(outfile,"\n\t\texcludeTriggerObjects = \"%s\"",
				GET_EXC(bHi,BIT_EXCLUDE_TRIGGER) ? truthTable[1] : truthTable[0]);
			fprintf(outfile,"\n\t\texcludeWindSockObjects = \"%s\"",
				GET_EXC(bHi,BIT_EXCLUDE_WINDSOCK) ? truthTable[1] : truthTable[0]);
		}

		fprintf(outfile," />\n");
	}
}
