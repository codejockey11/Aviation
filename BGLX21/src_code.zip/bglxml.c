/*
 *   $Id: bglxml.c,v 1.2 2007/09/23 23:29:08 Alessandro Exp $
 *
 *   BGL to XML converter for FSX
 *   Copyright (C)2004  Alessandro G. Antonini, Central Park Informatica
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   $Desc: Main program $
 *
 *   $Log: bglxml.c,v $
 *   Revision 1.2  2007/09/23 23:29:08  Alessandro
 *   +Id+Log
 *
 *   Revision 1.1  2007/09/23 23:20:19  Alessandro
 *   Initial revision
 *
 */
#include "bglxml.h"

char OutFileDir[1024];
char InputFileName[1024];
char OutputFileName[1024];

static const char RcsId[] = "$Id: bglxml.c,v 1.2 2007/09/23 23:29:08 Alessandro Exp $";

/*
 * forward declarations
 */
void WriteXmlHeader(FILE *);
void usage(int);
void PrintCopyRight(void);
int do_param(char *,int);
void print_switches(void);
void ParseObjectFile(char *);

void ReplaceExt(char *, const char *);
void ExtractPath(char *);
void GetOptError(char *str);
int main(int argc, char **argv)
{
	char objFile[1024];
	DWORD dwCode;
	int c;
	

	InputFileName[0] = '\0';
	OutputFileName[0] = '\0';

	PrintCopyRight();
#ifdef BC45
	c =GetParamCount();
#else
	c=argc;
#endif

	if (c<2)
	{
		usage(TRUE);
		return 0;
	}

#ifdef BC45
	c=getargs(7,lpOptions, do_param,GetOptError);
#else
	c=getargs(argc,argv,7,lpOptions, do_param,GetOptError);
#endif
	switch (c)
	{
	case INVALID:
		usage(TRUE);
		return 0;
	case HELP:
		usage(FALSE);
		print_switches();
		return 0;
	}

	if (!InputFileName[0])
	{
		printf("Error: missing an input file name\n");
		usage(TRUE);
		return 2;
	}

	if (!OutputFileName[0])			// missing output, use default
	{

		strcpy(OutputFileName,InputFileName);
		ReplaceExt(OutputFileName,".xml");
	}
#ifdef DEBUG
	printf("Out File Name = %s\n",OutputFileName);
#endif

	if (!InitArrays())
	{
		printf("Not enough memory to allocate airport arrays\n");
		return 0;
	}

	if (0 != (dwCode = OpenInputFile(InputFileName)))
	{
		return dwCode;
	}
	if (ValidateInputFile()!=0)
	{
		printf("%s\n",INVALIDFILE);					// invalid magic number
		return 0;
	}

	if (NULL == (outfile=OpenOutputFile(OutputFileName)))
	{
		CloseInputFile();
		return 2;
	}


	// print switches info
	#ifdef DEBUG
	printf("Terse = %d\n",nTerse);
	printf("LatLonAsDeg = %d\n",nLatLonAsDeg);
	printf("Feet = %d\n",nFeet);
	printf("Radius = %u\n",nRadius);
	if (pszLatStr)
		printf("pszLatStr = %s\n",pszLatStr);
	if (pszLonStr)
		printf("pszLonStr = %s\n",pszLonStr);
	#endif

	// see if partial decode is enabled

	if (pszLatStr && pszLonStr)
	{

		if (nRadius>4000)	// trim the radius to a reasonable value
			nRadius=4000;
		fCenterRad = (double)nRadius*1000;
		fCenterLat = deg2real(pszLatStr);
		fCenterLon = deg2real(pszLonStr);
		nPartialDecode = (0!=fCenterRad && 0!=fCenterLat && 0!=fCenterLon);
		#ifdef DEBUG
		printf("PartialDecodeEnabled = %d\n",nPartialDecode);
		#endif
	}


	// store path to output file
	strcpy(OutFileDir,OutputFileName);
	ExtractPath(OutFileDir);
#ifdef DEBUG
	printf("Out File Dir = %s\n",OutFileDir);
#endif


	// form path to objects.txt
	strcpy(objFile,argv[0]);
	ExtractPath(objFile);
	strcat(objFile,"library objects.txt");

#ifdef DEBUG
	printf("Object File = %s\n",objFile);
#endif

	ParseObjFile(objFile);

	WriteXmlHeader(outfile);
	printf("Analyzing %s...\n",InputFileName);
	StartObjLoop();

	FreeArrays();

	fprintf(outfile,"</FSData>\n");
	fclose(outfile);
	CloseInputFile();
	printf("Done!\nOutput saved as %s\n",OutputFileName);
	return 0;
}

void PrintCopyRight(void)
{
    printf("BglXml version %s - (C)2003-2007 Alessandro G.Antonini\n", VERSION);
}

void usage(int disphelp)
{
	printf("Usage: bglxml [-switches] infile.bgl [outfile.xml]\n");
	if (disphelp)
		printf("Type bglxml -? for help\n");
}

void print_switches(void)
{
	printf("\nSwitches:\n");
	print_desc(7,lpOptions);
}

void WriteXmlHeader(FILE *f)
{


#ifdef NT_API_CALLS
	SYSTEMTIME st;
	GetLocalTime(&st);


	fprintf(f,"<!--\n\t"
		"decoded by bglxml on %0.4d-%0.2d-%0.2d, %0.2d:%0.2d:%0.2d\n-->\n",
		st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond);
#else
	struct tm *ct;
	time_t current_time;
	time(&current_time);
	ct = localtime(&current_time);
	fprintf(f,"<!--\n\tdecoded by bglxml on %s-->\n", asctime(ct));
#endif

	fprintf(f, "<FSData version=\"9.0\" "
		"xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'\n "
		"xsi:noNamespaceSchemaLocation=\"bglcomp.xsd\" >\n\n");
}

int do_param(char *param,int num)
{
	switch (num)
	{
	case 1:
		strcpy(InputFileName,param);
		return ALLDONE;
	case 2:
		strcpy(OutputFileName,param);
		return ALLDONE;
	default:
		return INVALID;

	}

}


/*
 * replace extension to a file name
 */
void ReplaceExt(char *str, const char *ext)
{
	char *ptr = strrchr(str,'.');
	if (ptr)
	{
		*ptr='\0';
	}
	strcat(str,ext);
}

/*
 * extract directory out of a full name
 */
void ExtractPath(char *str)
{
	UINT i, len = strlen(str);
	for (i = len - 1; i > 0; i--)
	{
		if (str[i] == '\\' || str[i] == '/')
		{
			str[i+1] = '\0';
			return;
		}
	}
	// we have no path, just retun an empty string
	*str='\0';
}

/*
 * callback routine to print getopt errors
 */
void GetOptError(char *str)
{
	printf(str);
}
