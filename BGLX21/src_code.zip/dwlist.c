#include "bglxml.h"

dwlist_t *dwlist_init()
{
	dwlist_t *ptr = (dwlist_t *)MALLOC(sizeof(dwlist_t));
	if (ptr)
	{
		ptr->count=0;
		ptr->head=NULL;
		ptr->tail=NULL;
	}
	return ptr;
}

int dwlist_add(dwlist_t *list, const unsigned long value, const unsigned long data)
{
	dwnode_t *node = (dwnode_t *)MALLOC(sizeof(dwnode_t));
	if (node==NULL)
		return 0;
	node->value=value;
	node->data=data;
	node->next=NULL;

	if (NULL==list->head)
	{
		list->head=node;
		list->tail=node;
	}
	else
	{
		list->tail->next=node;
		list->tail=node;
	}
	list->count++;
	return 1;
}


void dwlist_clear(dwlist_t *list)
{
	dwnode_t *p1, *p=list->head;
	while (p!=NULL)
	{
		p1 = p;
		p=p->next;
		if (p1)
			FREE(p1);
	}
	list->count=0;
	list->head=NULL;
	list->tail=NULL;
}

void dwlist_free(dwlist_t **list)
{
	dwnode_t *p1, *p=(*list)->head;
	while (p!=NULL)
	{
		p1 = p;
		p=p->next;
		if (p1)
			FREE(p1);
	}
	FREE(*list);	// free list itself
	*list=0;
}

